import { useState, useEffect } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Heart, 
  Download,
  RefreshCw,
  AlertCircle,
  Target,
  X,
  FileText,
  Eye,
  Share2,
  Printer,
  ClipboardList
} from 'lucide-react';

// Types for questionnaire data
interface Student {
  id: string;
  name: string;
  grade: string;
  preTestScore: number;
  postTestScore: number;
  happinessImprovement: number;
  emotionalDistribution: {
    happy: number;
    neutral: number;
    sad: number;
    anxious: number;
    excited: number;
  };
}

interface ClassData {
  className: string;
  totalStudents: number;
  averagePreTest: number;
  averagePostTest: number;
  averageImprovement: number;
  students: Student[];
}

interface QuestionnaireData {
  classes: ClassData[];
  overallStats: {
    totalStudents: number;
    averageHappinessBefore: number;
    averageHappinessAfter: number;
    overallImprovement: number;
  };
}

export default function QuestionnairePage() {
  const [activeTab, setActiveTab] = useState<'overview' | 'individual' | 'comparison'>('overview');
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [selectedStudent, setSelectedStudent] = useState<string | null>(null);
  const [data, setData] = useState<QuestionnaireData | null>(null);
  const [loading, setLoading] = useState(true);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showAnalysisModal, setShowAnalysisModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [selectedDetailType, setSelectedDetailType] = useState<'student' | 'class' | 'overall' | null>(null);
  const [selectedDetailData, setSelectedDetailData] = useState<any>(null);

  // Mock data - replace with actual API calls
  const mockData: QuestionnaireData = {
    classes: [
      {
        className: 'Grade 3A',
        totalStudents: 25,
        averagePreTest: 6.2,
        averagePostTest: 8.1,
        averageImprovement: 30.6,
        students: [
          {
            id: 's1',
            name: 'Emma Johnson',
            grade: '3A',
            preTestScore: 5.5,
            postTestScore: 8.2,
            happinessImprovement: 49.1,
            emotionalDistribution: { happy: 40, neutral: 30, sad: 15, anxious: 10, excited: 5 }
          },
          {
            id: 's2',
            name: 'Liam Smith',
            grade: '3A',
            preTestScore: 7.1,
            postTestScore: 8.8,
            happinessImprovement: 23.9,
            emotionalDistribution: { happy: 50, neutral: 25, sad: 10, anxious: 10, excited: 5 }
          },
          {
            id: 's3',
            name: 'Sophia Davis',
            grade: '3A',
            preTestScore: 4.8,
            postTestScore: 7.5,
            happinessImprovement: 56.3,
            emotionalDistribution: { happy: 35, neutral: 35, sad: 20, anxious: 5, excited: 5 }
          }
        ]
      },
      {
        className: 'Grade 4B',
        totalStudents: 28,
        averagePreTest: 6.8,
        averagePostTest: 8.5,
        averageImprovement: 25.0,
        students: [
          {
            id: 's4',
            name: 'Noah Wilson',
            grade: '4B',
            preTestScore: 6.2,
            postTestScore: 8.9,
            happinessImprovement: 43.5,
            emotionalDistribution: { happy: 45, neutral: 30, sad: 15, anxious: 5, excited: 5 }
          },
          {
            id: 's5',
            name: 'Olivia Brown',
            grade: '4B',
            preTestScore: 8.1,
            postTestScore: 9.2,
            happinessImprovement: 13.6,
            emotionalDistribution: { happy: 55, neutral: 25, sad: 10, anxious: 5, excited: 5 }
          }
        ]
      }
    ],
    overallStats: {
      totalStudents: 53,
      averageHappinessBefore: 6.5,
      averageHappinessAfter: 8.3,
      overallImprovement: 27.7
    }
  };

  useEffect(() => {
    // Simulate API call
    const fetchData = async () => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1000));
      setData(mockData);
      setLoading(false);
    };
    fetchData();
  }, []);

  const getCurrentClassData = () => {
    if (selectedClass === 'all') {
      return data?.classes.reduce((acc, cls) => ({
        className: 'All Classes',
        totalStudents: acc.totalStudents + cls.totalStudents,
        averagePreTest: (acc.averagePreTest * acc.totalStudents + cls.averagePreTest * cls.totalStudents) / (acc.totalStudents + cls.totalStudents),
        averagePostTest: (acc.averagePostTest * acc.totalStudents + cls.averagePostTest * cls.totalStudents) / (acc.totalStudents + cls.totalStudents),
        averageImprovement: (acc.averageImprovement * acc.totalStudents + cls.averageImprovement * cls.totalStudents) / (acc.totalStudents + cls.totalStudents),
        students: [...acc.students, ...cls.students]
      }), {
        className: 'All Classes',
        totalStudents: 0,
        averagePreTest: 0,
        averagePostTest: 0,
        averageImprovement: 0,
        students: []
      });
    }
    return data?.classes.find(cls => cls.className === selectedClass);
  };

  const getStudentData = (studentId: string) => {
    return data?.classes.flatMap(cls => cls.students).find(student => student.id === studentId);
  };

  // Click handlers for interactive elements
  const handleDetailClick = (type: 'student' | 'class' | 'overall', data: any) => {
    setSelectedDetailType(type);
    setSelectedDetailData(data);
    setShowDetailModal(true);
  };

  const handleExportClick = () => {
    setShowExportModal(true);
  };

  const handleAnalysisClick = () => {
    setShowAnalysisModal(true);
  };

  const handleReportClick = () => {
    setShowReportModal(true);
  };

  const handleExportReport = (format: 'pdf' | 'csv' | 'excel') => {
    // Mock export functionality
    console.log(`Exporting report as ${format}`);
    alert(`Exporting report as ${format.toUpperCase()}. This would download the file.`);
    setShowExportModal(false);
  };

  const handleShareReport = () => {
    // Mock share functionality
    if (navigator.share) {
      navigator.share({
        title: 'Questionnaire Report',
        text: 'Check out this questionnaire analysis report',
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Report link copied to clipboard!');
    }
  };

  const EmotionalDistributionChart = ({ data, title, studentName }: { data: any, title: string, studentName?: string }) => {
    const colors = {
      happy: '#10B981',
      neutral: '#6B7280',
      sad: '#EF4444',
      anxious: '#F59E0B',
      excited: '#8B5CF6'
    };

    const total = Object.values(data).reduce((sum: number, val: any) => sum + val, 0);

    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
          {studentName && (
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span className="text-sm font-medium text-gray-600">{studentName}</span>
            </div>
          )}
        </div>
        
        <div className="space-y-3">
          {Object.entries(data).map(([emotion, value]: [string, any]) => (
            <div key={emotion} className="flex items-center space-x-3">
              <div className="flex items-center space-x-2 w-20">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: colors[emotion as keyof typeof colors] }}
                ></div>
                <span className="text-sm font-medium text-gray-600 capitalize">{emotion}</span>
              </div>
              <div className="flex-1 bg-gray-200 rounded-full h-2">
                <div 
                  className="h-2 rounded-full transition-all duration-500"
                  style={{ 
                    width: `${(value / total) * 100}%`,
                    backgroundColor: colors[emotion as keyof typeof colors]
                  }}
                ></div>
              </div>
              <span className="text-sm font-semibold text-gray-900 w-12 text-right">{value}%</span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const BarChart = ({ preTest, postTest, studentName }: { preTest: number, postTest: number, studentName?: string }) => {
    const maxValue = Math.max(preTest, postTest, 10);
    
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Happiness Score Comparison</h3>
          {studentName && (
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              <span className="text-sm font-medium text-gray-600">{studentName}</span>
            </div>
          )}
        </div>
        
        <div className="space-y-4">
          <div className="flex items-center space-x-4">
            <div className="w-20 text-sm font-medium text-gray-600">Pre-Test</div>
            <div className="flex-1 bg-gray-200 rounded-full h-6 relative">
              <div 
                className="bg-gradient-to-r from-red-400 to-red-500 h-6 rounded-full flex items-center justify-end pr-2 transition-all duration-500"
                style={{ width: `${(preTest / maxValue) * 100}%` }}
              >
                <span className="text-white text-xs font-semibold">{preTest.toFixed(1)}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="w-20 text-sm font-medium text-gray-600">Post-Test</div>
            <div className="flex-1 bg-gray-200 rounded-full h-6 relative">
              <div 
                className="bg-gradient-to-r from-green-400 to-green-500 h-6 rounded-full flex items-center justify-end pr-2 transition-all duration-500"
                style={{ width: `${(postTest / maxValue) * 100}%` }}
              >
                <span className="text-white text-xs font-semibold">{postTest.toFixed(1)}</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-4 flex items-center justify-center space-x-6">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span className="text-sm text-gray-600">Pre-Test</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-sm text-gray-600">Post-Test</span>
          </div>
        </div>
      </div>
    );
  };

  const StudentCard = ({ student }: { student: Student }) => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 cursor-pointer group">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h4 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">{student.name}</h4>
          <p className="text-sm text-gray-600">Grade {student.grade}</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-green-600">+{student.happinessImprovement.toFixed(1)}%</div>
          <div className="text-xs text-gray-500">Improvement</div>
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div 
          className="text-center p-3 bg-red-50 rounded-lg hover:bg-red-100 transition-colors cursor-pointer"
          onClick={() => handleDetailClick('student', { ...student, type: 'preTest' })}
        >
          <div className="text-lg font-bold text-red-600">{student.preTestScore.toFixed(1)}</div>
          <div className="text-xs text-gray-600">Pre-Test</div>
        </div>
        <div 
          className="text-center p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-colors cursor-pointer"
          onClick={() => handleDetailClick('student', { ...student, type: 'postTest' })}
        >
          <div className="text-lg font-bold text-green-600">{student.postTestScore.toFixed(1)}</div>
          <div className="text-xs text-gray-600">Post-Test</div>
        </div>
      </div>
      
      <div className="flex space-x-2">
        <button
          onClick={() => setSelectedStudent(student.id)}
          className="flex-1 py-2 px-4 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors text-sm font-medium"
        >
          <Eye className="h-4 w-4 inline mr-1" />
          View Analysis
        </button>
        <button
          onClick={() => handleDetailClick('student', student)}
          className="flex-1 py-2 px-4 bg-gray-50 text-gray-600 rounded-lg hover:bg-gray-100 transition-colors text-sm font-medium"
        >
          <FileText className="h-4 w-4 inline mr-1" />
          Details
        </button>
      </div>
    </div>
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading questionnaire data...</p>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-8 w-8 text-red-600 mx-auto mb-4" />
          <p className="text-gray-600">Failed to load questionnaire data</p>
        </div>
      </div>
    );
  }

  const currentClassData = getCurrentClassData();
  const selectedStudentData = selectedStudent ? getStudentData(selectedStudent) : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      {/* Modern Header */}
      <div className="bg-white/80 backdrop-blur-sm shadow-xl border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-6 lg:space-y-0">
              <div className="flex items-center space-x-4">
                <div className="p-4 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl shadow-lg">
                  <ClipboardList className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h1 className="text-4xl font-bold bg-gradient-to-r from-slate-900 to-slate-700 bg-clip-text text-transparent">
                    Pre & Post Test Questionnaire
                  </h1>
                  <p className="text-slate-600 mt-2 text-lg leading-relaxed">
                    Track student happiness and emotional well-being through art therapy
                  </p>
                  <div className="flex items-center space-x-4 mt-3">
                    <div className="flex items-center space-x-2 text-sm text-slate-500">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                      <span>Live Data</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-slate-500">
                      <Heart className="h-4 w-4" />
                      <span>Emotional Analysis</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-3">
                <select
                  value={selectedClass}
                  onChange={(e) => setSelectedClass(e.target.value)}
                  className="px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white shadow-sm font-medium"
                >
                  <option value="all">All Classes</option>
                  {data.classes.map(cls => (
                    <option key={cls.className} value={cls.className}>{cls.className}</option>
                  ))}
                </select>
                
                <div className="flex space-x-3">
                  <button 
                    onClick={handleAnalysisClick}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-xl hover:from-emerald-600 hover:to-emerald-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    <BarChart3 className="h-5 w-5" />
                    <span className="font-semibold">Analysis</span>
                  </button>
                  <button 
                    onClick={handleReportClick}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-xl hover:from-purple-600 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    <FileText className="h-5 w-5" />
                    <span className="font-semibold">Report</span>
                  </button>
                  <button 
                    onClick={handleExportClick}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl hover:from-blue-600 hover:to-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    <Download className="h-5 w-5" />
                    <span className="font-semibold">Export</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Modern Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          <div 
            className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-white/20 p-8 hover:shadow-2xl transition-all duration-500 cursor-pointer group relative overflow-hidden"
            onClick={() => handleDetailClick('overall', { type: 'totalStudents', data: data.overallStats })}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-blue-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-6">
                <div className="p-4 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110">
                  <Users className="h-7 w-7 text-white" />
                </div>
                <div className="text-right">
                  <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
                </div>
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-600 group-hover:text-blue-600 transition-colors duration-300 mb-2">Total Students</p>
                <p className="text-4xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors duration-300">{data.overallStats.totalStudents}</p>
                <div className="mt-4 h-1 bg-slate-200 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full w-4/5 transition-all duration-1000"></div>
                </div>
              </div>
            </div>
          </div>
          
          <div 
            className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-white/20 p-8 hover:shadow-2xl transition-all duration-500 cursor-pointer group relative overflow-hidden"
            onClick={() => handleDetailClick('overall', { type: 'happinessBefore', data: data.overallStats })}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-red-500/5 to-red-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-6">
                <div className="p-4 bg-gradient-to-br from-red-500 to-red-600 rounded-2xl shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110">
                  <TrendingDown className="h-7 w-7 text-white" />
                </div>
                <div className="text-right">
                  <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                </div>
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-600 group-hover:text-red-600 transition-colors duration-300 mb-2">Avg. Happiness Before</p>
                <p className="text-4xl font-bold text-red-600 group-hover:text-red-700 transition-colors duration-300">{data.overallStats.averageHappinessBefore.toFixed(1)}</p>
                <div className="mt-4 h-1 bg-slate-200 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-red-500 to-red-600 rounded-full w-3/5 transition-all duration-1000"></div>
                </div>
              </div>
            </div>
          </div>
          
          <div 
            className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-white/20 p-8 hover:shadow-2xl transition-all duration-500 cursor-pointer group relative overflow-hidden"
            onClick={() => handleDetailClick('overall', { type: 'happinessAfter', data: data.overallStats })}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-emerald-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-6">
                <div className="p-4 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110">
                  <TrendingUp className="h-7 w-7 text-white" />
                </div>
                <div className="text-right">
                  <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse"></div>
                </div>
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-600 group-hover:text-emerald-600 transition-colors duration-300 mb-2">Avg. Happiness After</p>
                <p className="text-4xl font-bold text-emerald-600 group-hover:text-emerald-700 transition-colors duration-300">{data.overallStats.averageHappinessAfter.toFixed(1)}</p>
                <div className="mt-4 h-1 bg-slate-200 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-emerald-500 to-emerald-600 rounded-full w-4/5 transition-all duration-1000"></div>
                </div>
              </div>
            </div>
          </div>
          
          <div 
            className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-white/20 p-8 hover:shadow-2xl transition-all duration-500 cursor-pointer group relative overflow-hidden"
            onClick={() => handleDetailClick('overall', { type: 'improvement', data: data.overallStats })}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-purple-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-6">
                <div className="p-4 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110">
                  <Heart className="h-7 w-7 text-white" />
                </div>
                <div className="text-right">
                  <div className="w-3 h-3 bg-purple-500 rounded-full animate-pulse"></div>
                </div>
              </div>
              <div>
                <p className="text-sm font-semibold text-slate-600 group-hover:text-purple-600 transition-colors duration-300 mb-2">Overall Improvement</p>
                <p className="text-4xl font-bold text-purple-600 group-hover:text-purple-700 transition-colors duration-300">+{data.overallStats.overallImprovement.toFixed(1)}%</p>
                <div className="mt-4 h-1 bg-slate-200 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-purple-500 to-purple-600 rounded-full w-5/6 transition-all duration-1000"></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modern Tabs */}
        <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-white/20 mb-10 overflow-hidden">
          <div className="border-b border-slate-200/50">
            <nav className="flex space-x-2 px-8 py-2">
              {[
                { id: 'overview', label: 'Overview', icon: BarChart3, color: 'blue' },
                { id: 'individual', label: 'Individual Analysis', icon: Users, color: 'emerald' },
                { id: 'comparison', label: 'Comparison', icon: Target, color: 'purple' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`group relative py-4 px-6 font-semibold text-sm flex items-center space-x-3 rounded-2xl transition-all duration-300 ${
                    activeTab === tab.id
                      ? `bg-gradient-to-r from-${tab.color}-500 to-${tab.color}-600 text-white shadow-lg shadow-${tab.color}-500/25`
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50/50'
                  }`}
                >
                  <div className={`p-2 rounded-lg transition-all duration-300 ${
                    activeTab === tab.id 
                      ? 'bg-white/20' 
                      : `bg-slate-100 group-hover:bg-${tab.color}-50`
                  }`}>
                    <tab.icon className={`h-5 w-5 transition-colors duration-300 ${
                      activeTab === tab.id 
                        ? 'text-white' 
                        : `text-slate-500 group-hover:text-${tab.color}-600`
                    }`} />
                  </div>
                  <span className="transition-colors duration-300">{tab.label}</span>
                  {activeTab === tab.id && (
                    <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-white rounded-full"></div>
                  )}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-8">
            {activeTab === 'overview' && currentClassData && (
              <div className="space-y-8">
                {/* Class Overview */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <BarChart 
                    preTest={currentClassData.averagePreTest} 
                    postTest={currentClassData.averagePostTest}
                    studentName={currentClassData.className}
                  />
                  <EmotionalDistributionChart 
                    data={{
                      happy: 45,
                      neutral: 30,
                      sad: 15,
                      anxious: 7,
                      excited: 3
                    }}
                    title="Overall Emotional Distribution"
                  />
                </div>

                {/* Students Grid */}
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-6">Student Performance</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {currentClassData.students.map(student => (
                      <StudentCard key={student.id} student={student} />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'individual' && !selectedStudentData && (
              <div className="text-center py-12">
                <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Select a Student</h3>
                <p className="text-gray-600 mb-6">Choose a student from the overview tab to view their individual analysis</p>
                <button
                  onClick={() => setActiveTab('overview')}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Go to Overview
                </button>
              </div>
            )}

            {activeTab === 'individual' && selectedStudentData && (
              <div className="space-y-8">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{selectedStudentData.name}</h3>
                  <p className="text-gray-600">Grade {selectedStudentData.grade}</p>
                </div>

                {/* Key Metrics Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="bg-gradient-to-r from-red-50 to-red-100 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-red-600">{selectedStudentData.preTestScore.toFixed(1)}</div>
                    <div className="text-sm text-gray-600">Pre-Test Score</div>
                  </div>
                  <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">{selectedStudentData.postTestScore.toFixed(1)}</div>
                    <div className="text-sm text-gray-600">Post-Test Score</div>
                  </div>
                  <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-blue-600">+{selectedStudentData.happinessImprovement.toFixed(1)}%</div>
                    <div className="text-sm text-gray-600">Improvement</div>
                  </div>
                  <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-purple-600">
                      {selectedStudentData.happinessImprovement > 30 ? 'Excellent' : 
                       selectedStudentData.happinessImprovement > 15 ? 'Good' : 'Needs Support'}
                    </div>
                    <div className="text-sm text-gray-600">Performance</div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <BarChart 
                    preTest={selectedStudentData.preTestScore} 
                    postTest={selectedStudentData.postTestScore}
                    studentName={selectedStudentData.name}
                  />
                  <EmotionalDistributionChart 
                    data={selectedStudentData.emotionalDistribution}
                    title="Emotional Distribution"
                    studentName={selectedStudentData.name}
                  />
                </div>

                {/* Detailed Analysis Section */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Progress Analysis</h4>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium text-gray-600">Score Change</span>
                        <span className="text-lg font-bold text-green-600">
                          +{(selectedStudentData.postTestScore - selectedStudentData.preTestScore).toFixed(1)} points
                        </span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium text-gray-600">Improvement Rate</span>
                        <span className="text-lg font-bold text-blue-600">
                          {selectedStudentData.happinessImprovement.toFixed(1)}%
                        </span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium text-gray-600">Performance Level</span>
                        <span className={`text-lg font-bold ${
                          selectedStudentData.happinessImprovement > 30 ? 'text-green-600' : 
                          selectedStudentData.happinessImprovement > 15 ? 'text-yellow-600' : 'text-red-600'
                        }`}>
                          {selectedStudentData.happinessImprovement > 30 ? 'High' : 
                           selectedStudentData.happinessImprovement > 15 ? 'Medium' : 'Low'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Emotional Insights</h4>
                    <div className="space-y-3">
                      {Object.entries(selectedStudentData.emotionalDistribution).map(([emotion, value]) => (
                        <div key={emotion} className="flex items-center justify-between">
                          <span className="text-sm font-medium text-gray-600 capitalize">{emotion}</span>
                          <div className="flex items-center space-x-2">
                            <div className="w-16 bg-gray-200 rounded-full h-2">
                              <div 
                                className="h-2 rounded-full bg-gradient-to-r from-blue-400 to-blue-500"
                                style={{ width: `${value}%` }}
                              ></div>
                            </div>
                            <span className="text-sm font-semibold text-gray-900 w-8">{value}%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Personalized Results with Recommendations */}
                <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-6">
                  <div className="text-center mb-6">
                    <h4 className="text-xl font-bold text-gray-900 mb-2">Personalized Results</h4>
                    <p className="text-gray-700">
                      <span className="font-bold text-blue-600">{selectedStudentData.name}</span>'s happiness improved by{' '}
                      <span className="font-bold text-green-600">+{selectedStudentData.happinessImprovement.toFixed(1)}%</span>
                    </p>
                    <p className="text-sm text-gray-600 mt-2">
                      From {selectedStudentData.preTestScore.toFixed(1)} to {selectedStudentData.postTestScore.toFixed(1)} out of 10
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="bg-white rounded-lg p-4">
                      <h5 className="font-semibold text-gray-900 mb-2">Recommendations</h5>
                      <ul className="text-sm text-gray-600 space-y-1">
                        {selectedStudentData.happinessImprovement > 30 ? (
                          <>
                            <li>• Continue current art therapy approach</li>
                            <li>• Consider advanced creative challenges</li>
                            <li>• Share success with peer group</li>
                          </>
                        ) : selectedStudentData.happinessImprovement > 15 ? (
                          <>
                            <li>• Increase session frequency</li>
                            <li>• Try different art mediums</li>
                            <li>• Focus on emotional expression</li>
                          </>
                        ) : (
                          <>
                            <li>• Additional one-on-one sessions</li>
                            <li>• Explore different art activities</li>
                            <li>• Consider counseling support</li>
                          </>
                        )}
                      </ul>
                    </div>
                    
                    <div className="bg-white rounded-lg p-4">
                      <h5 className="font-semibold text-gray-900 mb-2">Next Steps</h5>
                      <ul className="text-sm text-gray-600 space-y-1">
                        <li>• Schedule follow-up assessment</li>
                        <li>• Monitor emotional patterns</li>
                        <li>• Adjust therapy approach if needed</li>
                        <li>• Document progress regularly</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'comparison' && (
              <div className="space-y-8">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Pre-Test vs Post-Test Comparison</h3>
                  <p className="text-gray-600">Comprehensive analysis across all students</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Class Comparison</h4>
                    <div className="space-y-4">
                      {data.classes.map(cls => (
                        <div key={cls.className} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div>
                            <p className="font-medium text-gray-900">{cls.className}</p>
                            <p className="text-sm text-gray-600">{cls.totalStudents} students</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-green-600">+{cls.averageImprovement.toFixed(1)}%</p>
                            <p className="text-xs text-gray-500">improvement</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Top Performers</h4>
                    <div className="space-y-3">
                      {data.classes.flatMap(cls => cls.students)
                        .sort((a, b) => b.happinessImprovement - a.happinessImprovement)
                        .slice(0, 5)
                        .map((student, index) => (
                        <div key={student.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                              <span className="text-white text-sm font-bold">{index + 1}</span>
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">{student.name}</p>
                              <p className="text-sm text-gray-600">Grade {student.grade}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-green-600">+{student.happinessImprovement.toFixed(1)}%</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Detail Modal */}
      {showDetailModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">
                {selectedDetailType === 'student' ? 'Student Details' : 
                 selectedDetailType === 'class' ? 'Class Details' : 'Overall Statistics'}
              </h3>
              <button
                onClick={() => setShowDetailModal(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="p-6">
              {selectedDetailType === 'student' && selectedDetailData && (
                <div className="space-y-4">
                  <div className="text-center">
                    <h4 className="text-2xl font-bold text-gray-900">{selectedDetailData.name}</h4>
                    <p className="text-gray-600">Grade {selectedDetailData.grade}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-red-600">{selectedDetailData.preTestScore.toFixed(1)}</div>
                      <div className="text-sm text-gray-600">Pre-Test Score</div>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{selectedDetailData.postTestScore.toFixed(1)}</div>
                      <div className="text-sm text-gray-600">Post-Test Score</div>
                    </div>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg text-center">
                    <div className="text-2xl font-bold text-blue-600">+{selectedDetailData.happinessImprovement.toFixed(1)}%</div>
                    <div className="text-sm text-gray-600">Improvement</div>
                  </div>
                  <div className="space-y-2">
                    <h5 className="font-semibold text-gray-900">Emotional Distribution</h5>
                    {Object.entries(selectedDetailData.emotionalDistribution).map(([emotion, value]) => (
                      <div key={emotion} className="flex justify-between items-center">
                        <span className="capitalize text-gray-600">{emotion}</span>
                        <span className="font-semibold text-gray-900">{value as number}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {selectedDetailType === 'overall' && selectedDetailData && (
                <div className="space-y-4">
                  <div className="text-center">
                    <h4 className="text-2xl font-bold text-gray-900">Overall Statistics</h4>
                    <p className="text-gray-600">Comprehensive overview of all data</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{selectedDetailData.data.totalStudents}</div>
                      <div className="text-sm text-gray-600">Total Students</div>
                    </div>
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-red-600">{selectedDetailData.data.averageHappinessBefore.toFixed(1)}</div>
                      <div className="text-sm text-gray-600">Avg. Happiness Before</div>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{selectedDetailData.data.averageHappinessAfter.toFixed(1)}</div>
                      <div className="text-sm text-gray-600">Avg. Happiness After</div>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">+{selectedDetailData.data.overallImprovement.toFixed(1)}%</div>
                      <div className="text-sm text-gray-600">Overall Improvement</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">Export Report</h3>
              <button
                onClick={() => setShowExportModal(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-gray-600">Choose the format for your report export:</p>
              <div className="space-y-3">
                <button
                  onClick={() => handleExportReport('pdf')}
                  className="w-full flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <FileText className="h-6 w-6 text-red-600" />
                  <div className="text-left">
                    <div className="font-medium text-gray-900">PDF Report</div>
                    <div className="text-sm text-gray-600">Download as PDF document</div>
                  </div>
                </button>
                <button
                  onClick={() => handleExportReport('csv')}
                  className="w-full flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <FileText className="h-6 w-6 text-green-600" />
                  <div className="text-left">
                    <div className="font-medium text-gray-900">CSV Data</div>
                    <div className="text-sm text-gray-600">Download as CSV spreadsheet</div>
                  </div>
                </button>
                <button
                  onClick={() => handleExportReport('excel')}
                  className="w-full flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <FileText className="h-6 w-6 text-blue-600" />
                  <div className="text-left">
                    <div className="font-medium text-gray-900">Excel Workbook</div>
                    <div className="text-sm text-gray-600">Download as Excel file</div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Analysis Modal */}
      {showAnalysisModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">Comprehensive Analysis</h3>
              <button
                onClick={() => setShowAnalysisModal(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-6 rounded-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Key Insights</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li>• {data?.overallStats.totalStudents} students participated in the program</li>
                    <li>• Average improvement of {data?.overallStats.overallImprovement.toFixed(1)}% across all students</li>
                    <li>• {data?.classes.length} classes showed positive results</li>
                    <li>• Highest individual improvement: {Math.max(...(data?.classes.flatMap(cls => cls.students).map(s => s.happinessImprovement) || [0])).toFixed(1)}%</li>
                  </ul>
                </div>
                <div className="bg-gradient-to-r from-green-50 to-green-100 p-6 rounded-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Recommendations</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Continue current art therapy approach</li>
                    <li>• Focus on students with lower improvement rates</li>
                    <li>• Increase session frequency for better results</li>
                    <li>• Consider peer mentoring programs</li>
                  </ul>
                </div>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Performance Trends</h4>
                <div className="space-y-3">
                  {data?.classes.map(cls => (
                    <div key={cls.className} className="flex justify-between items-center p-3 bg-white rounded-lg">
                      <span className="font-medium text-gray-900">{cls.className}</span>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-600">{cls.totalStudents} students</span>
                        <span className="font-bold text-green-600">+{cls.averageImprovement.toFixed(1)}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">Report Viewer</h3>
              <div className="flex items-center space-x-2">
                <button
                  onClick={handleShareReport}
                  className="flex items-center space-x-2 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors"
                >
                  <Share2 className="h-4 w-4" />
                  <span>Share</span>
                </button>
                <button
                  onClick={() => window.print()}
                  className="flex items-center space-x-2 px-3 py-2 bg-gray-50 text-gray-600 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <Printer className="h-4 w-4" />
                  <span>Print</span>
                </button>
                <button
                  onClick={() => setShowReportModal(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="space-y-6">
                <div className="text-center">
                  <h4 className="text-2xl font-bold text-gray-900 mb-2">Questionnaire Analysis Report</h4>
                  <p className="text-gray-600">Generated on {new Date().toLocaleDateString()}</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="bg-blue-50 p-4 rounded-lg text-center">
                    <div className="text-3xl font-bold text-blue-600">{data?.overallStats.totalStudents}</div>
                    <div className="text-sm text-gray-600">Total Students</div>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg text-center">
                    <div className="text-3xl font-bold text-green-600">+{data?.overallStats.overallImprovement.toFixed(1)}%</div>
                    <div className="text-sm text-gray-600">Overall Improvement</div>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg text-center">
                    <div className="text-3xl font-bold text-purple-600">{data?.classes.length}</div>
                    <div className="text-sm text-gray-600">Classes Analyzed</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h5 className="text-lg font-semibold text-gray-900">Class Performance Summary</h5>
                  <div className="space-y-3">
                    {data?.classes.map(cls => (
                      <div key={cls.className} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                        <div>
                          <div className="font-medium text-gray-900">{cls.className}</div>
                          <div className="text-sm text-gray-600">{cls.totalStudents} students</div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-green-600">+{cls.averageImprovement.toFixed(1)}%</div>
                          <div className="text-xs text-gray-500">improvement</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-lg">
                  <h5 className="text-lg font-semibold text-gray-900 mb-4">Key Findings</h5>
                  <ul className="space-y-2 text-gray-700">
                    <li>• All classes showed positive improvement in happiness scores</li>
                    <li>• Average pre-test score: {data?.overallStats.averageHappinessBefore.toFixed(1)}/10</li>
                    <li>• Average post-test score: {data?.overallStats.averageHappinessAfter.toFixed(1)}/10</li>
                    <li>• The art therapy program demonstrates measurable positive impact</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
