import { useEffect, useState } from 'react';
import { getAssignedTests as getAssignedTestsApi } from '../lib/api';
import { 
  Copy, 
  ExternalLink, 
  Users, 
  Calendar, 
  ToggleLeft, 
  ToggleRight,
  Eye,
  RefreshCw,
  AlertCircle
} from 'lucide-react';

interface AssignedTestItem {
  id: string;
  title: string;
  publicUrl: string;
  status: 'active' | 'inactive' | 'expired';
  publishedAt: string;
  responseCount: number;
}

export default function AssignedTests() {
  const [tests, setTests] = useState<AssignedTestItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [togglingTest, setTogglingTest] = useState<string | null>(null);

  useEffect(() => {
    fetchAssignedTests();
  }, []);

  const fetchAssignedTests = async () => {
    try {
      setLoading(true);
      setError(null);
      const { tests: assigned } = await getAssignedTestsApi();
      const mapped: AssignedTestItem[] = assigned.map((t: any) => ({
        id: t.id,
        title: `${t.name} (${String(t.type).toUpperCase()})`,
        publicUrl: `${window.location.origin}/public/test/${t.linkHash || (t.url ? String(t.url).split('/').pop() : '')}`,
        status: t.status === 'active' ? 'active' : t.status === 'expired' ? 'expired' : 'inactive',
        publishedAt: t.startTime || t.createdAt,
        responseCount: 0,
      }));
      setTests(mapped);
    } catch (err: any) {
      console.error('Error fetching assigned tests:', err);
      setError(err.response?.data?.message || 'Failed to load assigned tests');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleStatus = async (testId: string, currentStatus: string) => {
    try {
      setTogglingTest(testId);
      const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
      
      // Update local state
      setTests(prev => prev.map(test => 
        test.id === testId 
          ? { ...test, status: newStatus as 'active' | 'inactive' }
          : test
      ));
    } catch (err: any) {
      console.error('Error toggling test status:', err);
      alert(err.response?.data?.message || 'Failed to update test status');
    } finally {
      setTogglingTest(null);
    }
  };

  const handleCopyUrl = async (url: string) => {
    try {
      await navigator.clipboard.writeText(url);
      alert('URL copied to clipboard!');
    } catch (err) {
      console.error('Failed to copy URL:', err);
      alert('Failed to copy URL');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading assigned tests...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-8 w-8 text-red-600 mx-auto mb-4" />
          <p className="text-gray-600 mb-4">{error}</p>
          <button
            onClick={fetchAssignedTests}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Assigned Tests</h1>
          <p className="text-gray-600 mt-2">Manage and view your published questionnaires</p>
        </div>

        {/* Tests Grid */}
        {tests.length === 0 ? (
          <div className="text-center py-12">
            <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Tests Assigned</h3>
            <p className="text-gray-500">No questionnaires have been published to your school yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tests.map((test) => (
              <div key={test.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                {/* Test Header */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-1">{test.title}</h3>
                  </div>
                  <div className="ml-4">
                    <button
                      onClick={() => handleToggleStatus(test.id, test.status)}
                      disabled={togglingTest === test.id}
                      className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                        test.status === 'active'
                          ? 'bg-green-100 text-green-800 hover:bg-green-200'
                          : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                      } ${togglingTest === test.id ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      {togglingTest === test.id ? (
                        <RefreshCw className="h-4 w-4 animate-spin" />
                      ) : test.status === 'active' ? (
                        <ToggleRight className="h-4 w-4" />
                      ) : (
                        <ToggleLeft className="h-4 w-4" />
                      )}
                      <span>{test.status === 'active' ? 'Active' : 'Inactive'}</span>
                    </button>
                  </div>
                </div>

                {/* Test Stats */}
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <Users className="h-5 w-5 text-blue-600 mx-auto mb-1" />
                    <div className="text-lg font-bold text-blue-600">{test.responseCount}</div>
                    <div className="text-xs text-gray-600">Responses</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <Calendar className="h-5 w-5 text-gray-600 mx-auto mb-1" />
                    <div className="text-sm font-medium text-gray-900">
                      {formatDate(test.publishedAt)}
                    </div>
                    <div className="text-xs text-gray-600">Published</div>
                  </div>
                </div>

                {/* Public URL */}
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Public URL
                  </label>
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={test.publicUrl}
                      readOnly
                      className="flex-1 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 text-sm"
                    />
                    <button
                      onClick={() => handleCopyUrl(test.publicUrl)}
                      className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
                      title="Copy URL"
                    >
                      <Copy className="h-4 w-4" />
                    </button>
                    <a
                      href={test.publicUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
                      title="Open in new tab"
                    >
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex space-x-2">
                  <button
                    onClick={() => window.open(`/school-dashboard/results/${test.id}`, '_blank')}
                    className="flex-1 flex items-center justify-center space-x-2 py-2 px-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Eye className="h-4 w-4" />
                    <span>View Results</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
