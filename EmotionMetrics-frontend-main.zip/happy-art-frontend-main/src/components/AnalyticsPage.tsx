import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Download,
  RefreshCw,
  AlertCircle,
  CheckCircle,
  Star,
  Target,
  Award,
  Users,
  Heart,
  Calendar,
  Activity,
  PieChart,
  LineChart,
  ArrowUp,
  ArrowDown,
  Minus,
  Eye,
  EyeOff,
  Filter,
  Search,
  X,
  FileText,
  BarChart,
  Share2,
  Printer,
  Settings,
  Info
} from 'lucide-react';

// Types for analytics data
interface StudentAnalytics {
  id: string;
  name: string;
  grade: string;
  preTestScore: number;
  postTestScore: number;
  happinessImprovement: number;
  emotionalTrend: {
    week1: number;
    week2: number;
    week3: number;
    week4: number;
  };
  participationRate: number;
  artSessionCount: number;
  lastSessionDate: string;
}

interface ClassAnalytics {
  className: string;
  totalStudents: number;
  averagePreTest: number;
  averagePostTest: number;
  averageImprovement: number;
  students: StudentAnalytics[];
  trends: {
    weeklyImprovement: number[];
    participationRate: number;
    sessionCompletion: number;
  };
}

interface AnalyticsData {
  classes: ClassAnalytics[];
  overallStats: {
    totalStudents: number;
    averageHappinessBefore: number;
    averageHappinessAfter: number;
    overallImprovement: number;
    totalSessions: number;
    averageParticipation: number;
  };
  timeRange: {
    startDate: string;
    endDate: string;
  };
}

export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedClass, setSelectedClass] = useState<string>('all');
  const [selectedStudent, setSelectedStudent] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<'overview' | 'detailed' | 'comparison'>('overview');
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'quarter' | 'year'>('month');
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showAnalysisModal, setShowAnalysisModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [selectedDetailType, setSelectedDetailType] = useState<'student' | 'class' | 'overall' | 'trend' | null>(null);
  const [selectedDetailData, setSelectedDetailData] = useState<any>(null);

  // Mock data - replace with actual API calls
  const mockData: AnalyticsData = {
    classes: [
      {
        className: 'Grade 3A',
        totalStudents: 25,
        averagePreTest: 6.2,
        averagePostTest: 8.1,
        averageImprovement: 30.6,
        trends: {
          weeklyImprovement: [15, 22, 28, 30],
          participationRate: 92,
          sessionCompletion: 88
        },
        students: [
          {
            id: 's1',
            name: 'Emma Johnson',
            grade: '3A',
            preTestScore: 5.5,
            postTestScore: 8.2,
            happinessImprovement: 49.1,
            emotionalTrend: { week1: 5.5, week2: 6.8, week3: 7.4, week4: 8.2 },
            participationRate: 95,
            artSessionCount: 12,
            lastSessionDate: '2024-01-15'
          },
          {
            id: 's2',
            name: 'Liam Smith',
            grade: '3A',
            preTestScore: 7.1,
            postTestScore: 8.8,
            happinessImprovement: 23.9,
            emotionalTrend: { week1: 7.1, week2: 7.5, week3: 8.1, week4: 8.8 },
            participationRate: 100,
            artSessionCount: 12,
            lastSessionDate: '2024-01-15'
          },
          {
            id: 's3',
            name: 'Sophia Davis',
            grade: '3A',
            preTestScore: 4.8,
            postTestScore: 7.5,
            happinessImprovement: 56.3,
            emotionalTrend: { week1: 4.8, week2: 5.9, week3: 6.7, week4: 7.5 },
            participationRate: 88,
            artSessionCount: 10,
            lastSessionDate: '2024-01-12'
          }
        ]
      },
      {
        className: 'Grade 4B',
        totalStudents: 28,
        averagePreTest: 6.8,
        averagePostTest: 8.5,
        averageImprovement: 25.0,
        trends: {
          weeklyImprovement: [12, 18, 22, 25],
          participationRate: 89,
          sessionCompletion: 85
        },
        students: [
          {
            id: 's4',
            name: 'Noah Wilson',
            grade: '4B',
            preTestScore: 6.2,
            postTestScore: 8.9,
            happinessImprovement: 43.5,
            emotionalTrend: { week1: 6.2, week2: 7.1, week3: 8.0, week4: 8.9 },
            participationRate: 92,
            artSessionCount: 11,
            lastSessionDate: '2024-01-14'
          },
          {
            id: 's5',
            name: 'Olivia Brown',
            grade: '4B',
            preTestScore: 8.1,
            postTestScore: 9.2,
            happinessImprovement: 13.6,
            emotionalTrend: { week1: 8.1, week2: 8.4, week3: 8.8, week4: 9.2 },
            participationRate: 100,
            artSessionCount: 12,
            lastSessionDate: '2024-01-15'
          }
        ]
      }
    ],
    overallStats: {
      totalStudents: 53,
      averageHappinessBefore: 6.5,
      averageHappinessAfter: 8.3,
      overallImprovement: 27.7,
      totalSessions: 156,
      averageParticipation: 90.5
    },
    timeRange: {
      startDate: '2024-01-01',
      endDate: '2024-01-31'
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 1000));
      setData(mockData);
      setLoading(false);
    };
    fetchData();
  }, [timeRange]);

  const getCurrentClassData = () => {
    if (selectedClass === 'all') {
      return data?.classes.reduce((acc, cls) => ({
        className: 'All Classes',
        totalStudents: acc.totalStudents + cls.totalStudents,
        averagePreTest: (acc.averagePreTest * acc.totalStudents + cls.averagePreTest * cls.totalStudents) / (acc.totalStudents + cls.totalStudents),
        averagePostTest: (acc.averagePostTest * acc.totalStudents + cls.averagePostTest * cls.totalStudents) / (acc.totalStudents + cls.totalStudents),
        averageImprovement: (acc.averageImprovement * acc.totalStudents + cls.averageImprovement * cls.totalStudents) / (acc.totalStudents + cls.totalStudents),
        trends: {
          weeklyImprovement: [0, 0, 0, 0],
          participationRate: 0,
          sessionCompletion: 0
        },
        students: [...acc.students, ...cls.students]
      }), {
        className: 'All Classes',
        totalStudents: 0,
        averagePreTest: 0,
        averagePostTest: 0,
        averageImprovement: 0,
        trends: { weeklyImprovement: [0, 0, 0, 0], participationRate: 0, sessionCompletion: 0 },
        students: []
      });
    }
    return data?.classes.find(cls => cls.className === selectedClass);
  };

  const getStudentData = (studentId: string) => {
    return data?.classes.flatMap(cls => cls.students).find(student => student.id === studentId);
  };

  // Click handlers for interactive elements
  const handleDetailClick = (type: 'student' | 'class' | 'overall' | 'trend', data: any) => {
    setSelectedDetailType(type);
    setSelectedDetailData(data);
    setShowDetailModal(true);
  };

  const handleExportClick = () => {
    setShowExportModal(true);
  };

  const handleAnalysisClick = () => {
    setShowAnalysisModal(true);
  };

  const handleReportClick = () => {
    setShowReportModal(true);
  };

  const handleSettingsClick = () => {
    setShowSettingsModal(true);
  };

  const handleExportReport = (format: 'pdf' | 'csv' | 'excel' | 'json') => {
    // Mock export functionality
    console.log(`Exporting analytics report as ${format}`);
    alert(`Exporting analytics report as ${format.toUpperCase()}. This would download the file.`);
    setShowExportModal(false);
  };

  const handleShareReport = () => {
    // Mock share functionality
    if (navigator.share) {
      navigator.share({
        title: 'Analytics Report',
        text: 'Check out this comprehensive analytics report',
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Analytics report link copied to clipboard!');
    }
  };

  const ComparisonChart = ({ data }: { data: ClassAnalytics }) => {
    const maxValue = Math.max(data.averagePreTest, data.averagePostTest, 10);
    
    return (
      <div 
        className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 cursor-pointer group"
        onClick={() => handleDetailClick('class', data)}
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Pre-Test vs Post-Test Comparison</h3>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span className="text-sm font-medium text-gray-600">{data.className}</span>
          </div>
        </div>
        
        {/* Chart with X-axis and Y-axis labels */}
        <div className="mb-6">
          <div className="flex items-end justify-center space-x-8 h-64">
            {/* Y-axis label */}
            <div className="flex flex-col items-center justify-center h-full">
              <div className="transform -rotate-90 text-sm font-medium text-gray-600 whitespace-nowrap">
                Avg. Happiness Score (%)
              </div>
            </div>
            
            {/* Chart bars */}
            <div className="flex items-end space-x-8">
              {/* Pre-Test Bar */}
              <div className="flex flex-col items-center">
                <div className="w-16 h-48 bg-gray-100 rounded-t-lg relative flex items-end">
                  <div 
                    className="w-full bg-gradient-to-t from-red-400 to-red-500 rounded-t-lg transition-all duration-1000 flex items-center justify-center"
                    style={{ height: `${(data.averagePreTest / maxValue) * 100}%` }}
                  >
                    <span className="text-white text-sm font-semibold transform -rotate-90 whitespace-nowrap">
                      {data.averagePreTest.toFixed(1)}
                    </span>
                  </div>
                </div>
                <div className="mt-2 text-sm font-medium text-gray-600">Pre-Test</div>
              </div>
              
              {/* Post-Test Bar */}
              <div className="flex flex-col items-center">
                <div className="w-16 h-48 bg-gray-100 rounded-t-lg relative flex items-end">
                  <div 
                    className="w-full bg-gradient-to-t from-green-400 to-green-500 rounded-t-lg transition-all duration-1000 flex items-center justify-center"
                    style={{ height: `${(data.averagePostTest / maxValue) * 100}%` }}
                  >
                    <span className="text-white text-sm font-semibold transform -rotate-90 whitespace-nowrap">
                      {data.averagePostTest.toFixed(1)}
                    </span>
                  </div>
                </div>
                <div className="mt-2 text-sm font-medium text-gray-600">Post-Test</div>
              </div>
            </div>
          </div>
          
          {/* X-axis label */}
          <div className="text-center mt-4">
            <div className="text-sm font-medium text-gray-600">Pre-test vs Post-test</div>
          </div>
        </div>
        
        {/* Highlight: % Increase in Happiness Score */}
        <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-lg p-4 mb-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600 mb-1">
              +{data.averageImprovement.toFixed(1)}%
            </div>
            <div className="text-sm font-medium text-gray-700">
              % Increase in Happiness Score
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-center space-x-8">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-red-500 rounded-full"></div>
            <span className="text-sm text-gray-600">Pre-Test</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-4 bg-green-500 rounded-full"></div>
            <span className="text-sm text-gray-600">Post-Test</span>
          </div>
        </div>
      </div>
    );
  };

  const TrendChart = ({ student }: { student: StudentAnalytics }) => {
    const weeks = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
    const values = [student.emotionalTrend.week1, student.emotionalTrend.week2, student.emotionalTrend.week3, student.emotionalTrend.week4];
    const maxValue = Math.max(...values, 10);
    
    return (
      <div 
        className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 cursor-pointer group"
        onClick={() => handleDetailClick('trend', { student, type: 'weekly' })}
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">Happiness Trend</h3>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span className="text-sm font-medium text-gray-600">{student.name}</span>
          </div>
        </div>
        
        <div className="space-y-4">
          {weeks.map((week, index) => (
            <div key={week} className="flex items-center space-x-4">
              <div className="w-16 text-sm font-medium text-gray-600">{week}</div>
              <div className="flex-1 bg-gray-200 rounded-full h-6 relative">
                <div 
                  className="bg-gradient-to-r from-blue-400 to-blue-500 h-6 rounded-full flex items-center justify-end pr-2 transition-all duration-500"
                  style={{ width: `${(values[index] / maxValue) * 100}%` }}
                >
                  <span className="text-white text-xs font-semibold">{values[index].toFixed(1)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const IndividualStudentCard = ({ student }: { student: StudentAnalytics }) => {
    const handleDownloadReport = () => {
      // Create a simple text report
      const report = `
HAPPINESS SCORE REPORT
=====================

Student: ${student.name}
Grade: ${student.grade}

PRE-TEST vs POST-TEST ANALYSIS
------------------------------
Pre-Test Score: ${student.preTestScore.toFixed(1)}/10
Post-Test Score: ${student.postTestScore.toFixed(1)}/10

YOUR HAPPINESS IMPROVED BY +${student.happinessImprovement.toFixed(1)}%

ADDITIONAL METRICS
------------------
Participation Rate: ${student.participationRate}%
Art Sessions Completed: ${student.artSessionCount}
Last Session: ${new Date(student.lastSessionDate).toLocaleDateString()}

WEEKLY PROGRESS
---------------
Week 1: ${student.emotionalTrend.week1.toFixed(1)}/10
Week 2: ${student.emotionalTrend.week2.toFixed(1)}/10
Week 3: ${student.emotionalTrend.week3.toFixed(1)}/10
Week 4: ${student.emotionalTrend.week4.toFixed(1)}/10

Generated on: ${new Date().toLocaleDateString()}
      `.trim();

      // Create and download the file
      const blob = new Blob([report], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${student.name.replace(/\s+/g, '_')}_Happiness_Report.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    };

    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 group">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h4 className="text-lg font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">{student.name}</h4>
            <p className="text-sm text-gray-600">Grade {student.grade}</p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-green-600 group-hover:text-green-700 transition-colors">+{student.happinessImprovement.toFixed(1)}%</div>
            <div className="text-xs text-gray-500">Improvement</div>
          </div>
        </div>
        
        {/* Student-specific delta message */}
        <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-3 mb-4">
          <div className="text-center">
            <div className="text-sm font-medium text-gray-700">
              <span className="font-bold text-blue-600">{student.name}</span>'s happiness improved by{' '}
              <span className="font-bold text-green-600">+{student.happinessImprovement.toFixed(1)}%</span>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div 
            className="text-center p-3 bg-red-50 rounded-lg hover:bg-red-100 transition-colors cursor-pointer"
            onClick={() => handleDetailClick('student', { ...student, type: 'preTest' })}
          >
            <div className="text-lg font-bold text-red-600">{student.preTestScore.toFixed(1)}</div>
            <div className="text-xs text-gray-600">Pre-Test</div>
          </div>
          <div 
            className="text-center p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-colors cursor-pointer"
            onClick={() => handleDetailClick('student', { ...student, type: 'postTest' })}
          >
            <div className="text-lg font-bold text-green-600">{student.postTestScore.toFixed(1)}</div>
            <div className="text-xs text-gray-600">Post-Test</div>
          </div>
          <div 
            className="text-center p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors cursor-pointer"
            onClick={() => handleDetailClick('student', { ...student, type: 'participation' })}
          >
            <div className="text-lg font-bold text-blue-600">{student.participationRate}%</div>
            <div className="text-xs text-gray-600">Participation</div>
          </div>
        </div>
        
        <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
          <span>Sessions: {student.artSessionCount}</span>
          <span>Last: {new Date(student.lastSessionDate).toLocaleDateString()}</span>
        </div>
        
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setSelectedStudent(student.id)}
            className="py-2 px-3 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors text-sm font-medium flex items-center justify-center space-x-1"
          >
            <Eye className="h-4 w-4" />
            <span>View</span>
          </button>
          <button
            onClick={() => handleDetailClick('student', student)}
            className="py-2 px-3 bg-gray-50 text-gray-600 rounded-lg hover:bg-gray-100 transition-colors text-sm font-medium flex items-center justify-center space-x-1"
          >
            <Info className="h-4 w-4" />
            <span>Details</span>
          </button>
          <button
            onClick={handleDownloadReport}
            className="py-2 px-3 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition-colors text-sm font-medium flex items-center justify-center space-x-1"
          >
            <Download className="h-4 w-4" />
            <span>Export</span>
          </button>
          <button
            onClick={() => handleDetailClick('trend', { student, type: 'weekly' })}
            className="py-2 px-3 bg-purple-50 text-purple-600 rounded-lg hover:bg-purple-100 transition-colors text-sm font-medium flex items-center justify-center space-x-1"
          >
            <BarChart className="h-4 w-4" />
            <span>Trend</span>
          </button>
        </div>
      </div>
    );
  };

  const PersonalizedStudentGraph = ({ student }: { student: StudentAnalytics }) => {
    const maxValue = Math.max(student.preTestScore, student.postTestScore, 10);
    
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900">{student.name}'s Progress</h3>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
            <span className="text-sm font-medium text-gray-600">Personalized View</span>
          </div>
        </div>
        
        {/* Individual student chart with X-axis and Y-axis labels */}
        <div className="mb-6">
          <div className="flex items-end justify-center space-x-8 h-64">
            {/* Y-axis label */}
            <div className="flex flex-col items-center justify-center h-full">
              <div className="transform -rotate-90 text-sm font-medium text-gray-600 whitespace-nowrap">
                Avg. Happiness Score (%)
              </div>
            </div>
            
            {/* Chart bars */}
            <div className="flex items-end space-x-8">
              {/* Pre-Test Bar */}
              <div className="flex flex-col items-center">
                <div className="w-16 h-48 bg-gray-100 rounded-t-lg relative flex items-end">
                  <div 
                    className="w-full bg-gradient-to-t from-red-400 to-red-500 rounded-t-lg transition-all duration-1000 flex items-center justify-center"
                    style={{ height: `${(student.preTestScore / maxValue) * 100}%` }}
                  >
                    <span className="text-white text-sm font-semibold transform -rotate-90 whitespace-nowrap">
                      {student.preTestScore.toFixed(1)}
                    </span>
                  </div>
                </div>
                <div className="mt-2 text-sm font-medium text-gray-600">Pre-Test</div>
              </div>
              
              {/* Post-Test Bar */}
              <div className="flex flex-col items-center">
                <div className="w-16 h-48 bg-gray-100 rounded-t-lg relative flex items-end">
                  <div 
                    className="w-full bg-gradient-to-t from-green-400 to-green-500 rounded-t-lg transition-all duration-1000 flex items-center justify-center"
                    style={{ height: `${(student.postTestScore / maxValue) * 100}%` }}
                  >
                    <span className="text-white text-sm font-semibold transform -rotate-90 whitespace-nowrap">
                      {student.postTestScore.toFixed(1)}
                    </span>
                  </div>
                </div>
                <div className="mt-2 text-sm font-medium text-gray-600">Post-Test</div>
              </div>
            </div>
          </div>
          
          {/* X-axis label */}
          <div className="text-center mt-4">
            <div className="text-sm font-medium text-gray-600">Pre-test vs Post-test</div>
          </div>
        </div>
        
        {/* Student-specific delta highlight */}
        <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg p-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600 mb-1">
              +{student.happinessImprovement.toFixed(1)}%
            </div>
            <div className="text-sm font-medium text-gray-700">
              Your Happiness improved by +{student.happinessImprovement.toFixed(1)}%
            </div>
          </div>
        </div>
      </div>
    );
  };

  const PersonalizedReport = ({ student }: { student: StudentAnalytics }) => {
    const handleDownloadReport = () => {
      // Create a comprehensive report
      const report = `
HAPPINESS SCORE REPORT - ${student.name.toUpperCase()}
=====================================================

Student Information:
-------------------
Name: ${student.name}
Grade: ${student.grade}
Report Generated: ${new Date().toLocaleDateString()}

PRE-TEST vs POST-TEST ANALYSIS
------------------------------
Pre-Test Score: ${student.preTestScore.toFixed(1)}/10
Post-Test Score: ${student.postTestScore.toFixed(1)}/10

YOUR HAPPINESS IMPROVED BY +${student.happinessImprovement.toFixed(1)}%

WEEKLY PROGRESS TRACKING
------------------------
Week 1: ${student.emotionalTrend.week1.toFixed(1)}/10
Week 2: ${student.emotionalTrend.week2.toFixed(1)}/10
Week 3: ${student.emotionalTrend.week3.toFixed(1)}/10
Week 4: ${student.emotionalTrend.week4.toFixed(1)}/10

PARTICIPATION & ENGAGEMENT
--------------------------
Participation Rate: ${student.participationRate}%
Art Sessions Completed: ${student.artSessionCount}
Last Session Date: ${new Date(student.lastSessionDate).toLocaleDateString()}

SUMMARY
-------
${student.name} has shown significant improvement in happiness scores, 
with a ${student.happinessImprovement.toFixed(1)}% increase from pre-test to post-test. 
The student participated in ${student.artSessionCount} art therapy sessions 
with a ${student.participationRate}% participation rate.

Generated by HappyArt Analytics System
      `.trim();

      // Create and download the file
      const blob = new Blob([report], { type: 'text/plain' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${student.name.replace(/\s+/g, '_')}_Detailed_Happiness_Report.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    };

    return (
      <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-6">
        <div className="text-center">
          <h4 className="text-xl font-bold text-gray-900 mb-2">Personalized Report</h4>
          <p className="text-gray-700 mb-4">
            <span className="font-bold text-blue-600">{student.name}</span>'s happiness improved by{' '}
            <span className="font-bold text-green-600">+{student.happinessImprovement.toFixed(1)}%</span>
          </p>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="bg-white rounded-lg p-4">
              <div className="text-2xl font-bold text-red-600">{student.preTestScore.toFixed(1)}</div>
              <div className="text-sm text-gray-600">Pre-Test Score</div>
            </div>
            <div className="bg-white rounded-lg p-4">
              <div className="text-2xl font-bold text-green-600">{student.postTestScore.toFixed(1)}</div>
              <div className="text-sm text-gray-600">Post-Test Score</div>
            </div>
          </div>
          <div className="flex items-center justify-center space-x-4 text-sm text-gray-600">
            <span>Participation: {student.participationRate}%</span>
            <span>•</span>
            <span>Sessions: {student.artSessionCount}</span>
          </div>
          <button 
            onClick={handleDownloadReport}
            className="mt-4 flex items-center space-x-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors mx-auto"
          >
            <Download className="h-4 w-4" />
            <span>Download Report</span>
          </button>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading analytics data...</p>
        </div>
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-8 w-8 text-red-600 mx-auto mb-4" />
          <p className="text-gray-600">Failed to load analytics data</p>
        </div>
      </div>
    );
  }

  const currentClassData = getCurrentClassData();
  const selectedStudentData = selectedStudent ? getStudentData(selectedStudent) : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      {/* Modern Header */}
      <div className="bg-white/80 backdrop-blur-sm shadow-xl border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-6 lg:space-y-0">
              <div className="flex items-center space-x-4">
                <div className="p-4 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl shadow-lg">
                  <Target className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h1 className="text-4xl font-bold bg-gradient-to-r from-slate-900 to-slate-700 bg-clip-text text-transparent">
                    Analytics Dashboard
                  </h1>
                  <p className="text-slate-600 mt-2 text-lg leading-relaxed">
                    Comprehensive analysis of student happiness and art therapy effectiveness
                  </p>
                  <div className="flex items-center space-x-4 mt-3">
                    <div className="flex items-center space-x-2 text-sm text-slate-500">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                      <span>Real-time Analytics</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-slate-500">
                      <BarChart3 className="h-4 w-4" />
                      <span>Advanced Insights</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center space-y-3 sm:space-y-0 sm:space-x-3">
                <div className="flex space-x-3">
                  <select
                    value={timeRange}
                    onChange={(e) => setTimeRange(e.target.value as any)}
                    className="px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-white shadow-sm font-medium"
                  >
                    <option value="week">Last Week</option>
                    <option value="month">Last Month</option>
                    <option value="quarter">Last Quarter</option>
                    <option value="year">Last Year</option>
                  </select>
                  <select
                    value={selectedClass}
                    onChange={(e) => setSelectedClass(e.target.value)}
                    className="px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-white shadow-sm font-medium"
                  >
                    <option value="all">All Classes</option>
                    {data.classes.map(cls => (
                      <option key={cls.className} value={cls.className}>{cls.className}</option>
                    ))}
                  </select>
                </div>
                
                <div className="flex space-x-3">
                  <button 
                    onClick={handleAnalysisClick}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-xl hover:from-emerald-600 hover:to-emerald-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    <BarChart className="h-5 w-5" />
                    <span className="font-semibold">Analysis</span>
                  </button>
                  <button 
                    onClick={handleReportClick}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-xl hover:from-purple-600 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    <FileText className="h-5 w-5" />
                    <span className="font-semibold">Report</span>
                  </button>
                  <button 
                    onClick={handleExportClick}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-xl hover:from-blue-600 hover:to-blue-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    <Download className="h-5 w-5" />
                    <span className="font-semibold">Export</span>
                  </button>
                  <button 
                    onClick={handleSettingsClick}
                    className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-slate-500 to-slate-600 text-white rounded-xl hover:from-slate-600 hover:to-slate-700 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105"
                  >
                    <Settings className="h-5 w-5" />
                    <span className="font-semibold">Settings</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div 
            className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 cursor-pointer group"
            onClick={() => handleDetailClick('overall', { type: 'totalStudents', data: data.overallStats })}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 group-hover:text-blue-600 transition-colors">Total Students</p>
                <p className="text-3xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors">{data.overallStats.totalStudents}</p>
              </div>
              <Users className="h-8 w-8 text-blue-600 group-hover:scale-110 transition-transform" />
            </div>
          </div>
          
          <div 
            className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 cursor-pointer group"
            onClick={() => handleDetailClick('overall', { type: 'happinessBefore', data: data.overallStats })}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 group-hover:text-red-600 transition-colors">Avg. Happiness Before</p>
                <p className="text-3xl font-bold text-red-600 group-hover:text-red-700 transition-colors">{data.overallStats.averageHappinessBefore.toFixed(1)}</p>
              </div>
              <TrendingDown className="h-8 w-8 text-red-600 group-hover:scale-110 transition-transform" />
            </div>
          </div>
          
          <div 
            className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 cursor-pointer group"
            onClick={() => handleDetailClick('overall', { type: 'happinessAfter', data: data.overallStats })}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 group-hover:text-green-600 transition-colors">Avg. Happiness After</p>
                <p className="text-3xl font-bold text-green-600 group-hover:text-green-700 transition-colors">{data.overallStats.averageHappinessAfter.toFixed(1)}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-600 group-hover:scale-110 transition-transform" />
            </div>
          </div>
          
          <div 
            className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 cursor-pointer group"
            onClick={() => handleDetailClick('overall', { type: 'improvement', data: data.overallStats })}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 group-hover:text-blue-600 transition-colors">Overall Improvement</p>
                <p className="text-3xl font-bold text-blue-600 group-hover:text-blue-700 transition-colors">+{data.overallStats.overallImprovement.toFixed(1)}%</p>
              </div>
              <Heart className="h-8 w-8 text-blue-600 group-hover:scale-110 transition-transform" />
            </div>
          </div>
        </div>

        {/* View Mode Tabs */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              {[
                { id: 'overview', label: 'Overview', icon: BarChart3 },
                { id: 'detailed', label: 'Detailed Analysis', icon: Target },
                { id: 'comparison', label: 'Comparison', icon: Activity }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setViewMode(tab.id as any)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center space-x-2 ${
                    viewMode === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <tab.icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {viewMode === 'overview' && currentClassData && (
              <div className="space-y-8">
                {/* Main Comparison Chart */}
                <ComparisonChart data={currentClassData} />

                {/* Students Grid */}
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-6">Student Performance</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {currentClassData.students.map(student => (
                      <IndividualStudentCard key={student.id} student={student} />
                    ))}
                  </div>
                </div>
              </div>
            )}

            {viewMode === 'detailed' && !selectedStudentData && (
              <div className="text-center py-12">
                <Target className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Select a Student</h3>
                <p className="text-gray-600 mb-6">Choose a student from the overview tab to view their detailed analysis</p>
                <button
                  onClick={() => setViewMode('overview')}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Go to Overview
                </button>
              </div>
            )}

            {viewMode === 'detailed' && selectedStudentData && (
              <div className="space-y-8">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{selectedStudentData.name}</h3>
                  <p className="text-gray-600">Grade {selectedStudentData.grade}</p>
                </div>

                {/* Comprehensive Metrics Dashboard */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-gradient-to-r from-red-50 to-red-100 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-red-600">{selectedStudentData.preTestScore.toFixed(1)}</div>
                    <div className="text-sm text-gray-600">Pre-Test Score</div>
                    <div className="text-xs text-gray-500 mt-1">Baseline Assessment</div>
                  </div>
                  <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-green-600">{selectedStudentData.postTestScore.toFixed(1)}</div>
                    <div className="text-sm text-gray-600">Post-Test Score</div>
                    <div className="text-xs text-gray-500 mt-1">Final Assessment</div>
                  </div>
                  <div className="bg-gradient-to-r from-blue-50 to-blue-100 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-blue-600">+{selectedStudentData.happinessImprovement.toFixed(1)}%</div>
                    <div className="text-sm text-gray-600">Improvement</div>
                    <div className="text-xs text-gray-500 mt-1">Happiness Growth</div>
                  </div>
                  <div className="bg-gradient-to-r from-purple-50 to-purple-100 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-purple-600">{selectedStudentData.participationRate}%</div>
                    <div className="text-sm text-gray-600">Participation</div>
                    <div className="text-xs text-gray-500 mt-1">Session Attendance</div>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <PersonalizedStudentGraph student={selectedStudentData} />
                  <PersonalizedReport student={selectedStudentData} />
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <TrendChart student={selectedStudentData} />
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Performance Analytics</h4>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium text-gray-600">Participation Rate</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div 
                              className="h-2 rounded-full bg-gradient-to-r from-blue-400 to-blue-500"
                              style={{ width: `${selectedStudentData.participationRate}%` }}
                            ></div>
                          </div>
                          <span className="text-lg font-bold text-blue-600">{selectedStudentData.participationRate}%</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium text-gray-600">Sessions Completed</span>
                        <span className="text-lg font-bold text-green-600">{selectedStudentData.artSessionCount}</span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium text-gray-600">Last Session</span>
                        <span className="text-lg font-bold text-purple-600">{new Date(selectedStudentData.lastSessionDate).toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium text-gray-600">Performance Level</span>
                        <span className={`text-lg font-bold ${
                          selectedStudentData.happinessImprovement > 30 ? 'text-green-600' : 
                          selectedStudentData.happinessImprovement > 15 ? 'text-yellow-600' : 'text-red-600'
                        }`}>
                          {selectedStudentData.happinessImprovement > 30 ? 'High' : 
                           selectedStudentData.happinessImprovement > 15 ? 'Medium' : 'Low'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Detailed Insights and Recommendations */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Progress Insights</h4>
                    <div className="space-y-3">
                      <div className="p-3 bg-green-50 rounded-lg">
                        <div className="text-sm font-medium text-green-800">Score Improvement</div>
                        <div className="text-lg font-bold text-green-600">
                          +{(selectedStudentData.postTestScore - selectedStudentData.preTestScore).toFixed(1)} points
                        </div>
                      </div>
                      <div className="p-3 bg-blue-50 rounded-lg">
                        <div className="text-sm font-medium text-blue-800">Growth Rate</div>
                        <div className="text-lg font-bold text-blue-600">
                          {selectedStudentData.happinessImprovement.toFixed(1)}% increase
                        </div>
                      </div>
                      <div className="p-3 bg-purple-50 rounded-lg">
                        <div className="text-sm font-medium text-purple-800">Engagement</div>
                        <div className="text-lg font-bold text-purple-600">
                          {selectedStudentData.participationRate}% active participation
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Recommendations</h4>
                    <div className="space-y-3">
                      {selectedStudentData.happinessImprovement > 30 ? (
                        <div className="p-3 bg-green-50 rounded-lg">
                          <div className="text-sm font-medium text-green-800 mb-1">Excellent Progress</div>
                          <ul className="text-xs text-green-700 space-y-1">
                            <li>• Continue current approach</li>
                            <li>• Consider advanced challenges</li>
                            <li>• Mentor other students</li>
                          </ul>
                        </div>
                      ) : selectedStudentData.happinessImprovement > 15 ? (
                        <div className="p-3 bg-yellow-50 rounded-lg">
                          <div className="text-sm font-medium text-yellow-800 mb-1">Good Progress</div>
                          <ul className="text-xs text-yellow-700 space-y-1">
                            <li>• Increase session frequency</li>
                            <li>• Try new art mediums</li>
                            <li>• Focus on emotional expression</li>
                          </ul>
                        </div>
                      ) : (
                        <div className="p-3 bg-red-50 rounded-lg">
                          <div className="text-sm font-medium text-red-800 mb-1">Needs Support</div>
                          <ul className="text-xs text-red-700 space-y-1">
                            <li>• Additional one-on-one time</li>
                            <li>• Explore different activities</li>
                            <li>• Consider counseling support</li>
                          </ul>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Next Steps</h4>
                    <div className="space-y-3">
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="text-sm font-medium text-gray-800 mb-1">Immediate Actions</div>
                        <ul className="text-xs text-gray-600 space-y-1">
                          <li>• Schedule follow-up assessment</li>
                          <li>• Review session recordings</li>
                          <li>• Update progress notes</li>
                        </ul>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="text-sm font-medium text-gray-800 mb-1">Long-term Goals</div>
                        <ul className="text-xs text-gray-600 space-y-1">
                          <li>• Monitor emotional patterns</li>
                          <li>• Adjust therapy approach</li>
                          <li>• Document improvements</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Weekly Progress Timeline */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-6">Weekly Progress Timeline</h4>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    {[
                      { week: 'Week 1', score: selectedStudentData.emotionalTrend.week1, color: 'red' },
                      { week: 'Week 2', score: selectedStudentData.emotionalTrend.week2, color: 'orange' },
                      { week: 'Week 3', score: selectedStudentData.emotionalTrend.week3, color: 'yellow' },
                      { week: 'Week 4', score: selectedStudentData.emotionalTrend.week4, color: 'green' }
                    ].map(({ week, score, color }, index) => (
                      <div key={week} className="text-center">
                        <div className={`w-16 h-16 mx-auto rounded-full flex items-center justify-center text-white font-bold text-lg mb-2 ${
                          color === 'red' ? 'bg-red-500' :
                          color === 'orange' ? 'bg-orange-500' :
                          color === 'yellow' ? 'bg-yellow-500' : 'bg-green-500'
                        }`}>
                          {score.toFixed(1)}
                        </div>
                        <div className="text-sm font-medium text-gray-900">{week}</div>
                        <div className="text-xs text-gray-500">Happiness Score</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {viewMode === 'comparison' && (
              <div className="space-y-8">
                <div className="text-center">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">Pre-Test vs Post-Test Comparison</h3>
                  <p className="text-gray-600">Comprehensive analysis across all students</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Class Comparison</h4>
                    <div className="space-y-4">
                      {data.classes.map(cls => (
                        <div key={cls.className} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div>
                            <p className="font-medium text-gray-900">{cls.className}</p>
                            <p className="text-sm text-gray-600">{cls.totalStudents} students</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-green-600">+{cls.averageImprovement.toFixed(1)}%</p>
                            <p className="text-xs text-gray-500">improvement</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Top Performers</h4>
                    <div className="space-y-3">
                      {data.classes.flatMap(cls => cls.students)
                        .sort((a, b) => b.happinessImprovement - a.happinessImprovement)
                        .slice(0, 5)
                        .map((student, index) => (
                        <div key={student.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center">
                              <span className="text-white text-sm font-bold">{index + 1}</span>
                            </div>
                            <div>
                              <p className="font-medium text-gray-900">{student.name}</p>
                              <p className="text-sm text-gray-600">Grade {student.grade}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold text-green-600">+{student.happinessImprovement.toFixed(1)}%</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Final Comparison Graph */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-6">Final Comparison Graph</h4>
                  <div className="text-center">
                    <div className="inline-block">
                      <div className="flex items-center space-x-8 mb-4">
                        <div className="text-center">
                          <div className="text-3xl font-bold text-red-600">{data.overallStats.averageHappinessBefore.toFixed(1)}</div>
                          <div className="text-sm text-gray-600">Pre-Test Average</div>
                        </div>
                        <div className="text-center">
                          <ArrowUp className="h-8 w-8 text-green-600 mx-auto" />
                          <div className="text-lg font-bold text-green-600">+{data.overallStats.overallImprovement.toFixed(1)}%</div>
                          <div className="text-sm text-gray-600">Improvement</div>
                        </div>
                        <div className="text-center">
                          <div className="text-3xl font-bold text-green-600">{data.overallStats.averageHappinessAfter.toFixed(1)}</div>
                          <div className="text-sm text-gray-600">Post-Test Average</div>
                        </div>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-4">
                        <div 
                          className="bg-gradient-to-r from-red-500 to-green-500 h-4 rounded-full transition-all duration-1000"
                          style={{ width: '100%' }}
                        ></div>
                      </div>
                      <p className="text-gray-600 mt-4">
                        <span className="font-bold text-blue-600">{data.overallStats.totalStudents}</span> students showed an average improvement of{' '}
                        <span className="font-bold text-green-600">+{data.overallStats.overallImprovement.toFixed(1)}%</span> in happiness scores
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Detail Modal */}
      {showDetailModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">
                {selectedDetailType === 'student' ? 'Student Details' : 
                 selectedDetailType === 'class' ? 'Class Details' : 
                 selectedDetailType === 'trend' ? 'Trend Analysis' : 'Overall Statistics'}
              </h3>
              <button
                onClick={() => setShowDetailModal(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="p-6">
              {selectedDetailType === 'student' && selectedDetailData && (
                <div className="space-y-4">
                  <div className="text-center">
                    <h4 className="text-2xl font-bold text-gray-900">{selectedDetailData.name}</h4>
                    <p className="text-gray-600">Grade {selectedDetailData.grade}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-red-600">{selectedDetailData.preTestScore.toFixed(1)}</div>
                      <div className="text-sm text-gray-600">Pre-Test Score</div>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{selectedDetailData.postTestScore.toFixed(1)}</div>
                      <div className="text-sm text-gray-600">Post-Test Score</div>
                    </div>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg text-center">
                    <div className="text-2xl font-bold text-blue-600">+{selectedDetailData.happinessImprovement.toFixed(1)}%</div>
                    <div className="text-sm text-gray-600">Improvement</div>
                  </div>
                  <div className="space-y-2">
                    <h5 className="font-semibold text-gray-900">Additional Metrics</h5>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="text-lg font-bold text-blue-600">{selectedDetailData.participationRate}%</div>
                        <div className="text-sm text-gray-600">Participation Rate</div>
                      </div>
                      <div className="p-3 bg-gray-50 rounded-lg">
                        <div className="text-lg font-bold text-purple-600">{selectedDetailData.artSessionCount}</div>
                        <div className="text-sm text-gray-600">Sessions Completed</div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              {selectedDetailType === 'class' && selectedDetailData && (
                <div className="space-y-4">
                  <div className="text-center">
                    <h4 className="text-2xl font-bold text-gray-900">{selectedDetailData.className}</h4>
                    <p className="text-gray-600">Class Analytics</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{selectedDetailData.totalStudents}</div>
                      <div className="text-sm text-gray-600">Total Students</div>
                    </div>
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-red-600">{selectedDetailData.averagePreTest.toFixed(1)}</div>
                      <div className="text-sm text-gray-600">Avg. Pre-Test</div>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{selectedDetailData.averagePostTest.toFixed(1)}</div>
                      <div className="text-sm text-gray-600">Avg. Post-Test</div>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">+{selectedDetailData.averageImprovement.toFixed(1)}%</div>
                      <div className="text-sm text-gray-600">Avg. Improvement</div>
                    </div>
                  </div>
                </div>
              )}
              {selectedDetailType === 'trend' && selectedDetailData && (
                <div className="space-y-4">
                  <div className="text-center">
                    <h4 className="text-2xl font-bold text-gray-900">Trend Analysis</h4>
                    <p className="text-gray-600">{selectedDetailData.student.name} - Weekly Progress</p>
                  </div>
                  <div className="space-y-3">
                    {Object.entries(selectedDetailData.student.emotionalTrend).map(([week, score]) => (
                      <div key={week} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <span className="capitalize text-gray-600">{week.replace('week', 'Week ')}</span>
                        <span className="font-semibold text-gray-900">{score as number}/10</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {selectedDetailType === 'overall' && selectedDetailData && (
                <div className="space-y-4">
                  <div className="text-center">
                    <h4 className="text-2xl font-bold text-gray-900">Overall Statistics</h4>
                    <p className="text-gray-600">Comprehensive overview of all analytics data</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-blue-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{selectedDetailData.data.totalStudents}</div>
                      <div className="text-sm text-gray-600">Total Students</div>
                    </div>
                    <div className="bg-red-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-red-600">{selectedDetailData.data.averageHappinessBefore.toFixed(1)}</div>
                      <div className="text-sm text-gray-600">Avg. Happiness Before</div>
                    </div>
                    <div className="bg-green-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{selectedDetailData.data.averageHappinessAfter.toFixed(1)}</div>
                      <div className="text-sm text-gray-600">Avg. Happiness After</div>
                    </div>
                    <div className="bg-purple-50 p-4 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">+{selectedDetailData.data.overallImprovement.toFixed(1)}%</div>
                      <div className="text-sm text-gray-600">Overall Improvement</div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">Export Analytics Report</h3>
              <button
                onClick={() => setShowExportModal(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <p className="text-gray-600">Choose the format for your analytics report export:</p>
              <div className="space-y-3">
                <button
                  onClick={() => handleExportReport('pdf')}
                  className="w-full flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <FileText className="h-6 w-6 text-red-600" />
                  <div className="text-left">
                    <div className="font-medium text-gray-900">PDF Report</div>
                    <div className="text-sm text-gray-600">Download as PDF document</div>
                  </div>
                </button>
                <button
                  onClick={() => handleExportReport('csv')}
                  className="w-full flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <FileText className="h-6 w-6 text-green-600" />
                  <div className="text-left">
                    <div className="font-medium text-gray-900">CSV Data</div>
                    <div className="text-sm text-gray-600">Download as CSV spreadsheet</div>
                  </div>
                </button>
                <button
                  onClick={() => handleExportReport('excel')}
                  className="w-full flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <FileText className="h-6 w-6 text-blue-600" />
                  <div className="text-left">
                    <div className="font-medium text-gray-900">Excel Workbook</div>
                    <div className="text-sm text-gray-600">Download as Excel file</div>
                  </div>
                </button>
                <button
                  onClick={() => handleExportReport('json')}
                  className="w-full flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <FileText className="h-6 w-6 text-purple-600" />
                  <div className="text-left">
                    <div className="font-medium text-gray-900">JSON Data</div>
                    <div className="text-sm text-gray-600">Download as JSON data</div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Analysis Modal */}
      {showAnalysisModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">Advanced Analytics</h3>
              <button
                onClick={() => setShowAnalysisModal(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-6 rounded-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Key Insights</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li>• {data?.overallStats.totalStudents} students participated in the program</li>
                    <li>• Average improvement of {data?.overallStats.overallImprovement.toFixed(1)}% across all students</li>
                    <li>• {data?.classes.length} classes showed positive results</li>
                    <li>• Total sessions conducted: {data?.overallStats.totalSessions}</li>
                    <li>• Average participation rate: {data?.overallStats.averageParticipation.toFixed(1)}%</li>
                  </ul>
                </div>
                <div className="bg-gradient-to-r from-green-50 to-green-100 p-6 rounded-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Performance Trends</h4>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Weekly improvement rates are consistent</li>
                    <li>• Higher participation correlates with better outcomes</li>
                    <li>• Art therapy shows measurable positive impact</li>
                    <li>• Students show sustained improvement over time</li>
                  </ul>
                </div>
              </div>
              <div className="bg-gray-50 p-6 rounded-lg">
                <h4 className="text-lg font-semibold text-gray-900 mb-4">Class Performance Analysis</h4>
                <div className="space-y-3">
                  {data?.classes.map(cls => (
                    <div key={cls.className} className="flex justify-between items-center p-3 bg-white rounded-lg">
                      <span className="font-medium text-gray-900">{cls.className}</span>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-600">{cls.totalStudents} students</span>
                        <span className="font-bold text-green-600">+{cls.averageImprovement.toFixed(1)}%</span>
                        <span className="text-sm text-blue-600">{cls.trends.participationRate}% participation</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">Analytics Report Viewer</h3>
              <div className="flex items-center space-x-2">
                <button
                  onClick={handleShareReport}
                  className="flex items-center space-x-2 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors"
                >
                  <Share2 className="h-4 w-4" />
                  <span>Share</span>
                </button>
                <button
                  onClick={() => window.print()}
                  className="flex items-center space-x-2 px-3 py-2 bg-gray-50 text-gray-600 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <Printer className="h-4 w-4" />
                  <span>Print</span>
                </button>
                <button
                  onClick={() => setShowReportModal(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="space-y-6">
                <div className="text-center">
                  <h4 className="text-2xl font-bold text-gray-900 mb-2">Analytics Dashboard Report</h4>
                  <p className="text-gray-600">Generated on {new Date().toLocaleDateString()}</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="bg-blue-50 p-4 rounded-lg text-center">
                    <div className="text-3xl font-bold text-blue-600">{data?.overallStats.totalStudents}</div>
                    <div className="text-sm text-gray-600">Total Students</div>
                  </div>
                  <div className="bg-green-50 p-4 rounded-lg text-center">
                    <div className="text-3xl font-bold text-green-600">+{data?.overallStats.overallImprovement.toFixed(1)}%</div>
                    <div className="text-sm text-gray-600">Overall Improvement</div>
                  </div>
                  <div className="bg-purple-50 p-4 rounded-lg text-center">
                    <div className="text-3xl font-bold text-purple-600">{data?.classes.length}</div>
                    <div className="text-sm text-gray-600">Classes Analyzed</div>
                  </div>
                  <div className="bg-orange-50 p-4 rounded-lg text-center">
                    <div className="text-3xl font-bold text-orange-600">{data?.overallStats.totalSessions}</div>
                    <div className="text-sm text-gray-600">Total Sessions</div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h5 className="text-lg font-semibold text-gray-900">Class Performance Summary</h5>
                  <div className="space-y-3">
                    {data?.classes.map(cls => (
                      <div key={cls.className} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                        <div>
                          <div className="font-medium text-gray-900">{cls.className}</div>
                          <div className="text-sm text-gray-600">{cls.totalStudents} students • {cls.trends.participationRate}% participation</div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-green-600">+{cls.averageImprovement.toFixed(1)}%</div>
                          <div className="text-xs text-gray-500">improvement</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-lg">
                  <h5 className="text-lg font-semibold text-gray-900 mb-4">Key Findings</h5>
                  <ul className="space-y-2 text-gray-700">
                    <li>• All classes showed positive improvement in happiness scores</li>
                    <li>• Average pre-test score: {data?.overallStats.averageHappinessBefore.toFixed(1)}/10</li>
                    <li>• Average post-test score: {data?.overallStats.averageHappinessAfter.toFixed(1)}/10</li>
                    <li>• The art therapy program demonstrates measurable positive impact</li>
                    <li>• Participation rates average {data?.overallStats.averageParticipation.toFixed(1)}% across all students</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Settings Modal */}
      {showSettingsModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <h3 className="text-xl font-semibold text-gray-900">Analytics Settings</h3>
              <button
                onClick={() => setShowSettingsModal(false)}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Default Time Range</label>
                <select
                  value={timeRange}
                  onChange={(e) => setTimeRange(e.target.value as any)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="week">Last Week</option>
                  <option value="month">Last Month</option>
                  <option value="quarter">Last Quarter</option>
                  <option value="year">Last Year</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Default View Mode</label>
                <select
                  value={viewMode}
                  onChange={(e) => setViewMode(e.target.value as any)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="overview">Overview</option>
                  <option value="detailed">Detailed Analysis</option>
                  <option value="comparison">Comparison</option>
                </select>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">Auto-refresh data</span>
                <input type="checkbox" className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-gray-700">Show detailed tooltips</span>
                <input type="checkbox" className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
