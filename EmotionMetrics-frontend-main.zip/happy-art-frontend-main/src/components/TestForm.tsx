import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Box,
  Typography,
  IconButton,
  Card,
  CardContent,
  Divider,
  Chip,
  Alert,
  CircularProgress
} from '@mui/material';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { Add, Delete, Edit, Save, Close } from '@mui/icons-material';
import dayjs from 'dayjs';
import { Test, Question, createTest, editTest } from '../lib/api';

interface TestFormProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
  test?: Test | null;
  mode: 'create' | 'edit';
}

const TestForm: React.FC<TestFormProps> = ({ open, onClose, onSuccess, test, mode }) => {
  const [formData, setFormData] = useState({
    name: '',
    type: 'pre' as 'pre' | 'post',
    grade: '',
    subject: '',
    durationMinutes: 60,
    startTime: dayjs(),
    endTime: dayjs().add(1, 'hour'),
  });

  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (test && mode === 'edit') {
      setFormData({
        name: test.name,
        type: test.type,
        grade: test.grade,
        subject: test.subject,
        durationMinutes: test.durationMinutes,
        startTime: dayjs(test.startTime),
        endTime: dayjs(test.endTime),
      });
      setQuestions(test.questions);
    } else {
      // Reset form for create mode
      setFormData({
        name: '',
        type: 'pre',
        grade: '',
        subject: '',
        durationMinutes: 60,
        startTime: dayjs(),
        endTime: dayjs().add(1, 'hour'),
      });
      setQuestions([]);
    }
    setError(null);
  }, [test, mode, open]);

  const generateQuestionId = () => {
    return `q_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  };

  const addQuestion = () => {
    const newQuestion: Question = {
      qid: generateQuestionId(),
      text: '',
      type: 'mcq',
      options: ['', ''],
      correctOption: '',
      marks: 1,
    };
    setQuestions([...questions, newQuestion]);
  };

  const updateQuestion = (index: number, field: keyof Question, value: any) => {
    const updatedQuestions = [...questions];
    updatedQuestions[index] = { ...updatedQuestions[index], [field]: value };
    setQuestions(updatedQuestions);
  };

  const removeQuestion = (index: number) => {
    setQuestions(questions.filter((_, i) => i !== index));
  };

  const addOption = (questionIndex: number) => {
    const updatedQuestions = [...questions];
    const currentOptions = updatedQuestions[questionIndex].options || [];
    updatedQuestions[questionIndex].options = [...currentOptions, ''];
    setQuestions(updatedQuestions);
  };

  const updateOption = (questionIndex: number, optionIndex: number, value: string) => {
    const updatedQuestions = [...questions];
    if (updatedQuestions[questionIndex].options) {
      updatedQuestions[questionIndex].options![optionIndex] = value;
    }
    setQuestions(updatedQuestions);
  };

  const removeOption = (questionIndex: number, optionIndex: number) => {
    const updatedQuestions = [...questions];
    if (updatedQuestions[questionIndex].options) {
      updatedQuestions[questionIndex].options = updatedQuestions[questionIndex].options!.filter(
        (_, i) => i !== optionIndex
      );
    }
    setQuestions(updatedQuestions);
  };

  const handleSubmit = async () => {
    setError(null);
    setLoading(true);

    try {
      // Validation
      if (!formData.name.trim()) {
        throw new Error('Test name is required');
      }
      if (!formData.grade.trim()) {
        throw new Error('Grade is required');
      }
      if (!formData.subject.trim()) {
        throw new Error('Subject is required');
      }
      if (questions.length === 0) {
        throw new Error('At least one question is required');
      }

      // Validate questions
      for (let i = 0; i < questions.length; i++) {
        const q = questions[i];
        if (!q.text.trim()) {
          throw new Error(`Question ${i + 1}: Text is required`);
        }
        if (q.type === 'mcq') {
          if (!q.options || q.options.length < 2) {
            throw new Error(`Question ${i + 1}: At least 2 options are required for MCQ`);
          }
          if (!q.correctOption) {
            throw new Error(`Question ${i + 1}: Correct option is required for MCQ`);
          }
        }
        if (q.marks < 1) {
          throw new Error(`Question ${i + 1}: Marks must be at least 1`);
        }
      }

      const testData = {
        ...formData,
        startTime: formData.startTime.toISOString(),
        endTime: formData.endTime.toISOString(),
        questions,
      };

      if (mode === 'create') {
        await createTest(testData);
      } else if (test && (test._id || test.id)) {
        await editTest(test._id || test.id!, testData);
      }

      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <LocalizationProvider dateAdapter={AdapterDayjs}>
      <Dialog open={open} onClose={onClose} maxWidth="md" fullWidth>
        <DialogTitle>
          {mode === 'create' ? 'Create New Test' : 'Edit Test'}
          <IconButton
            onClick={onClose}
            sx={{ position: 'absolute', right: 8, top: 8 }}
          >
            <Close />
          </IconButton>
        </DialogTitle>

        <DialogContent dividers>
          {error && (
            <Alert severity="error" sx={{ mb: 2 }}>
              {error}
            </Alert>
          )}

          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            {/* Basic Information */}
            <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
              <TextField
                label="Test Name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                fullWidth
                required
              />
              <FormControl sx={{ minWidth: 120 }}>
                <InputLabel>Type</InputLabel>
                <Select
                  value={formData.type}
                  onChange={(e) => setFormData({ ...formData, type: e.target.value as 'pre' | 'post' })}
                  label="Type"
                >
                  <MenuItem value="pre">Pre-Test</MenuItem>
                  <MenuItem value="post">Post-Test</MenuItem>
                </Select>
              </FormControl>
            </Box>

            <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
              <TextField
                label="Grade"
                value={formData.grade}
                onChange={(e) => setFormData({ ...formData, grade: e.target.value })}
                required
              />
              <TextField
                label="Subject"
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                required
              />
              <TextField
                label="Duration (minutes)"
                type="number"
                value={formData.durationMinutes}
                onChange={(e) => setFormData({ ...formData, durationMinutes: parseInt(e.target.value) || 60 })}
                inputProps={{ min: 1, max: 300 }}
              />
            </Box>

            <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
              <DateTimePicker
                label="Start Time"
                value={formData.startTime}
                onChange={(newValue) => newValue && setFormData({ ...formData, startTime: newValue })}
                sx={{ minWidth: 200 }}
              />
              <DateTimePicker
                label="End Time"
                value={formData.endTime}
                onChange={(newValue) => newValue && setFormData({ ...formData, endTime: newValue })}
                sx={{ minWidth: 200 }}
              />
            </Box>

            <Divider />

            {/* Questions Section */}
            <Box>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6">Questions ({questions.length})</Typography>
                <Button
                  startIcon={<Add />}
                  onClick={addQuestion}
                  variant="outlined"
                  size="small"
                >
                  Add Question
                </Button>
              </Box>

              {questions.map((question, index) => (
                <Card key={question.qid} sx={{ mb: 2 }}>
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                      <Typography variant="subtitle1">Question {index + 1}</Typography>
                      <IconButton
                        onClick={() => removeQuestion(index)}
                        color="error"
                        size="small"
                      >
                        <Delete />
                      </IconButton>
                    </Box>

                    <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
                      <TextField
                        label="Question Text"
                        value={question.text}
                        onChange={(e) => updateQuestion(index, 'text', e.target.value)}
                        fullWidth
                        multiline
                        rows={2}
                        required
                      />
                      <FormControl sx={{ minWidth: 120 }}>
                        <InputLabel>Type</InputLabel>
                        <Select
                          value={question.type}
                          onChange={(e) => updateQuestion(index, 'type', e.target.value)}
                          label="Type"
                        >
                          <MenuItem value="mcq">MCQ</MenuItem>
                          <MenuItem value="subjective">Subjective</MenuItem>
                        </Select>
                      </FormControl>
                      <TextField
                        label="Marks"
                        type="number"
                        value={question.marks}
                        onChange={(e) => updateQuestion(index, 'marks', parseInt(e.target.value) || 1)}
                        inputProps={{ min: 1 }}
                        sx={{ width: 100 }}
                      />
                    </Box>

                    {question.type === 'mcq' && (
                      <Box>
                        <Typography variant="subtitle2" sx={{ mb: 1 }}>Options</Typography>
                        {question.options?.map((option, optionIndex) => (
                          <Box key={optionIndex} sx={{ display: 'flex', gap: 1, mb: 1 }}>
                            <TextField
                              label={`Option ${optionIndex + 1}`}
                              value={option}
                              onChange={(e) => updateOption(index, optionIndex, e.target.value)}
                              size="small"
                              fullWidth
                            />
                            <FormControl sx={{ minWidth: 100 }}>
                              <InputLabel>Correct?</InputLabel>
                              <Select
                                value={question.correctOption === option ? 'yes' : 'no'}
                                onChange={(e) => updateQuestion(index, 'correctOption', e.target.value === 'yes' ? option : '')}
                                label="Correct?"
                              >
                                <MenuItem value="no">No</MenuItem>
                                <MenuItem value="yes">Yes</MenuItem>
                              </Select>
                            </FormControl>
                            <IconButton
                              onClick={() => removeOption(index, optionIndex)}
                              color="error"
                              size="small"
                              disabled={question.options!.length <= 2}
                            >
                              <Delete />
                            </IconButton>
                          </Box>
                        ))}
                        <Button
                          startIcon={<Add />}
                          onClick={() => addOption(index)}
                          size="small"
                          sx={{ mt: 1 }}
                        >
                          Add Option
                        </Button>
                      </Box>
                    )}
                  </CardContent>
                </Card>
              ))}

              {questions.length === 0 && (
                <Box sx={{ textAlign: 'center', py: 4 }}>
                  <Typography color="text.secondary">
                    No questions added yet. Click "Add Question" to get started.
                  </Typography>
                </Box>
              )}
            </Box>
          </Box>
        </DialogContent>

        <DialogActions>
          <Button onClick={onClose} disabled={loading}>
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            variant="contained"
            startIcon={loading ? <CircularProgress size={20} /> : <Save />}
            disabled={loading}
          >
            {loading ? 'Saving...' : mode === 'create' ? 'Create Test' : 'Update Test'}
          </Button>
        </DialogActions>
      </Dialog>
    </LocalizationProvider>
  );
};

export default TestForm;

