import React from 'react';
import { Box, Typography, Card, CardContent, useMediaQuery, useTheme } from '@mui/material';
// ...existing code...
import { School } from '@mui/icons-material';
// ...existing code...

const SchoolDashboard: React.FC = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));



  return (
    <Box sx={{ p: { xs: 2, sm: 3 } }}>
      <Box>
        <Typography variant={isMobile ? "h5" : "h4"} component="h1" gutterBottom>
          School Dashboard
        </Typography>
        <Typography variant="body1" color="text.secondary" sx={{ fontSize: isMobile ? '0.875rem' : '1rem' }}>
          Welcome to your school dashboard.
        </Typography>
      </Box>
      <Card sx={{ mt: 3 }}>
        <CardContent sx={{ textAlign: 'center', py: { xs: 6, sm: 8 }, px: { xs: 2, sm: 3 } }}>
          <School sx={{ fontSize: { xs: 60, sm: 80 }, color: 'text.secondary', mb: 2 }} />
          <Typography variant={isMobile ? "h6" : "h5"} color="text.secondary" gutterBottom>
            No Tests or Assignments
          </Typography>
          <Typography variant="body1" color="text.secondary" sx={{ fontSize: { xs: '0.875rem', sm: '1rem' } }}>
            There are currently no tests or assignments for your school.
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );
};

export default SchoolDashboard;

