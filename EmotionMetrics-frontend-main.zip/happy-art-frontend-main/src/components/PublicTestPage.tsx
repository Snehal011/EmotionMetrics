import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import {
  Box,
  Typography,
  Button,
  TextField,
  FormControl,
  RadioGroup,
  FormControlLabel,
  Radio,
  Alert,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Chip,
  Paper,
  Fade,
  Slide,
  Avatar
} from '@mui/material';
import {
  AccessTime,
  School,
  Person,
  CheckCircle,
  Timer,
  ArrowForward,
  ArrowBack,
  Quiz,
  EmojiEvents,
  Send,
  PersonAdd,
  Badge
} from '@mui/icons-material';
import { getPublicTest, submitPublicTest } from '../lib/api';

interface PublicQuestion {
  qid: string;
  text: string;
  type: 'mcq' | 'subjective';
  options?: string[];
  marks: number;
}

interface PublicTest {
  testId: string;
  name: string;
  type: string;
  durationMinutes: number;
  grade: string;
  subject: string;
  questions: PublicQuestion[];
  linkInfo: {
    linkHash: string;
    startTime: string;
    endTime: string;
    schoolName: string;
  };
}

interface Answer {
  qid: string;
  answerText?: string;
  selectedOptionIndex?: number;
}

const PublicTestPage: React.FC = () => {
  const { hash } = useParams<{ hash: string }>();
  
  const [test, setTest] = useState<PublicTest | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [studentName, setStudentName] = useState('');
  const [rollNo, setRollNo] = useState('');
  const [currentStep, setCurrentStep] = useState(0);
  const [submitting, setSubmitting] = useState(false);
  const [timeLeft, setTimeLeft] = useState(0);
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);
  const [submissionResult, setSubmissionResult] = useState<any>(null);

  const steps = ['Student Information', 'Take Test', 'Submit'];

  useEffect(() => {
    if (hash) {
      fetchTest();
    }
  }, [hash]);

  useEffect(() => {
    if (test && test.durationMinutes) {
      setTimeLeft(test.durationMinutes * 60);
    }
  }, [test]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (timeLeft > 0 && currentStep === 1) {
      interval = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleSubmit();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timeLeft, currentStep]);

  const fetchTest = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await getPublicTest(hash!);
      setTest(response);
      
      // Initialize answers array
      const initialAnswers = response.questions.map(q => ({
        qid: q.qid,
        answerText: '',
        selectedOptionIndex: undefined
      }));
      setAnswers(initialAnswers);
    } catch (err: any) {
      setError(err.response?.data?.message || err.message || 'Failed to load test');
    } finally {
      setLoading(false);
    }
  };

  const handleAnswerChange = (questionId: string, value: string | number, type: 'text' | 'option') => {
    setAnswers(prev => prev.map(answer => {
      if (answer.qid === questionId) {
        if (type === 'text') {
          return { ...answer, answerText: value as string, selectedOptionIndex: undefined };
        } else {
          return { ...answer, selectedOptionIndex: value as number, answerText: '' };
        }
      }
      return answer;
    }));
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleNext = () => {
    if (currentStep === 0) {
      if (!studentName.trim() || !rollNo.trim()) {
        setError('Please fill in all required fields');
        return;
      }
    }
    setCurrentStep(prev => prev + 1);
  };

  const handleBack = () => {
    setCurrentStep(prev => prev - 1);
  };

  const handleSubmit = async () => {
    if (!test || !studentName.trim() || !rollNo.trim()) {
      setError('Please fill in all required fields');
      return;
    }

    // Check if all questions are answered
    const unansweredQuestions = answers.filter(answer => 
      !answer.answerText?.trim() && answer.selectedOptionIndex === undefined
    );
    
    if (unansweredQuestions.length > 0) {
      setError('Please answer all questions before submitting');
      return;
    }

    try {
      setSubmitting(true);
      setError(null);
      const response = await submitPublicTest(hash!, {
        name: studentName,
        rollNo,
        answers: answers.map(answer => ({
          qid: answer.qid,
          answerText: answer.answerText,
          selectedOptionIndex: answer.selectedOptionIndex
        }))
      });
      
      setSubmissionResult(response);
      setShowSuccessDialog(true);
    } catch (err: any) {
      setError(err.response?.data?.message || err.message || 'Failed to submit test');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCloseSuccess = () => {
    setShowSuccessDialog(false);
    // Redirect to a thank you page or close the tab
    window.close();
  };

  if (loading) {
    return (
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        minHeight: '100vh',
        flexDirection: 'column',
        gap: 2
      }}>
        <CircularProgress size={60} />
        <Typography variant="h6" color="text.secondary">
          Loading test...
        </Typography>
      </Box>
    );
  }

  if (error && !test) {
    return (
      <Box sx={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        minHeight: '100vh',
        flexDirection: 'column',
        gap: 2,
        p: 3
      }}>
        <Alert severity="error" sx={{ maxWidth: 600, width: '100%' }}>
          {error}
        </Alert>
        <Button variant="contained" onClick={() => window.close()}>
          Close
        </Button>
      </Box>
    );
  }

  if (!test) return null;

  return (
    <Box sx={{ 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      p: { xs: 2, sm: 3 }
    }}>
      {/* Modern Header with Gradient */}
      <Paper 
        elevation={8} 
        sx={{ 
          mb: 4, 
          background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
          borderRadius: 3,
          overflow: 'hidden',
          position: 'relative'
        }}
      >
        <Box sx={{ 
          background: 'linear-gradient(90deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%)',
          p: 3
        }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 3 }}>
              <Avatar 
                sx={{ 
                  width: 64, 
                  height: 64, 
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  boxShadow: '0 8px 32px rgba(102, 126, 234, 0.3)'
                }}
              >
                <Quiz sx={{ fontSize: 32, color: 'white' }} />
              </Avatar>
              <Box>
                <Typography 
                  variant="h3" 
                  component="h1" 
                  sx={{ 
                    fontWeight: 700,
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    backgroundClip: 'text',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    mb: 1
                  }}
                >
                  {test.name}
                </Typography>
                <Box sx={{ display: 'flex', gap: 1.5, flexWrap: 'wrap' }}>
                  <Chip 
                    label={test.type.toUpperCase()} 
                    sx={{ 
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      color: 'white',
                      fontWeight: 600,
                      boxShadow: '0 4px 12px rgba(102, 126, 234, 0.3)'
                    }} 
                  />
                  <Chip 
                    label={`Grade ${test.grade}`} 
                    variant="outlined" 
                    sx={{ 
                      borderColor: '#667eea',
                      color: '#667eea',
                      fontWeight: 600
                    }} 
                  />
                  <Chip 
                    label={test.subject} 
                    variant="outlined" 
                    sx={{ 
                      borderColor: '#764ba2',
                      color: '#764ba2',
                      fontWeight: 600
                    }} 
                  />
                </Box>
              </Box>
            </Box>
            
            {currentStep === 1 && (
              <Fade in={true}>
                <Paper 
                  elevation={4}
                  sx={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: 1.5, 
                    background: timeLeft < 300 
                      ? 'linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%)' 
                      : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    color: 'white', 
                    px: 3, 
                    py: 1.5, 
                    borderRadius: 3,
                    boxShadow: timeLeft < 300 
                      ? '0 8px 32px rgba(255, 107, 107, 0.4)' 
                      : '0 8px 32px rgba(102, 126, 234, 0.4)'
                  }}
                >
                  <Timer sx={{ fontSize: 28 }} />
                  <Typography variant="h5" fontWeight="bold">
                    {formatTime(timeLeft)}
                  </Typography>
                </Paper>
              </Fade>
            )}
          </Box>
          
          <Box sx={{ display: 'flex', gap: 4, mt: 3, flexWrap: 'wrap' }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
              <School sx={{ color: '#667eea', fontSize: 24 }} />
              <Typography variant="h6" sx={{ color: '#2c3e50', fontWeight: 600 }}>
                {test.linkInfo.schoolName}
              </Typography>
            </Box>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
              <AccessTime sx={{ color: '#764ba2', fontSize: 24 }} />
              <Typography variant="h6" sx={{ color: '#2c3e50', fontWeight: 600 }}>
                Duration: {test.durationMinutes} minutes
              </Typography>
            </Box>
          </Box>
        </Box>
      </Paper>

      {/* Enhanced Progress Stepper */}
      <Paper 
        elevation={6} 
        sx={{ 
          mb: 4, 
          background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
          borderRadius: 3,
          overflow: 'hidden'
        }}
      >
        <Box sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'center', mb: 3 }}>
            <Typography variant="h6" sx={{ 
              color: '#2c3e50', 
              fontWeight: 600,
              textAlign: 'center'
            }}>
              Test Progress
            </Typography>
          </Box>
          
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', position: 'relative' }}>
            {/* Progress Line */}
            <Box sx={{
              position: 'absolute',
              top: '50%',
              left: 0,
              right: 0,
              height: 4,
              background: 'linear-gradient(90deg, #e0e7ff 0%, #c7d2fe 100%)',
              borderRadius: 2,
              zIndex: 1
            }} />
            
            <Box sx={{
              position: 'absolute',
              top: '50%',
              left: 0,
              width: `${(currentStep / (steps.length - 1)) * 100}%`,
              height: 4,
              background: 'linear-gradient(90deg, #667eea 0%, #764ba2 100%)',
              borderRadius: 2,
              zIndex: 2,
              transition: 'width 0.5s ease-in-out'
            }} />

            {steps.map((label, index) => (
              <Box key={label} sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', zIndex: 3 }}>
                <Avatar
                  sx={{
                    width: 56,
                    height: 56,
                    background: index <= currentStep 
                      ? 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)'
                      : 'linear-gradient(135deg, #e0e7ff 0%, #c7d2fe 100%)',
                    color: index <= currentStep ? 'white' : '#9ca3af',
                    boxShadow: index <= currentStep 
                      ? '0 8px 32px rgba(102, 126, 234, 0.4)'
                      : '0 4px 16px rgba(156, 163, 175, 0.2)',
                    transition: 'all 0.3s ease-in-out',
                    '&:hover': {
                      transform: 'scale(1.1)',
                      boxShadow: '0 12px 40px rgba(102, 126, 234, 0.5)'
                    }
                  }}
                >
                  {index === 0 && <PersonAdd sx={{ fontSize: 28 }} />}
                  {index === 1 && <Quiz sx={{ fontSize: 28 }} />}
                  {index === 2 && <Send sx={{ fontSize: 28 }} />}
                </Avatar>
                <Typography 
                  variant="body2" 
                  sx={{ 
                    mt: 1, 
                    fontWeight: index <= currentStep ? 600 : 400,
                    color: index <= currentStep ? '#2c3e50' : '#9ca3af',
                    textAlign: 'center',
                    maxWidth: 100
                  }}
                >
                  {label}
                </Typography>
              </Box>
            ))}
          </Box>
        </Box>
      </Paper>

      {/* Error Alert */}
      {error && (
        <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      {/* Step Content */}
      <Paper 
        elevation={8} 
        sx={{ 
          background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
          borderRadius: 3,
          overflow: 'hidden'
        }}
      >
        <Box sx={{ p: 4 }}>
          {currentStep === 0 && (
            <Slide direction="up" in={currentStep === 0} mountOnEnter unmountOnExit>
              <Box sx={{ maxWidth: 600, mx: 'auto' }}>
                <Box sx={{ textAlign: 'center', mb: 4 }}>
                  <Avatar 
                    sx={{ 
                      width: 80, 
                      height: 80, 
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      boxShadow: '0 12px 40px rgba(102, 126, 234, 0.4)',
                      mx: 'auto',
                      mb: 2
                    }}
                  >
                    <PersonAdd sx={{ fontSize: 40, color: 'white' }} />
                  </Avatar>
                  <Typography 
                    variant="h4" 
                    sx={{ 
                      fontWeight: 700,
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      backgroundClip: 'text',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                      mb: 2
                    }}
                  >
                    Welcome to the Test!
                  </Typography>
                  <Typography variant="h6" sx={{ color: '#6b7280', mb: 4 }}>
                    Please provide your details to get started
                  </Typography>
                </Box>

                <Box sx={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  <Box sx={{ position: 'relative' }}>
                    <TextField
                      label="Full Name"
                      value={studentName}
                      onChange={(e) => setStudentName(e.target.value)}
                      fullWidth
                      required
                      variant="outlined"
                      InputProps={{
                        startAdornment: (
                          <Box sx={{ mr: 1, display: 'flex', alignItems: 'center' }}>
                            <Person sx={{ color: '#667eea' }} />
                          </Box>
                        )
                      }}
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          borderRadius: 3,
                          '&:hover .MuiOutlinedInput-notchedOutline': {
                            borderColor: '#667eea',
                            borderWidth: 2
                          },
                          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                            borderColor: '#667eea',
                            borderWidth: 2
                          }
                        },
                        '& .MuiInputLabel-root.Mui-focused': {
                          color: '#667eea'
                        }
                      }}
                    />
                  </Box>
                  
                  <Box sx={{ position: 'relative' }}>
                    <TextField
                      label="Roll Number"
                      value={rollNo}
                      onChange={(e) => setRollNo(e.target.value)}
                      fullWidth
                      required
                      variant="outlined"
                      InputProps={{
                        startAdornment: (
                          <Box sx={{ mr: 1, display: 'flex', alignItems: 'center' }}>
                            <Badge sx={{ color: '#764ba2' }} />
                          </Box>
                        )
                      }}
                      sx={{
                        '& .MuiOutlinedInput-root': {
                          borderRadius: 3,
                          '&:hover .MuiOutlinedInput-notchedOutline': {
                            borderColor: '#764ba2',
                            borderWidth: 2
                          },
                          '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                            borderColor: '#764ba2',
                            borderWidth: 2
                          }
                        },
                        '& .MuiInputLabel-root.Mui-focused': {
                          color: '#764ba2'
                        }
                      }}
                    />
                  </Box>
                </Box>

                <Box sx={{ 
                  mt: 4, 
                  p: 3, 
                  background: 'linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%)',
                  borderRadius: 3,
                  textAlign: 'center'
                }}>
                  <Typography variant="body2" sx={{ color: '#6b7280', fontStyle: 'italic' }}>
                    ✨ Your information is secure and will only be used for this test
                  </Typography>
                </Box>
              </Box>
            </Slide>
          )}

          {currentStep === 1 && (
            <Slide direction="up" in={currentStep === 1} mountOnEnter unmountOnExit>
              <Box>
                <Box sx={{ textAlign: 'center', mb: 4 }}>
                  <Avatar 
                    sx={{ 
                      width: 80, 
                      height: 80, 
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      boxShadow: '0 12px 40px rgba(102, 126, 234, 0.4)',
                      mx: 'auto',
                      mb: 2
                    }}
                  >
                    <Quiz sx={{ fontSize: 40, color: 'white' }} />
                  </Avatar>
                  <Typography 
                    variant="h4" 
                    sx={{ 
                      fontWeight: 700,
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      backgroundClip: 'text',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                      mb: 2
                    }}
                  >
                    Test Questions
                  </Typography>
                  <Typography variant="h6" sx={{ color: '#6b7280', mb: 4 }}>
                    Answer all questions carefully. You can review your answers before submitting.
                  </Typography>
                </Box>
                
                {test.questions.map((question, index) => (
                  <Paper 
                    key={question.qid} 
                    elevation={4}
                    sx={{ 
                      mb: 4, 
                      p: 4,
                      borderRadius: 3,
                      background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
                      border: '1px solid rgba(102, 126, 234, 0.1)',
                      transition: 'all 0.3s ease-in-out',
                      '&:hover': {
                        transform: 'translateY(-2px)',
                        boxShadow: '0 12px 40px rgba(102, 126, 234, 0.15)'
                      }
                    }}
                  >
                    <Box sx={{ display: 'flex', gap: 3, mb: 3, alignItems: 'flex-start' }}>
                      <Avatar 
                        sx={{ 
                          width: 48, 
                          height: 48, 
                          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                          boxShadow: '0 8px 24px rgba(102, 126, 234, 0.3)',
                          flexShrink: 0
                        }}
                      >
                        <Typography variant="h6" sx={{ color: 'white', fontWeight: 700 }}>
                          {index + 1}
                        </Typography>
                      </Avatar>
                      <Box sx={{ flex: 1 }}>
                        <Typography 
                          variant="h6" 
                          sx={{ 
                            fontWeight: 600,
                            color: '#2c3e50',
                            lineHeight: 1.4,
                            mb: 2
                          }}
                        >
                          {question.text}
                        </Typography>
                        <Chip 
                          label={`${question.marks} mark${question.marks > 1 ? 's' : ''}`} 
                          size="small"
                          sx={{
                            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                            color: 'white',
                            fontWeight: 600
                          }}
                        />
                      </Box>
                    </Box>

                    {question.type === 'mcq' ? (
                      <FormControl component="fieldset" sx={{ width: '100%' }}>
                        <RadioGroup
                          value={answers.find(a => a.qid === question.qid)?.selectedOptionIndex ?? ''}
                          onChange={(e) => handleAnswerChange(question.qid, parseInt(e.target.value), 'option')}
                        >
                          {question.options?.map((option, optionIndex) => (
                            <Paper
                              key={optionIndex}
                              elevation={1}
                              sx={{
                                mb: 2,
                                p: 2,
                                borderRadius: 2,
                                background: answers.find(a => a.qid === question.qid)?.selectedOptionIndex === optionIndex
                                  ? 'linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%)'
                                  : 'transparent',
                                border: answers.find(a => a.qid === question.qid)?.selectedOptionIndex === optionIndex
                                  ? '2px solid #667eea'
                                  : '1px solid rgba(102, 126, 234, 0.2)',
                                transition: 'all 0.2s ease-in-out',
                                cursor: 'pointer',
                                '&:hover': {
                                  background: 'linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%)',
                                  borderColor: '#667eea'
                                }
                              }}
                              onClick={() => handleAnswerChange(question.qid, optionIndex, 'option')}
                            >
                              <FormControlLabel
                                value={optionIndex}
                                control={
                                  <Radio 
                                    sx={{ 
                                      color: '#667eea',
                                      '&.Mui-checked': {
                                        color: '#667eea'
                                      }
                                    }} 
                                  />
                                }
                                label={
                                  <Typography 
                                    variant="body1" 
                                    sx={{ 
                                      fontWeight: 500,
                                      color: '#2c3e50'
                                    }}
                                  >
                                    {option}
                                  </Typography>
                                }
                                sx={{ width: '100%', m: 0 }}
                              />
                            </Paper>
                          ))}
                        </RadioGroup>
                      </FormControl>
                    ) : (
                      <TextField
                        multiline
                        rows={4}
                        fullWidth
                        placeholder="Enter your detailed answer here..."
                        value={answers.find(a => a.qid === question.qid)?.answerText ?? ''}
                        onChange={(e) => handleAnswerChange(question.qid, e.target.value, 'text')}
                        variant="outlined"
                        sx={{
                          '& .MuiOutlinedInput-root': {
                            borderRadius: 2,
                            '&:hover .MuiOutlinedInput-notchedOutline': {
                              borderColor: '#667eea',
                              borderWidth: 2
                            },
                            '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
                              borderColor: '#667eea',
                              borderWidth: 2
                            }
                          },
                          '& .MuiInputLabel-root.Mui-focused': {
                            color: '#667eea'
                          }
                        }}
                      />
                    )}
                  </Paper>
                ))}
              </Box>
            </Slide>
          )}

          {currentStep === 2 && (
            <Slide direction="up" in={currentStep === 2} mountOnEnter unmountOnExit>
              <Box sx={{ maxWidth: 700, mx: 'auto' }}>
                <Box sx={{ textAlign: 'center', mb: 4 }}>
                  <Avatar 
                    sx={{ 
                      width: 80, 
                      height: 80, 
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      boxShadow: '0 12px 40px rgba(102, 126, 234, 0.4)',
                      mx: 'auto',
                      mb: 2
                    }}
                  >
                    <EmojiEvents sx={{ fontSize: 40, color: 'white' }} />
                  </Avatar>
                  <Typography 
                    variant="h4" 
                    sx={{ 
                      fontWeight: 700,
                      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                      backgroundClip: 'text',
                      WebkitBackgroundClip: 'text',
                      WebkitTextFillColor: 'transparent',
                      mb: 2
                    }}
                  >
                    Almost There!
                  </Typography>
                  <Typography variant="h6" sx={{ color: '#6b7280', mb: 4 }}>
                    Review your information and submit your test
                  </Typography>
                </Box>

                <Paper 
                  elevation={4}
                  sx={{ 
                    p: 4, 
                    mb: 4,
                    borderRadius: 3,
                    background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)'
                  }}
                >
                  <Typography variant="h6" sx={{ mb: 3, fontWeight: 600, color: '#2c3e50' }}>
                    Student Information
                  </Typography>
                  
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                    <Person sx={{ color: '#667eea', fontSize: 24 }} />
                    <Typography variant="h6" sx={{ color: '#2c3e50', fontWeight: 500 }}>
                      {studentName}
                    </Typography>
                  </Box>
                  
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                    <Badge sx={{ color: '#764ba2', fontSize: 24 }} />
                    <Typography variant="body1" sx={{ color: '#6b7280' }}>Roll Number:</Typography>
                    <Typography variant="h6" sx={{ color: '#764ba2', fontWeight: 600 }}>
                      {rollNo}
                    </Typography>
                  </Box>
                </Paper>

                <Paper 
                  elevation={4}
                  sx={{ 
                    p: 4, 
                    mb: 4,
                    borderRadius: 3,
                    background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)'
                  }}
                >
                  <Typography variant="h6" sx={{ mb: 3, fontWeight: 600, color: '#2c3e50' }}>
                    Test Summary
                  </Typography>
                  
                  <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 3, mb: 3 }}>
                    <Box sx={{ textAlign: 'center', p: 2, background: 'linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%)', borderRadius: 2 }}>
                      <Typography variant="h4" sx={{ color: '#667eea', fontWeight: 700 }}>
                        {test.questions.length}
                      </Typography>
                      <Typography variant="body2" sx={{ color: '#6b7280' }}>
                        Total Questions
                      </Typography>
                    </Box>
                    <Box sx={{ textAlign: 'center', p: 2, background: 'linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%)', borderRadius: 2 }}>
                      <Typography variant="h4" sx={{ color: '#764ba2', fontWeight: 700 }}>
                        {test.questions.reduce((sum, q) => sum + q.marks, 0)}
                      </Typography>
                      <Typography variant="body2" sx={{ color: '#6b7280' }}>
                        Total Marks
                      </Typography>
                    </Box>
                  </Box>
                </Paper>

                <Alert 
                  severity="warning" 
                  sx={{ 
                    mb: 4,
                    borderRadius: 3,
                    '& .MuiAlert-icon': {
                      fontSize: 28
                    }
                  }}
                >
                  <Typography variant="body1" sx={{ fontWeight: 500 }}>
                    ⚠️ Please review your answers carefully. Once submitted, you cannot make changes.
                  </Typography>
                </Alert>
              </Box>
            </Slide>
          )}

          {/* Enhanced Navigation Buttons */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 4, gap: 2 }}>
            <Button
              onClick={handleBack}
              disabled={currentStep === 0}
              variant="outlined"
              startIcon={<ArrowBack />}
              sx={{
                borderRadius: 3,
                px: 4,
                py: 1.5,
                fontSize: '1.1rem',
                fontWeight: 600,
                borderColor: '#667eea',
                color: '#667eea',
                '&:hover': {
                  borderColor: '#5a67d8',
                  backgroundColor: 'rgba(102, 126, 234, 0.1)',
                  transform: 'translateY(-2px)',
                  boxShadow: '0 8px 24px rgba(102, 126, 234, 0.2)'
                },
                '&:disabled': {
                  borderColor: '#e2e8f0',
                  color: '#a0aec0'
                },
                transition: 'all 0.3s ease-in-out'
              }}
            >
              Back
            </Button>
            
            <Box sx={{ display: 'flex', gap: 2 }}>
              {currentStep < steps.length - 1 ? (
                <Button
                  onClick={handleNext}
                  variant="contained"
                  endIcon={<ArrowForward />}
                  sx={{
                    borderRadius: 3,
                    px: 4,
                    py: 1.5,
                    fontSize: '1.1rem',
                    fontWeight: 600,
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    boxShadow: '0 8px 24px rgba(102, 126, 234, 0.3)',
                    '&:hover': {
                      background: 'linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%)',
                      transform: 'translateY(-2px)',
                      boxShadow: '0 12px 32px rgba(102, 126, 234, 0.4)'
                    },
                    transition: 'all 0.3s ease-in-out'
                  }}
                >
                  {currentStep === 0 ? 'Start Test' : 'Continue'}
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  variant="contained"
                  disabled={submitting}
                  startIcon={submitting ? <CircularProgress size={20} color="inherit" /> : <Send />}
                  sx={{
                    borderRadius: 3,
                    px: 4,
                    py: 1.5,
                    fontSize: '1.1rem',
                    fontWeight: 600,
                    background: submitting 
                      ? 'linear-gradient(135deg, #a0aec0 0%, #718096 100%)'
                      : 'linear-gradient(135deg, #48bb78 0%, #38a169 100%)',
                    boxShadow: submitting 
                      ? '0 4px 16px rgba(160, 174, 192, 0.3)'
                      : '0 8px 24px rgba(72, 187, 120, 0.3)',
                    '&:hover': {
                      background: submitting 
                        ? 'linear-gradient(135deg, #a0aec0 0%, #718096 100%)'
                        : 'linear-gradient(135deg, #38a169 0%, #2f855a 100%)',
                      transform: submitting ? 'none' : 'translateY(-2px)',
                      boxShadow: submitting 
                        ? '0 4px 16px rgba(160, 174, 192, 0.3)'
                        : '0 12px 32px rgba(72, 187, 120, 0.4)'
                    },
                    transition: 'all 0.3s ease-in-out'
                  }}
                >
                  {submitting ? 'Submitting...' : 'Submit Test'}
                </Button>
              )}
            </Box>
          </Box>
        </Box>
      </Paper>

      {/* Enhanced Success Dialog */}
      <Dialog 
        open={showSuccessDialog} 
        maxWidth="sm" 
        fullWidth
        PaperProps={{
          sx: {
            borderRadius: 3,
            background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)'
          }
        }}
      >
        <DialogTitle sx={{ textAlign: 'center', pb: 2 }}>
          <Avatar 
            sx={{ 
              width: 80, 
              height: 80, 
              background: 'linear-gradient(135deg, #48bb78 0%, #38a169 100%)',
              boxShadow: '0 12px 40px rgba(72, 187, 120, 0.4)',
              mx: 'auto',
              mb: 2
            }}
          >
            <CheckCircle sx={{ fontSize: 40, color: 'white' }} />
          </Avatar>
          <Typography 
            variant="h4" 
            sx={{ 
              fontWeight: 700,
              background: 'linear-gradient(135deg, #48bb78 0%, #38a169 100%)',
              backgroundClip: 'text',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              mb: 1
            }}
          >
            Test Submitted Successfully!
          </Typography>
          <Typography variant="h6" sx={{ color: '#6b7280' }}>
            🎉 Congratulations on completing the test!
          </Typography>
        </DialogTitle>
        <DialogContent sx={{ textAlign: 'center', py: 3 }}>
          {submissionResult && (
            <Box>
              <Paper 
                elevation={4}
                sx={{ 
                  p: 4, 
                  mb: 3,
                  borderRadius: 3,
                  background: 'linear-gradient(135deg, rgba(72, 187, 120, 0.1) 0%, rgba(56, 161, 105, 0.1) 100%)'
                }}
              >
                <Typography variant="h6" sx={{ color: '#2c3e50', mb: 2, fontWeight: 600 }}>
                  Your Performance
                </Typography>
                <Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 2, mb: 3 }}>
                  <Box>
                    <Typography variant="h3" sx={{ color: '#48bb78', fontWeight: 700 }}>
                      {submissionResult.marksObtained}
                    </Typography>
                    <Typography variant="body2" sx={{ color: '#6b7280' }}>
                      Marks Obtained
                    </Typography>
                  </Box>
                  <Box>
                    <Typography variant="h3" sx={{ color: '#38a169', fontWeight: 700 }}>
                      {submissionResult.totalMarks}
                    </Typography>
                    <Typography variant="body2" sx={{ color: '#6b7280' }}>
                      Total Marks
                    </Typography>
                  </Box>
                </Box>
                <Box sx={{ 
                  p: 3, 
                  background: 'linear-gradient(135deg, #48bb78 0%, #38a169 100%)',
                  borderRadius: 2,
                  color: 'white'
                }}>
                  <Typography variant="h2" sx={{ fontWeight: 700, mb: 1 }}>
                    {submissionResult.percentage}%
                  </Typography>
                  <Typography variant="h6" sx={{ opacity: 0.9 }}>
                    Overall Score
                  </Typography>
                </Box>
              </Paper>
              <Typography variant="body1" sx={{ color: '#6b7280', fontStyle: 'italic' }}>
                Thank you for taking the test! Your results have been recorded.
              </Typography>
            </Box>
          )}
        </DialogContent>
        <DialogActions sx={{ justifyContent: 'center', pb: 4, px: 3 }}>
          <Button 
            onClick={handleCloseSuccess} 
            variant="contained" 
            size="large"
            sx={{
              borderRadius: 3,
              px: 4,
              py: 1.5,
              fontSize: '1.1rem',
              fontWeight: 600,
              background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
              boxShadow: '0 8px 24px rgba(102, 126, 234, 0.3)',
              '&:hover': {
                background: 'linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%)',
                transform: 'translateY(-2px)',
                boxShadow: '0 12px 32px rgba(102, 126, 234, 0.4)'
              },
              transition: 'all 0.3s ease-in-out'
            }}
          >
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default PublicTestPage;
