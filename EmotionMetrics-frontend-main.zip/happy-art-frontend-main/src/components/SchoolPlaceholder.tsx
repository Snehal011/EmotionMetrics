import { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Calendar, 
  BarChart3, 
  Menu, 
  X,
  GraduationCap,
  Heart,
  Clock,
  TrendingUp,
  TrendingDown,
  Plus,
  FileText,
  CheckCircle,
  BarChart,
  Palette,
  User,
  Loader2,
  AlertCircle,
  ChevronDown,
  LogOut,
  X as CloseIcon,
  ClipboardList,
  Target,
  Activity
} from 'lucide-react';
import api from '../lib/api';
import QuestionnairePage from './QuestionnairePage';
import AnalyticsPage from './AnalyticsPage';
import Chatbot, { ChatButton } from './Chatbot';
import SchoolDashboard from './SchoolDashboard';
import SchoolResultsView from './SchoolResultsView';
import HappinessDetection from './HappinessDetection';
import AssignedTests from './AssignedTests';
import SchoolResults from './SchoolResults';

// TypeScript interfaces for API responses
interface DashboardSummary {
  schoolName: string;
  logoUrl: string;
  studentsImpacted: number;
  studentsChange: number;
  avgHappiness: number;
  happinessChange: number;
  sessionsConducted: number;
}

interface RecentActivity {
  id: number;
  title: string;
  time: string;
  type: 'success' | 'info' | 'warning' | 'error';
  icon: string;
}

interface QuickAction {
  id: number;
  title: string;
  description: string;
  icon: string;
  color: string;
  iconBg: string;
  url?: string;
}

interface DashboardData {
  summary: DashboardSummary | null;
  recent: RecentActivity[];
  actions: QuickAction[];
}

interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: string;
  schoolName?: string;
}

interface StatDetail {
  title: string;
  description: string;
  data: Array<{
    label: string;
    value: string | number;
    trend?: string;
  }>;
  insights: string[];
}

export default function SchoolPlaceholder() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [selectedStat, setSelectedStat] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'questionnaire' | 'analytics' | 'assigned-tests' | 'test-results' | 'happiness-detection'>('dashboard');
  const [chatbotOpen, setChatbotOpen] = useState(false);
  const [dashboardData, setDashboardData] = useState<DashboardData>({
    summary: null,
    recent: [],
    actions: []
  });
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Icon mapping for dynamic icons
  const iconMap: { [key: string]: any } = {
    CheckCircle,
    BarChart,
    Palette,
    Users,
    GraduationCap,
    Heart,
    Clock,
    Plus,
    Calendar,
    FileText,
    TrendingUp,
    TrendingDown
  };

  // Fetch dashboard data from API
  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      setError(null);

      const [summaryResponse, recentResponse, actionsResponse, profileResponse] = await Promise.all([
        api.get('/api/dashboard/summary'),
        api.get('/api/dashboard/recent'),
        api.get('/api/dashboard/actions'),
        api.get('/api/user/profile')
      ]);

      // Enhanced data processing with better fallbacks
      const summaryData = summaryResponse.data || {};
      const profileData = profileResponse.data || {};

      setDashboardData({
        summary: {
          schoolName: summaryData.schoolName || profileData.schoolName || 'HappyArt School',
          logoUrl: summaryData.logoUrl || 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=80&h=80&fit=crop&crop=center',
          studentsImpacted: summaryData.studentsImpacted || 1245,
          studentsChange: summaryData.studentsChange || 12,
          avgHappiness: summaryData.avgHappiness || 8.7,
          happinessChange: summaryData.happinessChange || 0.3,
          sessionsConducted: summaryData.sessionsConducted || 56
        },
        recent: recentResponse.data || [
          {
            id: 1,
            title: 'New art therapy session completed',
            time: '2 hours ago',
            type: 'success',
            icon: 'CheckCircle'
          },
          {
            id: 2,
            title: 'Student progress report generated',
            time: '4 hours ago',
            type: 'info',
            icon: 'FileText'
          },
          {
            id: 3,
            title: 'Monthly analytics updated',
            time: '1 day ago',
            type: 'info',
            icon: 'BarChart'
          }
        ],
        actions: actionsResponse.data || [
          {
            id: 1,
            title: 'Schedule New Session',
            description: 'Create a new art therapy session',
            icon: 'Plus',
            color: 'bg-gradient-to-r from-blue-500 to-blue-600',
            iconBg: 'bg-blue-100'
          },
          {
            id: 2,
            title: 'View Reports',
            description: 'Access detailed analytics',
            icon: 'BarChart',
            color: 'bg-gradient-to-r from-green-500 to-green-600',
            iconBg: 'bg-green-100'
          },
          {
            id: 3,
            title: 'Manage Students',
            description: 'Update student information',
            icon: 'Users',
            color: 'bg-gradient-to-r from-purple-500 to-purple-600',
            iconBg: 'bg-purple-100'
          }
        ]
      });
      
      setUserProfile({
        id: profileData.id || '1',
        name: profileData.name || 'School Administrator',
        email: profileData.email || 'admin@happyartschool.com',
        role: profileData.role || 'school',
        schoolName: profileData.schoolName || summaryData.schoolName || 'HappyArt School'
      });
    } catch (err: any) {
      console.error('Error fetching dashboard data:', err);
      
      // Set fallback data when API fails
      setDashboardData({
        summary: {
          schoolName: 'HappyArt School',
          logoUrl: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=80&h=80&fit=crop&crop=center',
          studentsImpacted: 1245,
          studentsChange: 12,
          avgHappiness: 8.7,
          happinessChange: 0.3,
          sessionsConducted: 56
        },
        recent: [
          {
            id: 1,
            title: 'New art therapy session completed',
            time: '2 hours ago',
            type: 'success',
            icon: 'CheckCircle'
          },
          {
            id: 2,
            title: 'Student progress report generated',
            time: '4 hours ago',
            type: 'info',
            icon: 'FileText'
          }
        ],
        actions: [
          {
            id: 1,
            title: 'Schedule New Session',
            description: 'Create a new art therapy session',
            icon: 'Plus',
            color: 'bg-gradient-to-r from-blue-500 to-blue-600',
            iconBg: 'bg-blue-100'
          },
          {
            id: 2,
            title: 'View Reports',
            description: 'Access detailed analytics',
            icon: 'BarChart',
            color: 'bg-gradient-to-r from-green-500 to-green-600',
            iconBg: 'bg-green-100'
          }
        ]
      });
      
      setUserProfile({
        id: '1',
        name: 'School Administrator',
        email: 'admin@happyartschool.com',
        role: 'school',
        schoolName: 'HappyArt School'
      });
      
      // Handle different types of errors
      if (err.code === 'NETWORK_ERROR' || !err.response) {
        setError('Network error. Please check your connection and try again.');
      } else if (err.response?.status === 401) {
        setError('Authentication required. Please sign in again.');
      } else if (err.response?.status === 403) {
        setError('Access denied. You do not have permission to view this dashboard.');
      } else if (err.response?.status >= 500) {
        setError('Server error. Please try again later.');
      } else {
        setError(err.response?.data?.message || 'Failed to load dashboard data. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  // Logout function
  const handleLogout = () => {
    try {
      // Remove token from localStorage
      localStorage.removeItem('auth_token');
      
      // Redirect to login page
      window.location.href = '/signin';
    } catch (error) {
      console.error('Error during logout:', error);
      // Force redirect even if there's an error
      window.location.href = '/signin';
    }
  };

  // Get detailed information for each stat
  const getStatDetails = (statName: string): StatDetail => {
    switch (statName) {
      case 'Students Impacted':
        return {
          title: 'Students Impacted',
          description: 'Total number of students who have participated in art therapy programs',
          data: [
            { label: 'Total Students', value: '1,245', trend: '+12%' },
            { label: 'Active This Month', value: '156', trend: '+8%' },
            { label: 'New Enrollments', value: '23', trend: '+15%' },
            { label: 'Completion Rate', value: '94%', trend: '+2%' }
          ],
          insights: [
            'Student participation has increased by 12% compared to last month',
            '94% of students complete their art therapy programs',
            'New enrollments are up 15% this month',
            'Most active age group: 8-12 years old'
          ]
        };
      case 'Avg. Happiness Score':
        return {
          title: 'Average Happiness Score',
          description: 'Average happiness rating from student assessments',
          data: [
            { label: 'Current Score', value: '8.7/10', trend: '+0.3' },
            { label: 'Previous Month', value: '8.4/10', trend: '+0.3' },
            { label: 'Highest Score', value: '9.2/10', trend: 'This week' },
            { label: 'Improvement Rate', value: '85%', trend: '+5%' }
          ],
          insights: [
            'Happiness scores have improved by 0.3 points this month',
            '85% of students show improved mood after art therapy',
            'Peak happiness scores occur after group art sessions',
            'Students report feeling more creative and confident'
          ]
        };
      case 'Sessions Conducted':
        return {
          title: 'Sessions Conducted',
          description: 'Total number of art therapy sessions completed',
          data: [
            { label: 'Total Sessions', value: '56', trend: '+8' },
            { label: 'This Month', value: '12', trend: '+3' },
            { label: 'Group Sessions', value: '34', trend: '+6' },
            { label: 'Individual Sessions', value: '22', trend: '+2' }
          ],
          insights: [
            '8 more sessions conducted compared to last month',
            'Group sessions are more popular (60% of total)',
            'Average session duration: 45 minutes',
            'Student satisfaction rate: 96%'
          ]
        };
      default:
        return {
          title: 'No Data',
          description: 'No detailed information available',
          data: [],
          insights: []
        };
    }
  };

  // Fetch data on component mount
  useEffect(() => {
    fetchDashboardData();
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (profileDropdownOpen && !target.closest('.profile-dropdown')) {
        setProfileDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [profileDropdownOpen]);

  // Retry function for error state
  const handleRetry = () => {
    fetchDashboardData();
  };

  // Get school name with proper fallback
  const getSchoolName = () => {
    return dashboardData.summary?.schoolName || 
           userProfile?.schoolName || 
           'HappyArt School';
  };

  const navigation = [
    { name: 'Dashboard', icon: LayoutDashboard, current: currentPage === 'dashboard', page: 'dashboard' as const },
    { name: 'Assigned Tests', icon: ClipboardList, current: currentPage === 'assigned-tests', page: 'assigned-tests' as const },
    { name: 'Test Results', icon: BarChart3, current: currentPage === 'test-results', page: 'test-results' as const },
    { name: 'Happiness Detection', icon: Heart, current: currentPage === 'happiness-detection', page: 'happiness-detection' as const },
    { name: 'Questionnaire', icon: ClipboardList, current: currentPage === 'questionnaire', page: 'questionnaire' as const },
    { name: 'Analytics', icon: Target, current: currentPage === 'analytics', page: 'analytics' as const },
  ];

  // Generate dynamic stats from API data
  const getStats = () => {
    if (!dashboardData.summary) return [];
    
    const { studentsImpacted, studentsChange, avgHappiness, happinessChange, sessionsConducted } = dashboardData.summary;
    
    return [
      {
        name: 'Students Impacted',
        value: studentsImpacted.toLocaleString(),
        icon: GraduationCap,
        change: `${studentsChange > 0 ? '+' : ''}${studentsChange}%`,
        changeType: studentsChange >= 0 ? 'positive' : 'negative',
        gradient: 'from-blue-500 to-blue-600',
        bgColor: 'bg-gradient-to-br from-blue-50 to-blue-100'
      },
      {
        name: 'Avg. Happiness Score',
        value: `${avgHappiness.toFixed(1)}/10`,
        icon: Heart,
        change: `${happinessChange > 0 ? '+' : ''}${happinessChange.toFixed(1)}`,
        changeType: happinessChange >= 0 ? 'positive' : 'negative',
        gradient: 'from-pink-500 to-rose-500',
        bgColor: 'bg-gradient-to-br from-pink-50 to-rose-100'
      },
      {
        name: 'Sessions Conducted',
        value: sessionsConducted.toString(),
        icon: Clock,
        change: '+8', // This could be calculated from historical data
        changeType: 'positive',
        gradient: 'from-green-500 to-emerald-500',
        bgColor: 'bg-gradient-to-br from-green-50 to-emerald-100'
      }
    ];
  };

  // Generate dynamic recent activities from API data
  const getRecentActivities = () => {
    return dashboardData.recent.map(activity => {
      const IconComponent = iconMap[activity.icon] || CheckCircle;
      const typeStyles = {
        success: { iconColor: 'text-green-600', bgColor: 'bg-green-50' },
        info: { iconColor: 'text-blue-600', bgColor: 'bg-blue-50' },
        warning: { iconColor: 'text-yellow-600', bgColor: 'bg-yellow-50' },
        error: { iconColor: 'text-red-600', bgColor: 'bg-red-50' }
      };
      
      return {
        ...activity,
        icon: IconComponent,
        ...typeStyles[activity.type]
      };
    });
  };

  // Generate dynamic quick actions from API data
  const getQuickActions = () => {
    return dashboardData.actions.map(action => {
      const IconComponent = iconMap[action.icon] || Plus;
      return {
        ...action,
        icon: IconComponent
      };
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Modern Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm transition-all duration-300" 
            onClick={() => setSidebarOpen(false)} 
          />
        </div>
      )}

      {/* Modern Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 w-72 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 shadow-2xl transform transition-all duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0 flex flex-col ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        {/* Sidebar Header */}
        <div className="flex items-center justify-between h-20 px-6 border-b border-slate-700/50 flex-shrink-0">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <GraduationCap className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">School Portal</h1>
              <p className="text-xs text-slate-400">
                {loading ? (
                  <div className="h-3 w-24 bg-slate-600 rounded animate-pulse"></div>
                ) : (
                  getSchoolName()
                )}
              </p>
            </div>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/50 transition-all duration-200"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        {/* Sidebar Navigation */}
        <nav className="mt-8 px-4 flex-1">
          <div className="space-y-1">
            {navigation.map((item) => (
              <div key={item.name} className="relative">
                <button
                  onClick={() => setCurrentPage(item.page)}
                  className={`group relative flex items-center px-4 py-3.5 text-sm font-medium rounded-xl transition-all duration-300 w-full text-left ${
                    item.current
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg shadow-blue-500/25'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700/50 hover:shadow-md'
                  }`}
                >
                  {/* Active indicator */}
                  {item.current && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-white rounded-r-full"></div>
                  )}
                  
                  {/* Icon with enhanced styling */}
                  <div className={`mr-4 p-2 rounded-lg transition-all duration-300 ${
                    item.current 
                      ? 'bg-white/20 shadow-sm' 
                      : 'bg-slate-700/50 group-hover:bg-slate-600/50'
                  }`}>
                    <item.icon
                      className={`h-5 w-5 transition-all duration-300 ${
                        item.current ? 'text-white' : 'text-slate-400 group-hover:text-white'
                      }`}
                    />
                  </div>
                  
                  {/* Text with subtle animation */}
                  <span className="transition-all duration-300">{item.name}</span>
                  
                  {/* Hover effect overlay */}
                  <div className={`absolute inset-0 rounded-xl transition-opacity duration-300 ${
                    item.current 
                      ? 'bg-gradient-to-r from-blue-600/20 to-purple-600/20 opacity-100' 
                      : 'bg-gradient-to-r from-slate-600/0 to-slate-600/0 group-hover:from-slate-600/20 group-hover:to-slate-600/20'
                  }`}></div>
                </button>
              </div>
            ))}
          </div>
          
          {/* Navigation divider */}
          <div className="mt-8 mb-6">
            <div className="h-px bg-gradient-to-r from-transparent via-slate-600 to-transparent"></div>
          </div>
          
          {/* Additional navigation items */}
          <div className="space-y-1">
            <button className="group flex items-center px-4 py-3 text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-700/50 rounded-xl transition-all duration-300 w-full text-left">
              <div className="mr-4 p-2 rounded-lg bg-slate-700/50 group-hover:bg-slate-600/50 transition-all duration-300">
                <BarChart3 className="h-5 w-5 text-slate-400 group-hover:text-white transition-colors duration-300" />
              </div>
              <span>Reports</span>
            </button>
            
            <button className="group flex items-center px-4 py-3 text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-700/50 rounded-xl transition-all duration-300 w-full text-left">
              <div className="mr-4 p-2 rounded-lg bg-slate-700/50 group-hover:bg-slate-600/50 transition-all duration-300">
                <Users className="h-5 w-5 text-slate-400 group-hover:text-white transition-colors duration-300" />
              </div>
              <span>Students</span>
            </button>
          </div>
        </nav>
        
        {/* Modern Logout Section */}
        <div className="p-6 border-t border-slate-700/50 flex-shrink-0">
          <button
            onClick={handleLogout}
            className="group w-full bg-gradient-to-r from-red-600/20 to-red-500/20 hover:from-red-600/30 hover:to-red-500/30 border border-red-500/30 hover:border-red-400/50 rounded-xl p-4 transition-all duration-300 hover:shadow-lg hover:shadow-red-500/10"
          >
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-red-500/25 transition-all duration-300 group-hover:scale-105">
                <LogOut className="h-5 w-5 text-white group-hover:rotate-12 transition-transform duration-300" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm font-semibold text-white group-hover:text-red-100 transition-colors duration-300">
                  {loading ? (
                    <div className="h-4 w-20 bg-slate-600 rounded animate-pulse"></div>
                  ) : (
                    `Sign out from ${getSchoolName()}`
                  )}
                </p>
                <p className="text-xs text-slate-400 group-hover:text-red-300 transition-colors duration-300">
                  Click to logout securely
                </p>
              </div>
              <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse"></div>
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col">
        {/* Top bar */}
        <div className="sticky top-0 z-30 bg-white shadow-sm border-b border-gray-200">
          <div className="flex items-center justify-between h-16 px-4 lg:px-6">
            {/* Modern Mobile menu button - left side */}
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2.5 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-all duration-200 shadow-sm hover:shadow-md"
            >
              <Menu className="h-6 w-6" />
            </button>
            
            {/* Empty space for desktop - pushes profile to right */}
            <div className="hidden lg:block flex-1"></div>
            
            {/* Profile Dropdown - Top Right Corner */}
            <div className="relative profile-dropdown">
              <button
                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                className="flex items-center space-x-3 bg-gray-50 rounded-lg px-4 py-2 hover:bg-gray-100 transition-colors duration-200"
              >
                <div className="h-10 w-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                  <User className="h-5 w-5 text-white" />
                </div>
                <div className="text-left">
                  <p className="text-sm font-semibold text-gray-900">Welcome back,</p>
                  <p className="text-xs text-gray-600">
                    {loading ? (
                      <div className="h-3 w-20 bg-gray-200 rounded animate-pulse"></div>
                    ) : (
                      userProfile?.name || userProfile?.schoolName || 'School Admin'
                    )}
                  </p>
                </div>
                <ChevronDown className="h-4 w-4 text-gray-400" />
              </button>

              {/* Dropdown Menu */}
              {profileDropdownOpen && (
                <div className="absolute right-0 top-full mt-1 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-50">
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center space-x-3 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors duration-200"
                  >
                    <LogOut className="h-4 w-4 text-gray-400" />
                    <span>Logout</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Page content */}
        <div className="flex-1 bg-gradient-to-br from-slate-50 via-white to-slate-50">
          {currentPage === 'dashboard' && (
            <div className="p-4 lg:p-8 max-w-7xl mx-auto w-full">
              {/* Modern Education-Themed Hero Banner */}
              <div className="relative mb-10 rounded-3xl overflow-hidden shadow-2xl group">
                {/* Books/Education Background Image */}
                <img
                  src="https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=1200&h=400&fit=crop&crop=center"
                  alt="Education and Books Background"
                  className="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105"
                />
                
                {/* Dynamic Overlay based on school name length */}
                <div className={`absolute inset-0 ${
                  (() => {
                    const schoolName = getSchoolName();
                    const nameLength = schoolName.length;
                    
                    if (nameLength > 20) {
                      return 'bg-gradient-to-r from-blue-600/90 via-purple-600/90 to-indigo-600/90'; // Very long names
                    } else if (nameLength > 15) {
                      return 'bg-gradient-to-r from-blue-600/85 via-purple-600/85 to-indigo-600/85'; // Long names
                    } else if (nameLength > 10) {
                      return 'bg-gradient-to-r from-blue-600/80 via-purple-600/80 to-indigo-600/80'; // Medium names
                    } else {
                      return 'bg-gradient-to-r from-blue-600/75 via-purple-600/75 to-indigo-600/75'; // Short names
                    }
                  })()
                }`}></div>
                
                {/* Additional overlay for better text contrast */}
                <div className="absolute inset-0 bg-black/30"></div>
                
                {/* Content */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-white px-6">
                    <div className="mb-4">
                      <div className="inline-flex items-center justify-center w-16 h-16 bg-white/25 backdrop-blur-sm rounded-2xl mb-4 shadow-lg">
                        <GraduationCap className="h-8 w-8 text-white drop-shadow-lg" />
                      </div>
                    </div>
                    <h1 className="text-5xl font-bold mb-3 bg-gradient-to-r from-white via-blue-50 to-white bg-clip-text text-transparent drop-shadow-lg">
                      {loading ? (
                        <div className="flex items-center justify-center">
                          <Loader2 className="h-10 w-10 animate-spin mr-3 text-white drop-shadow-lg" />
                          <span className="text-3xl text-white drop-shadow-lg">Loading...</span>
                        </div>
                      ) : getSchoolName()}
                    </h1>
                    <p className="text-xl opacity-95 max-w-2xl mx-auto leading-relaxed text-white drop-shadow-md">
                      Empowering young minds through art and creativity • Building brighter futures together
                    </p>
                    <div className="mt-6 flex items-center justify-center space-x-6 text-sm opacity-90">
                      <div className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2">
                        <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                        <span className="text-white font-medium">Live Dashboard</span>
                      </div>
                      <div className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2">
                        <Heart className="h-4 w-4 text-white" />
                        <span className="text-white font-medium">Art Therapy Program</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

          {/* Modern School Info Card */}
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-white/20 p-8 mb-10 hover:shadow-2xl transition-all duration-300">
            <div className="flex items-center space-x-6">
              {loading ? (
                <div className="h-20 w-20 bg-gradient-to-br from-slate-200 to-slate-300 rounded-2xl animate-pulse"></div>
              ) : (
                <div className="relative">
                  <img
                    src={dashboardData.summary?.logoUrl || "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=80&h=80&fit=crop&crop=center"}
                    alt="School Logo"
                    className="h-20 w-20 rounded-2xl object-cover shadow-lg ring-4 ring-white/50"
                    onError={(e) => {
                      e.currentTarget.src = "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=80&h=80&fit=crop&crop=center";
                    }}
                  />
                  <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-emerald-500 rounded-full border-2 border-white flex items-center justify-center">
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  </div>
                </div>
              )}
              <div className="flex-1">
                <h2 className="text-3xl font-bold bg-gradient-to-r from-slate-900 to-slate-700 bg-clip-text text-transparent">
                  School Overview
                </h2>
                <p className="text-slate-600 mt-2 text-lg leading-relaxed">
                  Track your students' progress and manage art therapy sessions with real-time insights
                </p>
                <div className="flex items-center space-x-4 mt-4">
                  <div className="flex items-center space-x-2 text-sm text-slate-500">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span>Active Program</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-slate-500">
                    <Calendar className="h-4 w-4" />
                    <span>24/7 Monitoring</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="bg-gradient-to-br from-slate-50 to-slate-100 rounded-2xl p-4 border border-slate-200">
                  <p className="text-sm text-slate-500 mb-1">Last updated</p>
                  <p className="text-sm font-semibold text-slate-900">
                    {loading ? (
                      <div className="h-4 w-20 bg-slate-200 rounded animate-pulse"></div>
                    ) : (
                      'Just now'
                    )}
                  </p>
                  <div className="flex items-center space-x-1 mt-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                    <span className="text-xs text-emerald-600 font-medium">Live</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Error State */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-2xl p-6 mb-8" role="alert" aria-live="polite">
              <div className="flex items-center space-x-3">
                <AlertCircle className="h-6 w-6 text-red-600" aria-hidden="true" />
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-red-900">Error Loading Dashboard</h3>
                  <p className="text-red-700 mt-1">{error}</p>
                </div>
                <button
                  onClick={handleRetry}
                  className="flex items-center space-x-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors duration-200"
                  aria-label="Retry loading dashboard data"
                >
                  <AlertCircle className="h-4 w-4" aria-hidden="true" />
                  <span>Retry</span>
                </button>
              </div>
            </div>
          )}

          {/* Modern Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-10">
            {loading ? (
              // Enhanced loading skeletons
              Array.from({ length: 3 }).map((_, index) => (
                <div
                  key={index}
                  className="bg-white/60 backdrop-blur-sm rounded-3xl shadow-lg border border-white/20 p-8 animate-pulse"
                  aria-label="Loading dashboard statistics"
                >
                  <div className="flex items-center justify-between mb-6">
                    <div className="p-4 bg-gradient-to-br from-slate-200 to-slate-300 rounded-2xl"></div>
                    <div className="h-8 w-20 bg-slate-200 rounded-full"></div>
                  </div>
                  <div>
                    <div className="h-5 w-32 bg-slate-200 rounded mb-3"></div>
                    <div className="h-10 w-24 bg-slate-200 rounded"></div>
                  </div>
                </div>
              ))
            ) : (
              getStats().map((stat, index) => (
                <div
                  key={stat.name}
                  onClick={() => setSelectedStat(stat.name)}
                  className={`${stat.bgColor} rounded-3xl shadow-xl border border-white/30 p-8 hover:shadow-2xl transition-all duration-500 hover:scale-105 cursor-pointer group relative overflow-hidden`}
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  {/* Animated background gradient */}
                  <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-6">
                      <div className={`p-4 bg-white/90 rounded-2xl shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110`}>
                        <stat.icon className={`h-7 w-7 bg-gradient-to-r ${stat.gradient} bg-clip-text text-transparent`} />
                      </div>
                      <div className={`flex items-center text-sm font-bold px-3 py-2 rounded-full shadow-sm ${
                        stat.changeType === 'positive' 
                          ? 'text-emerald-700 bg-emerald-100 border border-emerald-200' 
                          : 'text-red-700 bg-red-100 border border-red-200'
                      }`}>
                        {stat.changeType === 'positive' ? (
                          <TrendingUp className="h-4 w-4 mr-1.5" />
                        ) : (
                          <TrendingDown className="h-4 w-4 mr-1.5" />
                        )}
                        {stat.change}
                      </div>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-slate-600 mb-2 group-hover:text-slate-700 transition-colors duration-300">
                        {stat.name}
                      </p>
                      <p className="text-4xl font-bold text-slate-900 group-hover:text-slate-800 transition-colors duration-300">
                        {stat.value}
                      </p>
                    </div>
                    
                    {/* Progress indicator */}
                    <div className="mt-4 h-1 bg-white/50 rounded-full overflow-hidden">
                      <div className={`h-full bg-gradient-to-r ${stat.gradient} rounded-full transition-all duration-1000 ${
                        stat.changeType === 'positive' ? 'w-4/5' : 'w-3/5'
                      }`}></div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Enhanced Content Area */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Modern Recent Activity */}
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-white/20 p-8 hover:shadow-2xl transition-all duration-300">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center space-x-3">
                  <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl shadow-lg">
                    <Activity className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">Recent Activity</h3>
                    <p className="text-sm text-slate-500">Live updates from your school</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2 text-sm text-emerald-600 bg-emerald-50 px-3 py-1.5 rounded-full border border-emerald-200">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                  <span className="font-medium">Live</span>
                </div>
              </div>
              <div className="space-y-6">
                {loading ? (
                  // Enhanced loading skeletons for activities
                  Array.from({ length: 4 }).map((_, index) => (
                    <div key={index} className="flex items-start space-x-4 animate-pulse">
                      <div className="p-3 bg-gradient-to-br from-slate-200 to-slate-300 rounded-2xl"></div>
                      <div className="flex-1 min-w-0">
                        <div className="h-5 w-4/5 bg-slate-200 rounded mb-2"></div>
                        <div className="h-4 w-1/3 bg-slate-200 rounded"></div>
                      </div>
                    </div>
                  ))
                ) : getRecentActivities().length > 0 ? (
                  getRecentActivities().map((activity, index) => (
                    <div key={activity.id} className="relative group">
                      {index !== getRecentActivities().length - 1 && (
                        <div className="absolute left-8 top-16 w-0.5 h-12 bg-gradient-to-b from-slate-200 to-transparent"></div>
                      )}
                      <div className="flex items-start space-x-4 p-3 rounded-2xl hover:bg-slate-50/50 transition-all duration-300 group-hover:shadow-sm">
                        <div className={`p-3 ${activity.bgColor} rounded-2xl shadow-sm group-hover:shadow-md transition-all duration-300`}>
                          <activity.icon className={`h-5 w-5 ${activity.iconColor}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold text-slate-900 group-hover:text-slate-800 transition-colors duration-300">
                            {activity.title}
                          </p>
                          <p className="text-xs text-slate-500 mt-1 group-hover:text-slate-600 transition-colors duration-300">
                            {activity.time}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-slate-100 to-slate-200 rounded-3xl mb-4">
                      <BarChart className="h-8 w-8 text-slate-400" />
                    </div>
                    <p className="text-slate-500 text-sm font-medium">No recent activity to display</p>
                    <p className="text-slate-400 text-xs mt-1">Activity will appear here as it happens</p>
                  </div>
                )}
              </div>
            </div>

            {/* Modern Quick Actions */}
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl shadow-xl border border-white/20 p-8 hover:shadow-2xl transition-all duration-300">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center space-x-3">
                  <div className="p-3 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl shadow-lg">
                    <Target className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">Quick Actions</h3>
                    <p className="text-sm text-slate-500">Common tasks and shortcuts</p>
                  </div>
                </div>
                <div className="text-sm text-slate-500 bg-slate-50 px-3 py-1.5 rounded-full border border-slate-200">
                  {getQuickActions().length} available
                </div>
              </div>
              <div className="space-y-4">
                {loading ? (
                  // Enhanced loading skeletons for actions
                  Array.from({ length: 3 }).map((_, index) => (
                    <div key={index} className="w-full bg-gradient-to-r from-slate-100 to-slate-200 rounded-2xl p-6 animate-pulse">
                      <div className="flex items-center space-x-4">
                        <div className="p-3 bg-slate-300 rounded-xl"></div>
                        <div className="text-left flex-1">
                          <div className="h-5 w-28 bg-slate-300 rounded mb-2"></div>
                          <div className="h-4 w-36 bg-slate-300 rounded"></div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : getQuickActions().length > 0 ? (
                  getQuickActions().map((action, index) => (
                    <button
                      key={action.id}
                      className={`w-full ${action.color} text-white rounded-2xl p-6 hover:shadow-xl transition-all duration-300 transform hover:scale-[1.02] group relative overflow-hidden`}
                      onClick={() => {
                        if (action.url) {
                          window.open(action.url, '_blank');
                          // window.open(action.url);
                        }
                      }}
                      style={{ animationDelay: `${index * 100}ms` }}
                    >
                      {/* Animated background overlay */}
                      <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/10 to-white/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                      
                      <div className="relative z-10 flex items-center space-x-4">
                        <div className={`p-3 ${action.iconBg} rounded-xl group-hover:bg-white/20 transition-all duration-300 group-hover:scale-110 shadow-lg`}>
                          <action.icon className="h-6 w-6 text-white" />
                        </div>
                        <div className="text-left flex-1">
                          <p className="font-bold text-base group-hover:text-white/95 transition-colors duration-300">
                            {action.title}
                          </p>
                          <p className="text-sm opacity-90 group-hover:opacity-95 transition-opacity duration-300">
                            {action.description}
                          </p>
                        </div>
                        <div className="opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-x-2 group-hover:translate-x-0">
                          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                        </div>
                      </div>
                    </button>
                  ))
                ) : (
                  <div className="text-center py-12">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-slate-100 to-slate-200 rounded-3xl mb-4">
                      <Plus className="h-8 w-8 text-slate-400" />
                    </div>
                    <p className="text-slate-500 text-sm font-medium">No quick actions available</p>
                    <p className="text-slate-400 text-xs mt-1">Actions will appear here when available</p>
                  </div>
                )}
              </div>
            </div>
          </div>
            </div>
          )}
          
          {/* Render other pages */}
          {currentPage === 'assigned-tests' && <AssignedTests />}
          {currentPage === 'test-results' && <SchoolResults />}
          {currentPage === 'happiness-detection' && <HappinessDetection />}
          {currentPage === 'questionnaire' && <QuestionnairePage />}
          {currentPage === 'analytics' && <AnalyticsPage />}
        </div>
      </div>

      {/* Stat Details Modal */}
      {selectedStat && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              {/* Modal Header */}
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">{getStatDetails(selectedStat).title}</h2>
                <button
                  onClick={() => setSelectedStat(null)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                >
                  <CloseIcon className="h-6 w-6 text-gray-400" />
                </button>
              </div>

              {/* Modal Content */}
              <div className="space-y-6">
                {/* Description */}
                <p className="text-gray-600 text-lg">{getStatDetails(selectedStat).description}</p>

                {/* Data Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {getStatDetails(selectedStat).data.map((item, index) => (
                    <div key={index} className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-600">{item.label}</span>
                        {item.trend && (
                          <span className="text-xs font-semibold text-green-600 bg-green-100 px-2 py-1 rounded-full">
                            {item.trend}
                          </span>
                        )}
                      </div>
                      <p className="text-2xl font-bold text-gray-900 mt-2">{item.value}</p>
                    </div>
                  ))}
                </div>

                {/* Insights */}
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Key Insights</h3>
                  <ul className="space-y-2">
                    {getStatDetails(selectedStat).insights.map((insight, index) => (
                      <li key={index} className="flex items-start space-x-3">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                        <span className="text-gray-700">{insight}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="flex justify-end mt-8 pt-6 border-t border-gray-200">
                <button
                  onClick={() => setSelectedStat(null)}
                  className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors duration-200"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Chatbot */}
      <Chatbot isOpen={chatbotOpen} onClose={() => setChatbotOpen(false)} />
      <ChatButton onClick={() => setChatbotOpen(true)} />
    </div>
  );
}


