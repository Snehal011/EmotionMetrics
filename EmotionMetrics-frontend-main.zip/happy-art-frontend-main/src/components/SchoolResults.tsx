import { useEffect, useState } from 'react';
import { 
  Download, 
  Filter, 
  Search, 
  Eye, 
  RefreshCw,
  AlertCircle,
  Users,
  TrendingUp,
  Calendar
} from 'lucide-react';

interface TestResult {
  id: string;
  questionnaireId: string;
  studentName: string;
  studentClass: string;
  studentRollNumber: string;
  totalScore: number;
  averageScore: number;
  submittedAt: string;
  answers: Array<{
    questionId: string;
    questionText: string;
    sectionTitle: string;
    selectedOption: string;
    score: number;
  }>;
}

export default function SchoolResults() {
  const [results, setResults] = useState<TestResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [total, setTotal] = useState(0);
  
  // Filters
  const [filters, setFilters] = useState({
    questionnaireId: '',
    studentClass: '',
    dateFrom: '',
    dateTo: '',
    search: ''
  });
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(20);
  
  // Selected result for details
  const [selectedResult, setSelectedResult] = useState<TestResult | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  useEffect(() => {
    fetchResults();
  }, [filters, currentPage]);

  const fetchResults = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // For now, we'll use mock data since the backend endpoints need to be implemented
      const mockResults: TestResult[] = [
        {
          id: '1',
          questionnaireId: 'q1',
          studentName: 'John Doe',
          studentClass: '10A',
          studentRollNumber: '101',
          totalScore: 45,
          averageScore: 4.5,
          submittedAt: '2024-01-15T10:30:00Z',
          answers: [
            {
              questionId: 'q1',
              questionText: 'The student is actively engaged in learning activities.',
              sectionTitle: 'Academic Behavior',
              selectedOption: '5 - Excellent',
              score: 5
            },
            {
              questionId: 'q2',
              questionText: 'The student consistently completes assignments on time.',
              sectionTitle: 'Academic Behavior',
              selectedOption: '4 - Very Good',
              score: 4
            }
          ]
        },
        {
          id: '2',
          questionnaireId: 'q1',
          studentName: 'Jane Smith',
          studentClass: '10B',
          studentRollNumber: '102',
          totalScore: 40,
          averageScore: 4.0,
          submittedAt: '2024-01-15T11:15:00Z',
          answers: [
            {
              questionId: 'q1',
              questionText: 'The student is actively engaged in learning activities.',
              sectionTitle: 'Academic Behavior',
              selectedOption: '4 - Very Good',
              score: 4
            },
            {
              questionId: 'q2',
              questionText: 'The student consistently completes assignments on time.',
              sectionTitle: 'Academic Behavior',
              selectedOption: '4 - Very Good',
              score: 4
            }
          ]
        }
      ];
      
      setResults(mockResults);
      setTotal(mockResults.length);
    } catch (err: any) {
      console.error('Error fetching results:', err);
      setError(err.response?.data?.message || 'Failed to load results');
    } finally {
      setLoading(false);
    }
  };

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
    setCurrentPage(1);
  };

  const handleExportCSV = () => {
    const csvContent = generateCSV(results);
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `test-results-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const generateCSV = (data: TestResult[]) => {
    const headers = [
      'Student Name',
      'Class',
      'Roll Number',
      'Total Score',
      'Average Score',
      'Submitted At'
    ];
    
    const rows = data.map(result => [
      result.studentName,
      result.studentClass,
      result.studentRollNumber,
      result.totalScore,
      result.averageScore,
      new Date(result.submittedAt).toLocaleString()
    ]);
    
    return [headers, ...rows].map(row => row.join(',')).join('\n');
  };

  const filteredResults = results.filter(result => {
    if (filters.search) {
      const searchTerm = filters.search.toLowerCase();
      return (
        result.studentName.toLowerCase().includes(searchTerm) ||
        result.studentClass.toLowerCase().includes(searchTerm) ||
        result.studentRollNumber.toLowerCase().includes(searchTerm)
      );
    }
    return true;
  });

  const totalPages = Math.ceil(total / pageSize);
  const startIndex = (currentPage - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedResults = filteredResults.slice(startIndex, endIndex);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading results...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="h-8 w-8 text-red-600 mx-auto mb-4" />
          <p className="text-gray-600 mb-4">{error}</p>
          <button
            onClick={fetchResults}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">School Test Results</h1>
          <p className="text-gray-600 mt-2">View test results for your school</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <Users className="h-8 w-8 text-blue-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Responses</p>
                <p className="text-2xl font-bold text-gray-900">{total}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <TrendingUp className="h-8 w-8 text-green-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Average Score</p>
                <p className="text-2xl font-bold text-gray-900">
                  {results.length > 0 
                    ? (results.reduce((sum, r) => sum + r.averageScore, 0) / results.length).toFixed(1)
                    : '0'
                  }
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <Calendar className="h-8 w-8 text-purple-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">This Month</p>
                <p className="text-2xl font-bold text-gray-900">
                  {results.filter(r => {
                    const date = new Date(r.submittedAt);
                    const now = new Date();
                    return date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
                  }).length}
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <Download className="h-8 w-8 text-orange-600" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Export</p>
                <button
                  onClick={handleExportCSV}
                  className="text-sm text-orange-600 hover:text-orange-700 font-medium"
                >
                  Download CSV
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Class</label>
              <input
                type="text"
                value={filters.studentClass}
                onChange={(e) => handleFilterChange('studentClass', e.target.value)}
                placeholder="Filter by class"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">From Date</label>
              <input
                type="date"
                value={filters.dateFrom}
                onChange={(e) => handleFilterChange('dateFrom', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">To Date</label>
              <input
                type="date"
                value={filters.dateTo}
                onChange={(e) => handleFilterChange('dateTo', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          
          <div className="mt-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                value={filters.search}
                onChange={(e) => handleFilterChange('search', e.target.value)}
                placeholder="Search by student name, class, or roll number..."
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>

        {/* Results Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Student
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Class
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Roll No
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Score
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Submitted
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {paginatedResults.map((result) => (
                  <tr key={result.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{result.studentName}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{result.studentClass}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{result.studentRollNumber}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {result.averageScore.toFixed(1)}/5.0
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {new Date(result.submittedAt).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <button
                        onClick={() => {
                          setSelectedResult(result);
                          setShowDetails(true);
                        }}
                        className="text-blue-600 hover:text-blue-800 flex items-center"
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        View Details
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="mt-6 flex items-center justify-between">
            <div className="text-sm text-gray-700">
              Showing {startIndex + 1} to {Math.min(endIndex, total)} of {total} results
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </button>
              <span className="px-3 py-2 text-sm text-gray-700">
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="px-3 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next
              </button>
            </div>
          </div>
        )}

        {/* Details Modal */}
        {showDetails && selectedResult && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-semibold text-gray-900">Student Response Details</h3>
                  <button
                    onClick={() => setShowDetails(false)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    ×
                  </button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Student Information</h4>
                    <p><strong>Name:</strong> {selectedResult.studentName}</p>
                    <p><strong>Class:</strong> {selectedResult.studentClass}</p>
                    <p><strong>Roll Number:</strong> {selectedResult.studentRollNumber}</p>
                  </div>
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Test Results</h4>
                    <p><strong>Total Score:</strong> {selectedResult.totalScore}</p>
                    <p><strong>Average Score:</strong> {selectedResult.averageScore.toFixed(1)}/5.0</p>
                    <p><strong>Submitted:</strong> {new Date(selectedResult.submittedAt).toLocaleString()}</p>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-900 mb-4">Question Responses</h4>
                  <div className="space-y-4">
                    {selectedResult.answers.map((answer, index) => (
                      <div key={answer.questionId} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <h5 className="font-medium text-gray-900">
                            {index + 1}. {answer.questionText}
                          </h5>
                          <span className="text-sm font-medium text-blue-600">
                            Score: {answer.score}/5
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">
                          <strong>Section:</strong> {answer.sectionTitle}
                        </p>
                        <p className="text-sm text-gray-900">
                          <strong>Answer:</strong> {answer.selectedOption}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
