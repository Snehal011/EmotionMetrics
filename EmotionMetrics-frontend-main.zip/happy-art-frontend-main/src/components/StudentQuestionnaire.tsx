import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { FileText, Send, CheckCircle } from 'lucide-react';
import { Question } from '../types';

interface StudentQuestionnaireProps {
  schoolId: string;
  onResponseSubmitted: () => void;
}

export default function StudentQuestionnaire({ schoolId, onResponseSubmitted }: StudentQuestionnaireProps) {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [responses, setResponses] = useState<Record<string, number>>({});
  const [studentRollNo, setStudentRollNo] = useState('');
  const [currentTestType, setCurrentTestType] = useState<'pre_test' | 'post_test'>('pre_test');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    fetchActiveQuestions();
  }, [currentTestType]);

  const fetchActiveQuestions = async () => {
    try {
      const { data, error } = await supabase
        .from('questions')
        .select('*')
        .eq('active', true)
        .eq('question_type', currentTestType)
        .or(`target_school_id.is.null,target_school_id.eq.${schoolId}`);

      if (error) throw error;
      setQuestions(data || []);
      
      // Reset responses when switching test types
      setResponses({});
    } catch (error) {
      console.error('Error fetching questions:', error);
    }
  };

  const handleResponseChange = (questionId: string, value: number) => {
    setResponses(prev => ({
      ...prev,
      [questionId]: value
    }));
  };

  const calculateHappinessScore = (responses: Record<string, number>) => {
    const values = Object.values(responses);
    if (values.length === 0) return 0;
    return values.reduce((sum, value) => sum + value, 0) / values.length;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!studentRollNo.trim() || questions.length === 0) return;

    const unansweredQuestions = questions.filter(q => !responses[q.id]);
    if (unansweredQuestions.length > 0) {
      alert('Please answer all questions before submitting.');
      return;
    }

    setLoading(true);

    try {
      // Submit individual responses
      const responsePromises = questions.map(question => 
        supabase.from('student_responses').insert({
          student_roll_no: studentRollNo,
          school_id: schoolId,
          question_id: question.id,
          response_value: responses[question.id],
          response_type: currentTestType
        })
      );

      await Promise.all(responsePromises);

      // Calculate and update happiness score
      const newScore = calculateHappinessScore(responses);
      
      // Check if student already has a happiness score record
      const { data: existingScore, error: fetchError } = await supabase
        .from('happiness_scores')
        .select('*')
        .eq('student_roll_no', studentRollNo)
        .eq('school_id', schoolId)
        .single();

      if (fetchError && fetchError.code !== 'PGRST116') {
        throw fetchError;
      }

      if (existingScore) {
        // Update existing record
        const updateData = currentTestType === 'pre_test' 
          ? { 
              pre_test_score: newScore, 
              overall_score: newScore, // For now, overall score is just the current test score
              updated_at: new Date().toISOString()
            }
          : { 
              post_test_score: newScore,
              overall_score: existingScore.pre_test_score 
                ? (existingScore.pre_test_score + newScore) / 2 
                : newScore,
              updated_at: new Date().toISOString()
            };

        await supabase
          .from('happiness_scores')
          .update(updateData)
          .eq('id', existingScore.id);
      } else {
        // Create new record
        await supabase.from('happiness_scores').insert({
          student_roll_no: studentRollNo,
          school_id: schoolId,
          [currentTestType === 'pre_test' ? 'pre_test_score' : 'post_test_score']: newScore,
          overall_score: newScore
        });
      }

      setSubmitted(true);
      setTimeout(() => {
        setSubmitted(false);
        setResponses({});
        setStudentRollNo('');
        onResponseSubmitted();
      }, 2000);

    } catch (error) {
      console.error('Error submitting responses:', error);
      alert('Error submitting responses. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <div className="text-center py-12">
        <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Thank You!</h2>
        <p className="text-gray-600">Your responses have been submitted successfully.</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-lg shadow p-6 mb-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <FileText className="w-8 h-8 text-blue-600 mr-3" />
            <h2 className="text-2xl font-bold text-gray-900">Student Questionnaire</h2>
          </div>
          <div className="flex space-x-4">
            <button
              onClick={() => setCurrentTestType('pre_test')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentTestType === 'pre_test'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Pre-Test
            </button>
            <button
              onClick={() => setCurrentTestType('post_test')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                currentTestType === 'post_test'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Post-Test
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label htmlFor="rollNo" className="block text-sm font-medium text-gray-700 mb-2">
              Student Roll Number
            </label>
            <input
              type="text"
              id="rollNo"
              value={studentRollNo}
              onChange={(e) => setStudentRollNo(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Enter your roll number"
              required
            />
          </div>

          {questions.length > 0 ? (
            <div className="space-y-6">
              <div className="border-t border-gray-200 pt-6">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  {currentTestType === 'pre_test' ? 'Pre-Test' : 'Post-Test'} Questions
                </h3>
                <p className="text-sm text-gray-600 mb-6">
                  Please rate each statement on a scale of 1 (Strongly Disagree) to 10 (Strongly Agree)
                </p>

                {questions.map((question, index) => (
                  <div key={question.id} className="bg-gray-50 rounded-lg p-6 mb-4">
                    <label className="block text-sm font-medium text-gray-900 mb-4">
                      {index + 1}. {question.question_text}
                    </label>
                    
                    <div className="flex flex-wrap gap-2">
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((value) => (
                        <label
                          key={value}
                          className={`flex items-center justify-center w-10 h-10 rounded-full border-2 cursor-pointer transition-all ${
                            responses[question.id] === value
                              ? 'border-blue-500 bg-blue-500 text-white'
                              : 'border-gray-300 hover:border-blue-300'
                          }`}
                        >
                          <input
                            type="radio"
                            name={`question_${question.id}`}
                            value={value}
                            checked={responses[question.id] === value}
                            onChange={() => handleResponseChange(question.id, value)}
                            className="sr-only"
                          />
                          <span className="text-sm font-medium">{value}</span>
                        </label>
                      ))}
                    </div>
                    
                    <div className="flex justify-between text-xs text-gray-500 mt-2">
                      <span>Strongly Disagree</span>
                      <span>Strongly Agree</span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={loading || Object.keys(responses).length !== questions.length}
                  className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Submitting...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Submit Responses
                    </>
                  )}
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center py-12">
              <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No Active Questions</h3>
              <p className="text-gray-500">
                No {currentTestType === 'pre_test' ? 'pre-test' : 'post-test'} questions are currently available.
                Please check back later or contact your administrator.
              </p>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}