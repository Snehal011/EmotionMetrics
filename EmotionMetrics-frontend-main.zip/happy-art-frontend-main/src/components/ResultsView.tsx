import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Card,
  CardContent,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  CircularProgress,
  Alert,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Button
} from '@mui/material';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer
} from 'recharts';
import { RefreshCw, TrendingUp, Users, Award, Target } from 'lucide-react';
import { Test, TestResult, getTests, getTestResults } from '../lib/api';

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

const ResultsView: React.FC = () => {
  const [tests, setTests] = useState<Test[]>([]);
  const [selectedTestId, setSelectedTestId] = useState<string>('');
  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchTests();
  }, []);

  useEffect(() => {
    if (selectedTestId) {
      fetchTestResults(selectedTestId);
    }
  }, [selectedTestId]);

  const fetchTests = async () => {
    try {
      setLoading(true);
      const response = await getTests();
      setTests(response.tests || []);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch tests');
    } finally {
      setLoading(false);
    }
  };

  const fetchTestResults = async (testId: string) => {
    try {
      setLoading(true);
      setError(null);
      const result = await getTestResults(testId);
      setTestResult(result);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch test results');
      setTestResult(null);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    if (selectedTestId) {
      fetchTestResults(selectedTestId);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'success';
      case 'expired': return 'error';
      case 'draft': return 'warning';
      case 'completed': return 'info';
      default: return 'default';
    }
  };

  const getGradeStatsData = () => {
    if (!testResult?.statistics.gradeStats) return [];
    
    return Object.entries(testResult.statistics.gradeStats).map(([grade, stats]) => ({
      grade,
      count: stats.count,
      averageMarks: stats.averageMarks,
      averagePercentage: (stats.averageMarks / testResult.totalMarks) * 100
    }));
  };

  const getMarksDistributionData = () => {
    if (!testResult?.results) return [];
    
    const ranges = [
      { range: '0-20%', min: 0, max: 20, count: 0 },
      { range: '21-40%', min: 21, max: 40, count: 0 },
      { range: '41-60%', min: 41, max: 60, count: 0 },
      { range: '61-80%', min: 61, max: 80, count: 0 },
      { range: '81-100%', min: 81, max: 100, count: 0 }
    ];

    testResult.results.forEach(result => {
      const percentage = result.percentage;
      const range = ranges.find(r => percentage >= r.min && percentage <= r.max);
      if (range) range.count++;
    });

    return ranges;
  };

  const getTopScorersData = () => {
    if (!testResult?.statistics.topScores) return [];
    
    return testResult.statistics.topScores.slice(0, 10).map((scorer, index) => ({
      rank: index + 1,
      name: scorer.studentName,
      marks: scorer.marksObtained,
      percentage: scorer.percentage,
      school: scorer.schoolName
    }));
  };

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4" component="h1">
          Test Results
        </Typography>
        <Button
          startIcon={<RefreshCw />}
          onClick={handleRefresh}
          disabled={loading || !selectedTestId}
        >
          Refresh
        </Button>
      </Box>

      {/* Test Selection */}
      <Card sx={{ mb: 3 }}>
        <CardContent>
          <FormControl fullWidth>
            <InputLabel>Select Test</InputLabel>
            <Select
              value={selectedTestId}
              onChange={(e) => setSelectedTestId(e.target.value)}
              label="Select Test"
            >
              {tests.map((test) => (
                <MenuItem key={test.id} value={test.id}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Typography>{test.name}</Typography>
                    <Chip
                      label={test.status}
                      size="small"
                      color={getStatusColor(test.status) as any}
                    />
                    <Typography variant="caption" color="text.secondary">
                      ({test.type}, Grade {test.grade})
                    </Typography>
                  </Box>
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </CardContent>
      </Card>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
          <CircularProgress />
        </Box>
      )}

      {testResult && !loading && (
        <>
          {/* Test Info */}
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h5" gutterBottom>
                {testResult.testName}
              </Typography>
              <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap' }}>
                <Chip label={testResult.testType} color="primary" />
                <Chip label={`Grade ${testResult.grade}`} />
                <Chip label={testResult.subject} />
                <Chip label={`Total Marks: ${testResult.totalMarks}`} />
              </Box>
            </CardContent>
          </Card>

          {/* Summary Statistics */}
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 3, mb: 3 }}>
            <Card sx={{ flex: '1 1 200px', minWidth: 200 }}>
              <CardContent sx={{ textAlign: 'center' }}>
                <Users size={32} color="#1976d2" />
                <Typography variant="h4" sx={{ mt: 1 }}>
                  {testResult.statistics.totalStudents}
                </Typography>
                <Typography color="text.secondary">
                  Total Students
                </Typography>
              </CardContent>
            </Card>
            <Card sx={{ flex: '1 1 200px', minWidth: 200 }}>
              <CardContent sx={{ textAlign: 'center' }}>
                <Target size={32} color="#2e7d32" />
                <Typography variant="h4" sx={{ mt: 1 }}>
                  {testResult.statistics.averageMarks.toFixed(1)}
                </Typography>
                <Typography color="text.secondary">
                  Average Marks
                </Typography>
              </CardContent>
            </Card>
            <Card sx={{ flex: '1 1 200px', minWidth: 200 }}>
              <CardContent sx={{ textAlign: 'center' }}>
                <TrendingUp size={32} color="#ed6c02" />
                <Typography variant="h4" sx={{ mt: 1 }}>
                  {testResult.statistics.averagePercentage.toFixed(1)}%
                </Typography>
                <Typography color="text.secondary">
                  Average Percentage
                </Typography>
              </CardContent>
            </Card>
            <Card sx={{ flex: '1 1 200px', minWidth: 200 }}>
              <CardContent sx={{ textAlign: 'center' }}>
                <Award size={32} color="#9c27b0" />
                <Typography variant="h4" sx={{ mt: 1 }}>
                  {testResult.statistics.topScores.length > 0 ? testResult.statistics.topScores[0].percentage.toFixed(1) : 0}%
                </Typography>
                <Typography color="text.secondary">
                  Highest Score
                </Typography>
              </CardContent>
            </Card>
          </Box>

          {/* Charts */}
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 3, mb: 3 }}>
            {/* Marks Distribution */}
            <Card sx={{ flex: '1 1 400px', minWidth: 400 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Marks Distribution
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={getMarksDistributionData()}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ range, count }: any) => `${range}: ${count}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                    >
                      {getMarksDistributionData().map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Grade-wise Performance */}
            <Card sx={{ flex: '1 1 400px', minWidth: 400 }}>
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  Grade-wise Performance
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={getGradeStatsData()}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="grade" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="averagePercentage" fill="#8884d8" name="Average %" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </Box>

          {/* Top Scorers */}
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Top Scorers
              </Typography>
              <TableContainer component={Paper} variant="outlined">
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Rank</TableCell>
                      <TableCell>Student Name</TableCell>
                      <TableCell>School</TableCell>
                      <TableCell align="right">Marks</TableCell>
                      <TableCell align="right">Percentage</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {getTopScorersData().map((scorer) => (
                      <TableRow key={scorer.rank}>
                        <TableCell>
                          <Chip
                            label={scorer.rank}
                            color={scorer.rank <= 3 ? 'primary' : 'default'}
                            size="small"
                          />
                        </TableCell>
                        <TableCell>{scorer.name}</TableCell>
                        <TableCell>{scorer.school}</TableCell>
                        <TableCell align="right">{scorer.marks}</TableCell>
                        <TableCell align="right">{scorer.percentage.toFixed(1)}%</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>

          {/* All Results */}
          <Card>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                All Results ({testResult.results.length} students)
              </Typography>
              <TableContainer component={Paper} variant="outlined" sx={{ maxHeight: 400 }}>
                <Table stickyHeader>
                  <TableHead>
                    <TableRow>
                      <TableCell>Student Name</TableCell>
                      <TableCell>Grade</TableCell>
                      <TableCell>School</TableCell>
                      <TableCell align="right">Marks</TableCell>
                      <TableCell align="right">Percentage</TableCell>
                      <TableCell>Submitted At</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {testResult.results.map((result, index) => (
                      <TableRow key={index}>
                        <TableCell>{result.studentName}</TableCell>
                        <TableCell>{result.grade}</TableCell>
                        <TableCell>{result.schoolName}</TableCell>
                        <TableCell align="right">{result.marksObtained}</TableCell>
                        <TableCell align="right">{result.percentage.toFixed(1)}%</TableCell>
                        <TableCell>
                          {new Date(result.submittedAt).toLocaleString()}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </>
      )}

      {!selectedTestId && !loading && (
        <Card>
          <CardContent sx={{ textAlign: 'center', py: 4 }}>
            <Typography variant="h6" color="text.secondary">
              Select a test to view results
            </Typography>
          </CardContent>
        </Card>
      )}
    </Box>
  );
};

export default ResultsView;
