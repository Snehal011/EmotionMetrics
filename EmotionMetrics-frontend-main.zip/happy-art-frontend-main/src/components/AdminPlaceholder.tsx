import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Building2, 
  BarChart3, 
  Menu, 
  X,
  User,
  ChevronDown,
  LogOut,
  Settings,
  FileText,
  Trash2,
  Eye,
  Edit,
  Calendar,
  Hash
} from 'lucide-react';
import { ListChecks } from 'lucide-react';
import api, { getSchools, createTest, publishTest } from '../lib/api';
import AdminResultsView from './AdminResultsView';
import QuestionnaireManager from './QuestionnaireManager';
import DefaultQuestionnaireEditor from './DefaultQuestionnaireEditor';
import Chatbot, { ChatButton } from './Chatbot';

interface OverviewData {
  totalSchools: number;
  totalBooksDistributed: number;
  totalChildrenImpacted: number;
  happinessScores: {
    before: number;
    after: number;
    improvement: number;
  };
  recentSessions: Array<{
    id: string;
    schoolName: string;
    date: string;
    participants: number;
    improvement: number;
  }>;
  lastUpdated: string;
}

interface School {
  id: string;
  name: string;
  email: string;
  address: string;
  phone: string;
  principalName: string;
  totalStudents: number;
  booksDistributed: number;
  lastActivity: string;
  happinessIndex: number;
  status: string;
  photoCount: number;
  recentSessions: Array<{
    id: string;
    date: string;
    participants: number;
    improvement: number;
  }>;
}

interface Photo {
  id: string;
  url: string;
  description: string;
  tags: string[];
  uploadedAt: string;
  schoolName: string;
  schoolId: string;
}

interface AnalyticsData {
  timeRange: {
    start: string;
    end: string;
    label: string;
  };
  happinessTrends: Array<{
    date: string;
    before: number;
    after: number;
    improvement: number;
  }>;
  schoolComparison: Array<{
    name: string;
    students: number;
    books: number;
    happinessImprovement: number;
    lastActivity: string;
  }>;
  heatmapData: Array<{
    date: string;
    school: string;
    emotions: Array<{
      emotion: string;
      count: number;
      percentage: number;
    }>;
  }>;
  summary: {
    totalSchools: number;
    totalStudents: number;
    totalBooks: number;
    averageImprovement: number;
  };
}

interface SavedQuestionnaire {
  id: string;
  title: string;
  description: string;
  createdAt: string;
  sections: Array<{
    id: string;
    title: string;
    intro?: string;
    questions: Array<{
      id: string;
      text: string;
      options: Array<{
        id: string;
        text: string;
      }>;
    }>;
  }>;
  totalQuestions: number;
}

// Saved Questionnaires Section Component
function SavedQuestionnairesSection() {
  const [savedQuestionnaires, setSavedQuestionnaires] = useState<SavedQuestionnaire[]>([]);
  const [selectedQuestionnaire, setSelectedQuestionnaire] = useState<SavedQuestionnaire | null>(null);
  const [showDetails, setShowDetails] = useState(false);
  const [schools, setSchools] = useState<Array<{ id: string; name: string; email: string }>>([]);
  const [selectedTypeById, setSelectedTypeById] = useState<Record<string, 'pre' | 'post'>>({});
  const [selectedSchoolById, setSelectedSchoolById] = useState<Record<string, string>>({});
  const [isPublishingId, setIsPublishingId] = useState<string | null>(null);
  const [showEdit, setShowEdit] = useState(false);
  const [editingQuestionnaire, setEditingQuestionnaire] = useState<SavedQuestionnaire | null>(null);

  const loadSavedQuestionnaires = () => {
    const saved = JSON.parse(localStorage.getItem('saved-questionnaires') || '[]');
    setSavedQuestionnaires(saved);
  };

  useEffect(() => {
    loadSavedQuestionnaires();
    // Listen for auth expiry and prompt re-login gracefully
    const onAuthExpired = () => {
      alert('Your session expired. Please sign in again to continue.');
    };
    window.addEventListener('auth:expired', onAuthExpired);
    // Load schools from API for selector
    (async () => {
      try {
        const schoolsData = await getSchools();
        const transformed = schoolsData.map((s: any) => ({ id: s._id || s.id || String(s._id || ''), _id: s._id, name: s.school_name || s.name, email: s.email }));
        setSchools(transformed);
        try { localStorage.setItem('cached_schools', JSON.stringify(transformed)); } catch {}
      } catch (e) {
        console.error('Failed to load schools for questionnaires section', e);
        // Fallback to cached schools to keep dropdown visible
        try {
          const cached = JSON.parse(localStorage.getItem('cached_schools') || '[]');
          if (Array.isArray(cached) && cached.length > 0) {
            setSchools(cached);
          }
        } catch {}
      }
    })();
    
    // Listen for storage changes to refresh when new questionnaires are saved
    const handleStorageChange = () => {
      loadSavedQuestionnaires();
    };
    
    window.addEventListener('storage', handleStorageChange);
    
    // Also check periodically for changes (in case of same-tab updates)
    const interval = setInterval(loadSavedQuestionnaires, 1000);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
      window.removeEventListener('auth:expired', onAuthExpired);
    };
  }, []);

  const deleteQuestionnaire = (id: string) => {
    if (confirm('Are you sure you want to delete this questionnaire?')) {
      const updated = savedQuestionnaires.filter(q => q.id !== id);
      setSavedQuestionnaires(updated);
      localStorage.setItem('saved-questionnaires', JSON.stringify(updated));
    }
  };

  const setType = (id: string, type: 'pre' | 'post') => {
    setSelectedTypeById((prev) => ({ ...prev, [id]: type }));
  };

  const setSchool = (qid: string, schoolValue: string) => {
    // Store raw value from <option value=...>. Options use Mongo _id as value.
    console.log('[SavedQuestionnairesSection] setSchool', { qid, schoolValue });
    setSelectedSchoolById((prev) => ({ ...prev, [qid]: String(schoolValue).trim() }));
  };

  const handlePublish = async (q: SavedQuestionnaire) => {
    const chosenType = selectedTypeById[q.id] || 'pre';
    let schoolId = selectedSchoolById[q.id];
    if (!schoolId) {
      alert('Please select a school before publishing.');
      return;
    }
    // Normalize school id: accept either MongoId or label, map to canonical id
    const mongoIdRegex = /^[a-f\d]{24}$/i;
    console.log('[SavedQuestionnairesSection] Publish start', { rawSelectedSchool: schoolId, chosenType, schools });
    const cleaned = String(schoolId || '').trim();
    if (!mongoIdRegex.test(cleaned)) {
      const norm = (v: any) => String(v || '').toLowerCase().replace(/[^a-z0-9]/g, '');
      const needle = norm(cleaned);
      const found = schools.find((s) => {
        const idMatch = mongoIdRegex.test(String(s.id));
        if (!idMatch && (s as any)._id && mongoIdRegex.test(String((s as any)._id))) return true; // ensure presence
        const nameNorm = norm(s.name);
        return nameNorm === needle || nameNorm.includes(needle) || needle.includes(nameNorm);
      });
      if (found) schoolId = (found as any).id || (found as any)._id;
    } else {
      schoolId = cleaned;
    }
    console.log('[SavedQuestionnairesSection] Normalized school id', { normalizedSchoolId: schoolId });
    if (!mongoIdRegex.test(String(schoolId))) {
      alert('Invalid school id selected.');
      return;
    }
    // Ensure admin auth token is present; backend will 401/403 otherwise
    const token = localStorage.getItem('auth_token');
    if (!token) {
      alert('Your admin session has expired. Please sign in again and retry publishing.');
      return;
    }
    try {
      setIsPublishingId(q.id);
      // Build Test payload from questionnaire
      const name = `${q.title} (${chosenType === 'pre' ? 'Pre' : 'Post'} Test)`;
      const now = new Date();
      const startTime = new Date(now.getTime() + 5 * 60 * 1000).toISOString(); // +5 min
      const endTime = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString(); // +7 days
      const questions = q.sections.flatMap((section) =>
        section.questions.map((ques) => {
          // Clean and validate option texts
          const optionTexts = (ques.options || [])
            .map((o) => (o.text || '').toString().trim())
            .filter((t) => t.length > 0);
          // Determine correct option: prefer stored correctOptionId; fallback to first option
          const correctIndex = (ques as any).correctOptionId
            ? (ques.options || []).findIndex((o) => o.id === (ques as any).correctOptionId)
            : 0;
          const correctOption = optionTexts[Math.max(0, correctIndex)] || optionTexts[0] || 'Option 1';
          return {
            text: (ques.text || '').toString().trim(),
            type: 'mcq' as const,
            options: optionTexts,
            correctOption,
            marks: 1,
          };
        })
      );

      // Filter out any invalid questions (empty text or fewer than 2 options)
      const validQuestions = questions.filter((qq) => qq.text.length > 0 && Array.isArray(qq.options) && qq.options.length >= 2);
      if (validQuestions.length === 0) {
        alert('No valid questions to publish. Please ensure each question has text and at least 2 options.');
        return;
      }

      // Provide sensible defaults for required fields not derived from questionnaire
      const createPayload = {
        name,
        type: chosenType,
        grade: 'N/A',
        subject: 'Happiness Assessment',
        durationMinutes: 30,
        startTime,
        endTime,
        questions: validQuestions,
      };
      console.log('[SavedQuestionnairesSection] createTest payload', createPayload);
      const created = await createTest(createPayload);
      console.log('[SavedQuestionnairesSection] createTest response', created);

      // API returns { message, test: { id, ... } }
      const testId = created?.test?.id || created?.test?._id || created?._id || created?.id;
      if (!testId) {
        console.error('Unexpected createTest response shape:', created);
        throw new Error('Test creation succeeded but no testId returned.');
      }

      // Publish to the selected school
      console.log('[SavedQuestionnairesSection] publishTest params', { testId, schoolId: String(schoolId).trim() });
      await publishTest(testId, [String(schoolId).trim()]);
      console.log('[SavedQuestionnairesSection] publishTest success');

      alert(`Published ${chosenType.toUpperCase()} test to ${schools.find((s) => s.id === schoolId)?.name || 'selected school'}. It should now appear under Assigned Tests with a public URL.`);
    } catch (e: any) {
      console.error('Publish failed', e);
      const serverMsg = e?.response?.data?.message || e?.response?.data?.error;
      const details = e?.response?.data?.errors ? `\nDetails: ${e.response.data.errors.map((er: any) => er.msg).join(', ')}` : '';
      alert((serverMsg || e?.message || 'Failed to create/publish test') + details);
    } finally {
      setIsPublishingId(null);
    }
  };

  const startEdit = (q: SavedQuestionnaire) => {
    // Create a deep copy for safe editing
    const copy: SavedQuestionnaire = JSON.parse(JSON.stringify(q));
    setEditingQuestionnaire(copy);
    setShowEdit(true);
  };

  const saveEdit = () => {
    if (!editingQuestionnaire) return;
    const updated = savedQuestionnaires.map((q) => (q.id === editingQuestionnaire.id ? editingQuestionnaire : q));
    setSavedQuestionnaires(updated);
    localStorage.setItem('saved-questionnaires', JSON.stringify(updated));
    setShowEdit(false);
    setEditingQuestionnaire(null);
  };

  const updateEditQuestionText = (sectionId: string, questionId: string, text: string) => {
    if (!editingQuestionnaire) return;
    const updated: SavedQuestionnaire = {
      ...editingQuestionnaire,
      sections: editingQuestionnaire.sections.map((s) =>
        s.id === sectionId
          ? { ...s, questions: s.questions.map((q) => (q.id === questionId ? { ...q, text } : q)) }
          : s
      ),
    };
    setEditingQuestionnaire(updated);
  };

  const loadQuestionnaire = (questionnaire: SavedQuestionnaire) => {
    setSelectedQuestionnaire(questionnaire);
    setShowDetails(true);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (savedQuestionnaires.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow border border-gray-200 p-6">
        <div className="text-center py-8">
          <div className="mx-auto w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
            <FileText className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Saved Questionnaires</h3>
          <p className="text-gray-500">Create and save your first questionnaire using the editor below.</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="bg-white rounded-xl shadow border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900">Saved Questionnaires</h3>
          <p className="text-gray-600 text-sm">Manage your saved questionnaire sets</p>
        </div>
        
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {savedQuestionnaires.map((questionnaire) => (
              <div key={questionnaire.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 text-sm truncate">{questionnaire.title}</h4>
                    <p className="text-xs text-gray-500 mt-1 truncate break-words whitespace-normal">{questionnaire.description}</p>
                  </div>
                  <button
                    onClick={() => deleteQuestionnaire(questionnaire.id)}
                    className="ml-2 text-red-500 hover:text-red-700 p-1"
                    title="Delete questionnaire"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                  <div className="flex items-center">
                    <Hash className="w-3 h-3 mr-1" />
                    {questionnaire.totalQuestions} questions
                  </div>
                  <div className="flex items-center">
                    <Calendar className="w-3 h-3 mr-1" />
                    {formatDate(questionnaire.createdAt)}
                  </div>
                </div>

                {/* Pre/Post toggle */}
                <div className="flex items-center gap-2 mb-3">
                  <button
                    className={`px-2 py-1 rounded text-xs ${ (selectedTypeById[questionnaire.id] || 'pre') === 'pre' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`}
                    onClick={() => setType(questionnaire.id, 'pre')}
                  >
                    Pre Test
                  </button>
                  <button
                    className={`px-2 py-1 rounded text-xs ${ (selectedTypeById[questionnaire.id] || 'pre') === 'post' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`}
                    onClick={() => setType(questionnaire.id, 'post')}
                  >
                    Post Test
                  </button>
                </div>

                {/* School selector */}
                <div className="mb-3">
                  <label className="block text-xs text-gray-600 mb-1">Select School</label>
                  <select
                    className="w-full px-2 py-1 border border-gray-300 rounded text-xs"
                    value={selectedSchoolById[questionnaire.id] || ''}
                    onChange={(e) => setSchool(questionnaire.id, e.target.value)}
                  >
                    <option value="">-- Choose school --</option>
                    {schools.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>
                
                <div className="flex space-x-2">
                  <button
                    onClick={() => loadQuestionnaire(questionnaire)}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded text-xs font-medium flex items-center justify-center"
                  >
                    <Eye className="w-3 h-3 mr-1" />
                    View
                  </button>
                  <button
                    onClick={() => startEdit(questionnaire)}
                    className="flex-1 bg-gray-600 hover:bg-gray-700 text-white px-3 py-2 rounded text-xs font-medium flex items-center justify-center"
                  >
                    <Edit className="w-3 h-3 mr-1" />
                    Edit
                  </button>
                  <button
                    onClick={() => handlePublish(questionnaire)}
                    disabled={isPublishingId === questionnaire.id}
                    className={`flex-1 ${isPublishingId === questionnaire.id ? 'bg-green-400' : 'bg-green-600 hover:bg-green-700'} text-white px-3 py-2 rounded text-xs font-medium`}
                  >
                    {isPublishingId === questionnaire.id ? 'Publishing...' : 'Publish'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Questionnaire Details Modal */}
      {showDetails && selectedQuestionnaire && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-2/3 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">{selectedQuestionnaire.title}</h3>
                <button
                  onClick={() => setShowDetails(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <span className="text-2xl">&times;</span>
                </button>
              </div>

              <div className="max-h-96 overflow-y-auto">
                <div className="mb-4">
                  <p className="text-gray-600 text-sm">{selectedQuestionnaire.description}</p>
                  <div className="flex items-center mt-2 text-xs text-gray-500">
                    <Hash className="w-3 h-3 mr-1" />
                    {selectedQuestionnaire.totalQuestions} questions
                    <Calendar className="w-3 h-3 ml-4 mr-1" />
                    Created: {formatDate(selectedQuestionnaire.createdAt)}
                  </div>
                </div>

                <div className="space-y-4">
                  {selectedQuestionnaire.sections.map((section) => (
                    <div key={section.id} className="border rounded-lg p-4">
                      <h4 className="font-semibold text-gray-900 mb-2">{section.title}</h4>
                      {section.intro && <p className="text-sm text-gray-600 mb-3">{section.intro}</p>}
                      
                      <div className="space-y-3">
                        {section.questions.map((question, idx) => (
                          <div key={question.id} className="bg-gray-50 rounded p-3">
                            <p className="text-sm font-medium text-gray-700 mb-2">
                              {idx + 1}. {question.text}
                            </p>
                            <div className="space-y-1">
                              {question.options.map((option) => (
                                <div key={option.id} className="flex items-center text-xs text-gray-600">
                                  <div className="w-2 h-2 bg-gray-400 rounded-full mr-2"></div>
                                  {option.text}
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end mt-4">
                <button
                  onClick={() => setShowDetails(false)}
                  className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Questionnaire Modal */}
      {showEdit && editingQuestionnaire && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-10 mx-auto p-5 border w-11/12 md:w-4/5 lg:w-3/4 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">Edit Questionnaire</h3>
                <button onClick={() => setShowEdit(false)} className="text-gray-400 hover:text-gray-600">
                  <span className="text-2xl">&times;</span>
                </button>
              </div>

              <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-1">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Title</label>
                  <input
                    className="w-full px-3 py-2 border border-gray-300 rounded"
                    value={editingQuestionnaire.title}
                    onChange={(e) => setEditingQuestionnaire({ ...editingQuestionnaire, title: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded"
                    value={editingQuestionnaire.description}
                    onChange={(e) => setEditingQuestionnaire({ ...editingQuestionnaire, description: e.target.value })}
                  />
                </div>

                {'ratingScaleText' in editingQuestionnaire && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Rating Scale Text</label>
                    <textarea
                      rows={2}
                      className="w-full px-3 py-2 border border-gray-300 rounded"
                      value={(editingQuestionnaire as any).ratingScaleText || ''}
                      onChange={(e) => setEditingQuestionnaire({ ...editingQuestionnaire, ...( { ratingScaleText: e.target.value } as any ) })}
                    />
                  </div>
                )}

                <div className="space-y-4">
                  {editingQuestionnaire.sections.map((section) => (
                    <div key={section.id} className="border rounded p-3">
                      <div className="mb-2">
                        <div className="font-semibold text-gray-900 text-sm">{section.title}</div>
                        {section.intro && <div className="text-xs text-gray-600">{section.intro}</div>}
                      </div>
                      <div className="space-y-2">
                        {section.questions.map((q, idx) => (
                          <div key={q.id} className="bg-gray-50 p-2 rounded">
                            <div className="text-xs text-gray-500 mb-1">Question {idx + 1}</div>
                            <input
                              className="w-full px-2 py-1 border border-gray-300 rounded text-sm"
                              value={q.text}
                              onChange={(e) => updateEditQuestionText(section.id, q.id, e.target.value)}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 mt-4">
                <button onClick={() => setShowEdit(false)} className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400">Cancel</button>
                <button onClick={saveEdit} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Save Changes</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default function AdminDashboard() {
  const { logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileDropdownOpen, setProfileDropdownOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('results');
  const [overviewData, setOverviewData] = useState<OverviewData | null>(null);
  const [schools, setSchools] = useState<School[]>([]);
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [modalContent, setModalContent] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  // ...existing code...
  const [isMobileView, setIsMobileView] = useState(false);
  const [chatbotOpen, setChatbotOpen] = useState(false);

  // Navigation structure
  const navigation = [
    { name: 'Questionnaires', icon: ListChecks, current: activeTab === 'questionnaires', page: 'questionnaires' as const },
    { name: 'Results', icon: FileText, current: activeTab === 'results', page: 'results' as const },
    { name: 'School Distribution', icon: Building2, current: activeTab === 'schools', page: 'schools' as const },
    { name: 'Analytics', icon: BarChart3, current: activeTab === 'analytics', page: 'analytics' as const },
  ];

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (profileDropdownOpen && !target.closest('.profile-dropdown')) {
        setProfileDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [profileDropdownOpen]);

  useEffect(() => {
    const loadData = async () => {
      await Promise.all([
        fetchOverviewData(),
        fetchSchools(),
        fetchPhotos(),
        fetchAnalytics()
      ]);
      setLoading(false);
    };
    loadData();
  }, []);

  // ...existing code...

  // Detect screen size for mobile view
  useEffect(() => {
    const checkScreenSize = () => {
      setIsMobileView(window.innerWidth < 768);
    };
    
    checkScreenSize();
    window.addEventListener('resize', checkScreenSize);
    
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  const fetchOverviewData = async () => {
    try {
      const response = await api.get('/api/admin/overview');
      setOverviewData(response.data);
    } catch (error) {
      console.error('Error fetching overview data:', error);
    }
  };

  const fetchSchools = async () => {
    try {
      const response = await api.get('/api/admin/schools');
      setSchools(response.data);
    } catch (error) {
      console.error('Error fetching schools:', error);
    }
  };

  const fetchPhotos = async () => {
    try {
      const response = await api.get('/api/admin/photos');
      setPhotos(response.data);
    } catch (error) {
      console.error('Error fetching photos:', error);
    }
  };

  const fetchAnalytics = async () => {
    try {
      const response = await api.get('/api/admin/analytics');
      setAnalyticsData(response.data);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    }
  };

  // ...existing code...

  const showSchoolDetails = async (school: School) => {
    try {
      const response = await api.get(`/api/admin/school/${school.id}/details`);
      setModalContent({
        type: 'school-details',
        data: response.data
      });
      setShowModal(true);
    } catch (error) {
      console.error('Error fetching school details:', error);
    }
  };

  const showPhotoDetails = (photo: Photo) => {
    setModalContent({
      type: 'photo-details',
      data: photo
    });
    setShowModal(true);
  };

  const showAnalyticsDetails = () => {
    setModalContent({
      type: 'analytics-details',
      data: analyticsData
    });
    setShowModal(true);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Modern Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm transition-all duration-300" 
            onClick={() => setSidebarOpen(false)} 
          />
        </div>
      )}

      {/* Modern Admin Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 w-72 bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 shadow-2xl transform transition-all duration-300 ease-in-out lg:translate-x-0 flex flex-col ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        {/* Sidebar Header */}
        <div className="flex items-center justify-between h-20 px-6 border-b border-slate-700/50 flex-shrink-0">
          <div className="flex items-center space-x-3">
            <div className="h-10 w-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center shadow-lg">
              <Settings className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Admin Portal</h1>
              <p className="text-xs text-slate-400">System Management</p>
            </div>
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700/50 transition-all duration-200"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        
        {/* Sidebar Navigation */}
        <nav className="flex-1 overflow-y-auto py-8 px-4">
          <div className="space-y-1">
            {navigation.map((item) => (
              <div key={item.name} className="relative">
                <button
                  onClick={() => setActiveTab(item.page)}
                  className={`group relative flex items-center px-4 py-3.5 text-sm font-medium rounded-xl transition-all duration-300 w-full text-left ${
                    item.current
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-500/25'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700/50 hover:shadow-md'
                  }`}
                >
                  {/* Active indicator */}
                  {item.current && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-white rounded-r-full"></div>
                  )}
                  
                  {/* Icon with enhanced styling */}
                  <div className={`mr-4 p-2 rounded-lg transition-all duration-300 ${
                    item.current 
                      ? 'bg-white/20 shadow-sm' 
                      : 'bg-slate-700/50 group-hover:bg-slate-600/50'
                  }`}>
                    <item.icon
                      className={`h-5 w-5 transition-all duration-300 ${
                        item.current ? 'text-white' : 'text-slate-400 group-hover:text-white'
                      }`}
                    />
                  </div>
                  
                  {/* Text with subtle animation */}
                  <span className="transition-all duration-300">{item.name}</span>
                  
                  {/* Hover effect overlay */}
                  <div className={`absolute inset-0 rounded-xl transition-opacity duration-300 ${
                    item.current 
                      ? 'bg-gradient-to-r from-emerald-600/20 to-teal-600/20 opacity-100' 
                      : 'bg-gradient-to-r from-slate-600/0 to-slate-600/0 group-hover:from-slate-600/20 group-hover:to-slate-600/20'
                  }`}></div>
                </button>
              </div>
            ))}
          </div>
          
          {/* Navigation divider */}
          <div className="mt-8 mb-6">
            <div className="h-px bg-gradient-to-r from-transparent via-slate-600 to-transparent"></div>
          </div>
          
          {/* Additional navigation items removed as requested */}
        </nav>
        
        {/* Modern Logout Section */}
        <div className="p-6 border-t border-slate-700/50 flex-shrink-0">
          <button
            onClick={logout}
            className="group w-full bg-gradient-to-r from-red-600/20 to-red-500/20 hover:from-red-600/30 hover:to-red-500/30 border border-red-500/30 hover:border-red-400/50 rounded-xl p-4 transition-all duration-300 hover:shadow-lg hover:shadow-red-500/10"
          >
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-gradient-to-br from-red-500 to-red-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-red-500/25 transition-all duration-300 group-hover:scale-105">
                <LogOut className="h-5 w-5 text-white group-hover:rotate-12 transition-transform duration-300" />
              </div>
              <div className="flex-1 text-left">
                <p className="text-sm font-semibold text-white group-hover:text-red-100 transition-colors duration-300">
                  Sign out from Admin Portal
                </p>
                <p className="text-xs text-slate-400 group-hover:text-red-300 transition-colors duration-300">
                  Click to logout securely
                </p>
              </div>
              <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="w-2 h-2 bg-red-400 rounded-full animate-pulse"></div>
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col lg:ml-72">
        {/* Top bar */}
        <div className="sticky top-0 z-30 bg-white shadow-sm border-b border-gray-200">
          <div className="flex items-center justify-between h-16 px-4 lg:px-6">
            {/* Modern Mobile menu button - left side */}
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2.5 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-all duration-200 shadow-sm hover:shadow-md"
            >
              <Menu className="h-6 w-6" />
            </button>
            
            {/* Empty space for desktop - pushes profile to right */}
            <div className="hidden lg:block flex-1"></div>
            
            {/* Profile Dropdown - Top Right Corner */}
            <div className="relative profile-dropdown">
              <button
                onClick={() => setProfileDropdownOpen(!profileDropdownOpen)}
                className="flex items-center space-x-3 bg-gray-50 rounded-lg px-4 py-2 hover:bg-gray-100 transition-colors duration-200"
              >
                <div className="h-10 w-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full flex items-center justify-center">
                  <User className="h-5 w-5 text-white" />
                </div>
                <div className="text-left">
                  <p className="text-sm font-semibold text-gray-900">Welcome back,</p>
                  <p className="text-xs text-gray-600">Admin User</p>
                </div>
                <ChevronDown className="h-4 w-4 text-gray-400" />
              </button>

              {/* Dropdown Menu */}
              {profileDropdownOpen && (
                <div className="absolute right-0 top-full mt-1 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1 z-50">
                  <button
                    onClick={logout}
                    className="w-full flex items-center space-x-3 px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 transition-colors duration-200"
                  >
                    <LogOut className="h-4 w-4 text-gray-400" />
                    <span>Logout</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Page content */}
        <div className="flex-1 bg-gradient-to-br from-slate-50 via-white to-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {/* Modern Admin Hero Banner */}
            <div className="relative mb-10 rounded-3xl overflow-hidden shadow-2xl group">
              {/* Education/Administration Background Image */}
              <img
                src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=1200&h=400&fit=crop&crop=center"
                alt="Modern Education Technology Background"
                className="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105"
              />
              
              {/* Dynamic Overlay based on admin context */}
              <div className="absolute inset-0 bg-gradient-to-r from-emerald-600/80 via-teal-600/80 to-cyan-600/80"></div>
              
              {/* Additional overlay for better text contrast */}
              <div className="absolute inset-0 bg-black/25"></div>
              
              {/* Content */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center text-white px-6">
                  <div className="mb-4">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-white/25 backdrop-blur-sm rounded-2xl mb-4 shadow-lg">
                      <Settings className="h-8 w-8 text-white drop-shadow-lg" />
                    </div>
                  </div>
                  <h1 className="text-5xl font-bold mb-3 bg-gradient-to-r from-white via-emerald-50 to-white bg-clip-text text-transparent drop-shadow-lg">
                    Admin Dashboard
                  </h1>
                  <p className="text-xl opacity-95 max-w-2xl mx-auto leading-relaxed text-white drop-shadow-md">
                    Comprehensive school management and analytics • Empowering education through technology
                  </p>
                  <div className="mt-6 flex items-center justify-center space-x-6 text-sm opacity-90">
                    <div className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2">
                      <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                      <span className="text-white font-medium">System Management</span>
                    </div>
                    <div className="flex items-center space-x-2 bg-white/20 backdrop-blur-sm rounded-full px-4 py-2">
                      <BarChart3 className="h-4 w-4 text-white" />
                      <span className="text-white font-medium">Analytics & Reports</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

        {activeTab === 'overview' && overviewData && (
          <div className="space-y-6">
            {/* Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1562774053-701939374585?w=100&h=100&fit=crop&crop=center" 
                      alt="School Building"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Schools</p>
                    <p className="text-2xl font-bold text-gray-900">{overviewData.totalSchools}</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setModalContent({
                      type: 'schools-list',
                      data: schools
                    });
                    setShowModal(true);
                  }}
                  className="mt-2 text-blue-600 hover:text-blue-800 text-sm font-medium"
                >
                  View Details →
                </button>
              </div>

              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=100&h=100&fit=crop&crop=center" 
                      alt="Books and Education"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Books Distributed</p>
                    <p className="text-2xl font-bold text-gray-900">{overviewData.totalBooksDistributed}</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setModalContent({
                      type: 'books-distribution',
                      data: schools.map(s => ({ name: s.name, books: s.booksDistributed }))
                    });
                    setShowModal(true);
                  }}
                  className="mt-2 text-green-600 hover:text-green-800 text-sm font-medium"
                >
                  View Details →
                </button>
              </div>

              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=100&h=100&fit=crop&crop=center" 
                      alt="Students Learning"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Children Impacted</p>
                    <p className="text-2xl font-bold text-gray-900">{overviewData.totalChildrenImpacted}</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setModalContent({
                      type: 'children-impact',
                      data: schools.map(s => ({ name: s.name, students: s.totalStudents }))
                    });
                    setShowModal(true);
                  }}
                  className="mt-2 text-purple-600 hover:text-purple-800 text-sm font-medium"
                >
                  View Details →
                </button>
              </div>

              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center">
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=100&h=100&fit=crop&crop=center" 
                      alt="Happy Children"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Happiness Improvement</p>
                    <p className="text-2xl font-bold text-gray-900">{overviewData.happinessScores.improvement}%</p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setModalContent({
                      type: 'happiness-scores',
                      data: {
                        before: overviewData.happinessScores.before,
                        after: overviewData.happinessScores.after,
                        improvement: overviewData.happinessScores.improvement
                      }
                    });
                    setShowModal(true);
                  }}
                  className="mt-2 text-yellow-600 hover:text-yellow-800 text-sm font-medium"
                >
                  View Details →
                </button>
              </div>
            </div>

            {/* Recent Sessions */}
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-900">Recent Sessions</h3>
              </div>
              <div className="divide-y divide-gray-200">
                {overviewData.recentSessions.map((session) => (
                  <div key={session.id} className="px-6 py-4 hover:bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-900">{session.schoolName}</p>
                        <p className="text-sm text-gray-500">{formatDate(session.date)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-900">{session.participants} participants</p>
                        <p className="text-sm text-green-600">+{session.improvement}% improvement</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'schools' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">School Distribution</h2>
              <button
                onClick={() => {
                  setModalContent({ type: 'add-school', data: null });
                  setShowModal(true);
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium"
              >
                Add New School
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {schools.map((school) => (
                <div key={school.id} className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start space-x-3">
                      <img 
                        src="https://images.unsplash.com/photo-1562774053-701939374585?w=100&h=100&fit=crop&crop=center" 
                        alt={`${school.name} School`}
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{school.name}</h3>
                      <p className="text-sm text-gray-600">{school.principalName}</p>
                      </div>
                    </div>
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      school.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {school.status}
                    </span>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Students:</span>
                      <span className="font-medium">{school.totalStudents}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Books Distributed:</span>
                      <span className="font-medium">{school.booksDistributed}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Happiness Index:</span>
                      <span className="font-medium text-green-600">+{school.happinessIndex}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Last Activity:</span>
                      <span className="font-medium">{formatDate(school.lastActivity)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Photos:</span>
                      <span className="font-medium">{school.photoCount}</span>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <button
                      onClick={() => showSchoolDetails(school)}
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded text-sm font-medium"
                    >
                      View Details
                    </button>
                    <button
                      onClick={() => {
                        setModalContent({
                          type: 'school-sessions',
                          data: school.recentSessions
                        });
                        setShowModal(true);
                      }}
                      className="flex-1 bg-gray-600 hover:bg-gray-700 text-white px-3 py-2 rounded text-sm font-medium"
                    >
                      Sessions
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ...existing code... */}

        {activeTab === 'results' && (
          <AdminResultsView />
        )}

        {activeTab === 'questionnaires' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Questionnaires</h2>
                <p className="text-gray-600">Create and manage Pre/Post test questionnaires for schools.</p>
              </div>
            </div>
            
            {/* Saved Questionnaires Section */}
            <SavedQuestionnairesSection />
            
            {/* Questionnaire Editor */}
            <DefaultQuestionnaireEditor />
          </div>
        )}

        {activeTab === 'photos' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">Photo Gallery</h2>
              <button
                onClick={() => {
                  setModalContent({ type: 'upload-photos', data: null });
                  setShowModal(true);
                }}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium"
              >
                Upload Photos
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {photos.map((photo) => (
                <div key={photo.id} className="bg-white rounded-lg shadow overflow-hidden hover:shadow-lg transition-shadow">
                  <img
                    src={photo.url}
                    alt={photo.description}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-4">
                    <h3 className="text-sm font-medium text-gray-900 truncate">{photo.schoolName}</h3>
                    <p className="text-xs text-gray-600 mt-1">{formatDateTime(photo.uploadedAt)}</p>
                    {photo.tags.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {photo.tags.map((tag, index) => (
                          <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                    <button
                      onClick={() => showPhotoDetails(photo)}
                      className="mt-2 w-full bg-gray-600 hover:bg-gray-700 text-white px-3 py-2 rounded text-sm font-medium"
                    >
                      View Details
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'analytics' && analyticsData && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h2>
              <button
                onClick={showAnalyticsDetails}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium"
              >
                Detailed Analytics
              </button>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1562774053-701939374585?w=100&h=100&fit=crop&crop=center" 
                      alt="School Building"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Schools</p>
                    <p className="text-2xl font-bold text-gray-900">{analyticsData.summary.totalSchools}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=100&h=100&fit=crop&crop=center" 
                      alt="Students Learning"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Students</p>
                    <p className="text-2xl font-bold text-gray-900">{analyticsData.summary.totalStudents}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=100&h=100&fit=crop&crop=center" 
                      alt="Books and Education"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Books Distributed</p>
                    <p className="text-2xl font-bold text-gray-900">{analyticsData.summary.totalBooks}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center">
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&h=100&fit=crop&crop=center" 
                      alt="Analytics Chart"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Avg Improvement</p>
                    <p className="text-2xl font-bold text-gray-900">{analyticsData.summary.averageImprovement.toFixed(1)}%</p>
                  </div>
                </div>
              </div>
            </div>

            {/* School Comparison Chart */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">School Performance Comparison</h3>
              <div className="space-y-4">
                {analyticsData.schoolComparison.map((school, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div>
                      <h4 className="font-medium text-gray-900">{school.name}</h4>
                      <p className="text-sm text-gray-600">{school.students} students • {school.books} books</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-green-600">+{school.happinessImprovement.toFixed(1)}%</p>
                      <p className="text-sm text-gray-600">improvement</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'admin' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-900">Admin Panel</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1562774053-701939374585?w=100&h=100&fit=crop&crop=center" 
                      alt="School Management"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 ml-4">School Management</h3>
                </div>
                <p className="text-gray-600 mb-4">Add new schools, update records, and manage school information.</p>
                <button
                  onClick={() => {
                    setModalContent({ type: 'add-school', data: null });
                    setShowModal(true);
                  }}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm font-medium"
                >
                  Add New School
                </button>
              </div>

              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1511578314322-379afb476865?w=100&h=100&fit=crop&crop=center" 
                      alt="Session Management"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 ml-4">Session Management</h3>
                </div>
                <p className="text-gray-600 mb-4">Schedule sessions, add session data, and track progress.</p>
                <button
                  onClick={() => {
                    setModalContent({ type: 'schedule-session', data: null });
                    setShowModal(true);
                  }}
                  className="w-full bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded text-sm font-medium"
                >
                  Schedule Session
                </button>
              </div>

              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1609220136736-443140cffec6?w=100&h=100&fit=crop&crop=center" 
                      alt="Photo Management"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 ml-4">Photo Management</h3>
                </div>
                <p className="text-gray-600 mb-4">Upload photos, add tags, and organize memories.</p>
                <button
                  onClick={() => {
                    setModalContent({ type: 'upload-photos', data: null });
                    setShowModal(true);
                  }}
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded text-sm font-medium"
                >
                  Upload Photos
                </button>
              </div>

              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&h=100&fit=crop&crop=center" 
                      alt="Data Import"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 ml-4">Data Import</h3>
                </div>
                <p className="text-gray-600 mb-4">Import school records and session data via Excel files.</p>
                <button
                  onClick={() => {
                    setModalContent({ type: 'import-data', data: null });
                    setShowModal(true);
                  }}
                  className="w-full bg-yellow-600 hover:bg-yellow-700 text-white px-4 py-2 rounded text-sm font-medium"
                >
                  Import Data
                </button>
              </div>

              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <div className="p-2 bg-red-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&h=100&fit=crop&crop=center" 
                      alt="Reports"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 ml-4">Reports</h3>
                </div>
                <p className="text-gray-600 mb-4">Generate comprehensive reports and export data.</p>
                <button
                  onClick={() => {
                    setModalContent({ type: 'generate-report', data: null });
                    setShowModal(true);
                  }}
                  className="w-full bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded text-sm font-medium"
                >
                  Generate Report
                </button>
              </div>

              <div className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center mb-4">
                  <div className="p-2 bg-indigo-100 rounded-lg">
                    <img 
                      src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&h=100&fit=crop&crop=center" 
                      alt="Settings"
                      className="w-8 h-8 rounded-lg object-cover"
                    />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 ml-4">Settings</h3>
                </div>
                <p className="text-gray-600 mb-4">Configure system settings and preferences.</p>
                <button
                  onClick={() => {
                    setModalContent({ type: 'settings', data: null });
                    setShowModal(true);
                  }}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded text-sm font-medium"
                >
                  Open Settings
                </button>
              </div>
            </div>
          </div>
        )}

          {/* Modal */}
          {showModal && (
            <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-medium text-gray-900">
                  {modalContent?.type === 'school-details' && 'School Details'}
                  {modalContent?.type === 'photo-details' && 'Photo Details'}
                  {modalContent?.type === 'analytics-details' && 'Detailed Analytics'}
                  {modalContent?.type === 'add-school' && 'Add New School'}
                  {modalContent?.type === 'schedule-session' && 'Schedule Session'}
                  {modalContent?.type === 'upload-photos' && 'Upload Photos'}
                  {modalContent?.type === 'import-data' && 'Import Data'}
                  {modalContent?.type === 'generate-report' && 'Generate Report'}
                  {modalContent?.type === 'settings' && 'Settings'}
                  {modalContent?.type === 'schools-list' && 'All Schools'}
                  {modalContent?.type === 'books-distribution' && 'Books Distribution'}
                  {modalContent?.type === 'children-impact' && 'Children Impact'}
                  {modalContent?.type === 'happiness-scores' && 'Happiness Scores'}
                  {modalContent?.type === 'school-sessions' && 'School Sessions'}
                </h3>
                <button
                  onClick={() => setShowModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <span className="text-2xl">&times;</span>
                </button>
              </div>

              <div className="max-h-96 overflow-y-auto">
                {modalContent?.type === 'school-details' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">School Name</label>
                        <p className="mt-1 text-sm text-gray-900">{modalContent.data.basicInfo.name}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Principal</label>
                        <p className="mt-1 text-sm text-gray-900">{modalContent.data.basicInfo.principalName}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Email</label>
                        <p className="mt-1 text-sm text-gray-900">{modalContent.data.basicInfo.email}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Phone</label>
                        <p className="mt-1 text-sm text-gray-900">{modalContent.data.basicInfo.phone}</p>
                      </div>
                    </div>
                    
                    <div className="border-t pt-4">
                      <h4 className="text-md font-medium text-gray-900 mb-2">Statistics</h4>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700">Total Students</label>
                          <p className="mt-1 text-sm text-gray-900">{modalContent.data.statistics.totalStudents}</p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700">Books Distributed</label>
                          <p className="mt-1 text-sm text-gray-900">{modalContent.data.statistics.booksDistributed}</p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700">Photo Count</label>
                          <p className="mt-1 text-sm text-gray-900">{modalContent.data.statistics.photoCount}</p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700">Session Count</label>
                          <p className="mt-1 text-sm text-gray-900">{modalContent.data.statistics.sessionCount}</p>
                        </div>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="text-md font-medium text-gray-900 mb-2">Recent Sessions</h4>
                      <div className="space-y-2">
                        {modalContent.data.sessions.slice(0, 5).map((session: any, index: number) => (
                          <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                            <div>
                              <p className="text-sm font-medium">{formatDate(session.date)}</p>
                              <p className="text-xs text-gray-600">{session.type} • {session.participants} participants</p>
                            </div>
                            <div className="text-right">
                              <p className="text-sm font-medium text-green-600">+{session.improvement}%</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {modalContent?.type === 'photo-details' && (
                  <div className="space-y-4">
                    <img
                      src={modalContent.data.url}
                      alt={modalContent.data.description}
                      className="w-full h-64 object-cover rounded-lg"
                    />
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Description</label>
                      <p className="mt-1 text-sm text-gray-900">{modalContent.data.description || 'No description'}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">School</label>
                      <p className="mt-1 text-sm text-gray-900">{modalContent.data.schoolName}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Uploaded</label>
                      <p className="mt-1 text-sm text-gray-900">{formatDateTime(modalContent.data.uploadedAt)}</p>
                    </div>
                    {modalContent.data.tags.length > 0 && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Tags</label>
                        <div className="mt-1 flex flex-wrap gap-1">
                          {modalContent.data.tags.map((tag: string, index: number) => (
                            <span key={index} className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded">
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {modalContent?.type === 'analytics-details' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Time Range</label>
                        <p className="mt-1 text-sm text-gray-900">{modalContent.data.timeRange.label}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Total Schools</label>
                        <p className="mt-1 text-sm text-gray-900">{modalContent.data.summary.totalSchools}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Total Students</label>
                        <p className="mt-1 text-sm text-gray-900">{modalContent.data.summary.totalStudents}</p>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Average Improvement</label>
                        <p className="mt-1 text-sm text-gray-900">{modalContent.data.summary.averageImprovement.toFixed(1)}%</p>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <h4 className="text-md font-medium text-gray-900 mb-2">Happiness Trends</h4>
                      <div className="space-y-2 max-h-32 overflow-y-auto">
                        {modalContent.data.happinessTrends.slice(0, 10).map((trend: any, index: number) => (
                          <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                            <div>
                              <p className="text-sm font-medium">{formatDate(trend.date)}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-sm text-gray-600">Before: {trend.before}</p>
                              <p className="text-sm text-gray-600">After: {trend.after}</p>
                              <p className="text-sm font-medium text-green-600">+{trend.improvement}%</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* Add other modal content types here */}
                {modalContent?.type === 'add-school' && (
                  <div className="space-y-4">
                    <p className="text-gray-600">Add new school form would go here with fields for school name, email, address, etc.</p>
                    <div className="flex justify-end space-x-2">
                      <button
                        onClick={() => setShowModal(false)}
                        className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => setShowModal(false)}
                        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
                      >
                        Add School
                      </button>
                    </div>
                  </div>
                )}

                {modalContent?.type === 'schedule-session' && (
                  <div className="space-y-4">
                    <p className="text-gray-600">Schedule session form would go here with fields for school selection, date, type, etc.</p>
                    <div className="flex justify-end space-x-2">
                      <button
                        onClick={() => setShowModal(false)}
                        className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => setShowModal(false)}
                        className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700"
                      >
                        Schedule
                      </button>
                    </div>
                  </div>
                )}

                {modalContent?.type === 'upload-photos' && (
                  <div className="space-y-4">
                    <p className="text-gray-600">Photo upload form would go here with file upload, school selection, tags, etc.</p>
                    <div className="flex justify-end space-x-2">
                      <button
                        onClick={() => setShowModal(false)}
                        className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => setShowModal(false)}
                        className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700"
                      >
                        Upload
                      </button>
                    </div>
                  </div>
                )}

                {/* Simple list modals */}
                {modalContent?.type === 'schools-list' && (
                  <div className="space-y-2">
                    {modalContent.data.map((school: School, index: number) => (
                      <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <div>
                          <p className="text-sm font-medium">{school.name}</p>
                          <p className="text-xs text-gray-600">{school.principalName}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-gray-900">{school.totalStudents} students</p>
                          <p className="text-xs text-gray-600">{school.booksDistributed} books</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {modalContent?.type === 'books-distribution' && (
                  <div className="space-y-2">
                    {modalContent.data.map((item: any, index: number) => (
                      <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <p className="text-sm font-medium">{item.name}</p>
                        <p className="text-sm text-gray-900">{item.books} books</p>
                      </div>
                    ))}
                  </div>
                )}

                {modalContent?.type === 'children-impact' && (
                  <div className="space-y-2">
                    {modalContent.data.map((item: any, index: number) => (
                      <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <p className="text-sm font-medium">{item.name}</p>
                        <p className="text-sm text-gray-900">{item.students} students</p>
                      </div>
                    ))}
                  </div>
                )}

                {modalContent?.type === 'happiness-scores' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div className="p-4 bg-gray-50 rounded">
                        <p className="text-sm text-gray-600">Before Art</p>
                        <p className="text-2xl font-bold text-gray-900">{modalContent.data.before}</p>
                      </div>
                      <div className="p-4 bg-gray-50 rounded">
                        <p className="text-sm text-gray-600">After Art</p>
                        <p className="text-2xl font-bold text-gray-900">{modalContent.data.after}</p>
                      </div>
                      <div className="p-4 bg-green-50 rounded">
                        <p className="text-sm text-gray-600">Improvement</p>
                        <p className="text-2xl font-bold text-green-600">+{modalContent.data.improvement}%</p>
                      </div>
                    </div>
                  </div>
                )}

                {modalContent?.type === 'school-sessions' && (
                  <div className="space-y-2">
                    {modalContent.data.map((session: any, index: number) => (
                      <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <div>
                          <p className="text-sm font-medium">{formatDate(session.date)}</p>
                          <p className="text-xs text-gray-600">{session.participants} participants</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium text-green-600">+{session.improvement}%</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end mt-4">
                <button
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
            </div>
          )}
          </div>
        </div>
      </div>
      {/* ...existing code... */}

      {/* Chatbot */}
      <Chatbot isOpen={chatbotOpen} onClose={() => setChatbotOpen(false)} />
      <ChatButton onClick={() => setChatbotOpen(true)} />
    </div>
  );
}


