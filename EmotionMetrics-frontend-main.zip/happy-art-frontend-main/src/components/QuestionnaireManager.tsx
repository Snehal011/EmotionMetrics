import React, { useState } from 'react';
import { Plus, Edit3, Eye, EyeOff, Trash2 } from 'lucide-react';

type Question = {
  id: string;
  question_text: string;
  question_type: 'pre_test' | 'post_test';
  target_school_id?: string | null;
  active: boolean;
};

export default function QuestionnaireManager() {
  const mockSchools = [
    { id: 's1', name: 'Sunrise High School' },
    { id: 's2', name: 'Green Valley School' },
  ];

  const [questions, setQuestions] = useState<Question[]>([
    { id: 'q1', question_text: 'I feel happy most of the time.', question_type: 'pre_test', target_school_id: null, active: true },
    { id: 'q2', question_text: 'I enjoy participating in class activities.', question_type: 'post_test', target_school_id: 's1', active: false },
  ]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);

  const addQuestion = (questionData: Omit<Question, 'id' | 'active'>) => {
    const newQuestion: Question = {
      id: `q_${Date.now()}`,
      active: false,
      ...questionData,
    };
    setQuestions((prev) => [newQuestion, ...prev]);
  };

  const updateQuestion = (questionId: string, updates: Partial<Question>) => {
    setQuestions((prev) => prev.map((q) => (q.id === questionId ? { ...q, ...updates } : q)));
  };

  const deleteQuestion = (questionId: string) => {
    setQuestions((prev) => prev.filter((q) => q.id !== questionId));
  };

  const toggleQuestionActive = (questionId: string, active: boolean) => {
    const target = questions.find((q) => q.id === questionId);
    if (!target) return;
    setQuestions((prev) =>
      prev.map((q) => {
        if (q.question_type === target.question_type) {
          return { ...q, active: q.id === questionId ? active : false };
        }
        return q;
      })
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Questionnaire Management</h2>
          <p className="text-gray-600 mt-1">Create and manage questions for schools</p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Question
        </button>
      </div>

      {(showAddForm || editingQuestion) && (
        <QuestionForm
          question={editingQuestion}
          schools={mockSchools}
          onSubmit={editingQuestion ? (data) => updateQuestion(editingQuestion.id, data) : addQuestion}
          onCancel={() => {
            setShowAddForm(false);
            setEditingQuestion(null);
          }}
        />
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Pre-Test Questions</h3>
          <QuestionsList
            questions={questions.filter((q) => q.question_type === 'pre_test')}
            schools={mockSchools}
            onEdit={setEditingQuestion}
            onDelete={deleteQuestion}
            onToggleActive={toggleQuestionActive}
          />
        </div>

        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-4">Post-Test Questions</h3>
          <QuestionsList
            questions={questions.filter((q) => q.question_type === 'post_test')}
            schools={mockSchools}
            onEdit={setEditingQuestion}
            onDelete={deleteQuestion}
            onToggleActive={toggleQuestionActive}
          />
        </div>
      </div>
    </div>
  );
}

interface QuestionFormProps {
  question?: Question | null;
  schools: Array<{ id: string; name: string }>;
  onSubmit: (data: any) => void;
  onCancel: () => void;
}

function QuestionForm({ question, schools, onSubmit, onCancel }: QuestionFormProps) {
  const [formData, setFormData] = useState({
    question_text: question?.question_text || '',
    question_type: (question?.question_type || 'pre_test') as 'pre_test' | 'post_test',
    target_school_id: question?.target_school_id || '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      target_school_id: formData.target_school_id || null,
    });
    onCancel();
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-medium text-gray-900 mb-4">{question ? 'Edit Question' : 'Add New Question'}</h3>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Question Type</label>
          <select
            value={formData.question_type}
            onChange={(e) => setFormData({ ...formData, question_type: e.target.value as 'pre_test' | 'post_test' })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
          >
            <option value="pre_test">Pre-Test</option>
            <option value="post_test">Post-Test</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Question Text</label>
          <textarea
            value={formData.question_text}
            onChange={(e) => setFormData({ ...formData, question_text: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            rows={3}
            placeholder="Enter your question here..."
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Target School (Optional)</label>
          <select
            value={formData.target_school_id}
            onChange={(e) => setFormData({ ...formData, target_school_id: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="">All Schools</option>
            {schools.map((school) => (
              <option key={school.id} value={school.id}>
                {school.name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex justify-end space-x-3">
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            {question ? 'Update' : 'Create'} Question
          </button>
        </div>
      </form>
    </div>
  );
}

interface QuestionsListProps {
  questions: Question[];
  schools: Array<{ id: string; name: string }>;
  onEdit: (question: Question) => void;
  onDelete: (questionId: string) => void;
  onToggleActive: (questionId: string, active: boolean) => void;
}

function QuestionsList({ questions, schools, onEdit, onDelete, onToggleActive }: QuestionsListProps) {
  const getSchoolName = (schoolId?: string | null) => {
    if (!schoolId) return 'All Schools';
    const school = schools.find((s) => s.id === schoolId);
    return school?.name || 'Unknown School';
  };

  if (questions.length === 0) {
    return <div className="text-center py-8 text-gray-500">No questions created yet</div>;
  }

  return (
    <div className="space-y-4">
      {questions.map((question) => (
        <div key={question.id} className="bg-white border rounded-lg p-4">
          <div className="flex justify-between items-start mb-2">
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-900">{question.question_text}</p>
              <p className="text-xs text-gray-500 mt-1">Target: {getSchoolName(question.target_school_id)}</p>
            </div>
            <div className="flex items-center space-x-2 ml-4">
              <button
                onClick={() => onToggleActive(question.id, !question.active)}
                className={`p-1 rounded transition-colors ${question.active ? 'text-green-600 hover:bg-green-50' : 'text-gray-400 hover:bg-gray-50'}`}
                title={question.active ? 'Deactivate' : 'Activate'}
              >
                {question.active ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              </button>
              <button onClick={() => onEdit(question)} className="p-1 text-blue-600 hover:bg-blue-50 rounded transition-colors" title="Edit">
                <Edit3 className="w-4 h-4" />
              </button>
              <button onClick={() => onDelete(question.id)} className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors" title="Delete">
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
          {question.active && (
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-xs text-green-600 font-medium">Active</span>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}