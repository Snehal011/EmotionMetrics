import React, { useState, useEffect } from 'react';
import {
  Box,
  Typography,
  Button,
  CircularProgress,
  Alert,
  Snackbar,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Avatar,
  Fade,
  Slide,
  LinearProgress
} from '@mui/material';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer
} from 'recharts';
import {
  ArrowBack,
  Refresh,
  TrendingUp,
  People,
  Grade,
  Assessment,
  EmojiEvents,
  School,
  Analytics,
  Star,
  MilitaryTech,
  Schedule
} from '@mui/icons-material';
import { useParams, useNavigate } from 'react-router-dom';
import { SchoolTestResults, getSchoolTestResults } from '../lib/api';

const PIE_COLORS = ['#667eea', '#f5576c', '#00f2fe', '#38f9d7', '#fee140'];

const SchoolResultsView: React.FC = () => {
  const { testId } = useParams<{ testId: string }>();
  const navigate = useNavigate();
  const [results, setResults] = useState<SchoolTestResults | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');

  useEffect(() => {
    if (testId) {
      fetchTestResults();
    }
  }, [testId]);

  const fetchTestResults = async () => {
    if (!testId) return;
    
    try {
      setLoading(true);
      setError(null);
      const response = await getSchoolTestResults(testId);
      setResults(response);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch test results');
      setSnackbarMessage('Failed to fetch test results');
      setSnackbarOpen(true);
    } finally {
      setLoading(false);
    }
  };

  const getMarksDistributionData = () => {
    if (!results?.results) return [];
    
    const ranges = [
      { range: '0-20%', min: 0, max: 20, count: 0 },
      { range: '21-40%', min: 21, max: 40, count: 0 },
      { range: '41-60%', min: 41, max: 60, count: 0 },
      { range: '61-80%', min: 61, max: 80, count: 0 },
      { range: '81-100%', min: 81, max: 100, count: 0 }
    ];

    results.results.forEach(result => {
      const percentage = result.percentage;
      const range = ranges.find(r => percentage >= r.min && percentage <= r.max);
      if (range) range.count++;
    });

    return ranges;
  };

  const getGradeDistributionData = () => {
    if (!results?.results) return [];
    
    const gradeMap = new Map<string, { count: number; totalMarks: number }>();
    
    results.results.forEach(result => {
      const grade = result.grade;
      if (!gradeMap.has(grade)) {
        gradeMap.set(grade, { count: 0, totalMarks: 0 });
      }
      const gradeData = gradeMap.get(grade)!;
      gradeData.count++;
      gradeData.totalMarks += result.marksObtained;
    });

    return Array.from(gradeMap.entries()).map(([grade, data]) => ({
      grade,
      count: data.count,
      averageMarks: Math.round((data.totalMarks / data.count) * 100) / 100
    }));
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '50vh' }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ p: 3 }}>
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
        <Button onClick={() => navigate('/school-dashboard')} startIcon={<ArrowBack />}>
          Back to Dashboard
        </Button>
      </Box>
    );
  }

  if (!results) {
    return (
      <Box sx={{ p: 3 }}>
        <Typography variant="h6" color="text.secondary">
          No results found for this test.
        </Typography>
        <Button onClick={() => navigate('/school-dashboard')} startIcon={<ArrowBack />}>
          Back to Dashboard
        </Button>
      </Box>
    );
  }

  return (
    <Box sx={{ 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      p: { xs: 2, sm: 3 }
    }}>
      {/* Modern Header with Gradient */}
      <Paper 
        elevation={8} 
        sx={{ 
          mb: 4, 
          background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
          borderRadius: 3,
          overflow: 'hidden',
          position: 'relative'
        }}
      >
        <Box sx={{ 
          background: 'linear-gradient(90deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%)',
          p: 3
        }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 3 }}>
              <Avatar 
                sx={{ 
                  width: 64, 
                  height: 64, 
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  boxShadow: '0 8px 32px rgba(102, 126, 234, 0.3)'
                }}
              >
                <Analytics sx={{ fontSize: 32, color: 'white' }} />
              </Avatar>
        <Box>
          <Button
            startIcon={<ArrowBack />}
            onClick={() => navigate('/school-dashboard')}
                  sx={{ 
                    mb: 2,
                    borderRadius: 2,
                    textTransform: 'none',
                    fontWeight: 600,
                    color: '#667eea',
                    '&:hover': {
                      backgroundColor: 'rgba(102, 126, 234, 0.1)'
                    }
                  }}
                >
                  ← BACK TO DASHBOARD
          </Button>
                <Typography 
                  variant="h3" 
                  component="h1" 
                  sx={{ 
                    fontWeight: 700,
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    backgroundClip: 'text',
                    WebkitBackgroundClip: 'text',
                    WebkitTextFillColor: 'transparent',
                    mb: 1
                  }}
                >
            Test Results
          </Typography>
                <Typography variant="h6" sx={{ color: '#6b7280', fontWeight: 500 }}>
            {results.test.name} - Grade {results.test.grade} - {results.test.subject}
          </Typography>
        </Box>
            </Box>
            
        <Button
          startIcon={<Refresh />}
          onClick={fetchTestResults}
          disabled={loading}
              variant="contained"
              sx={{
                borderRadius: 3,
                px: 3,
                py: 1.5,
                fontSize: '1rem',
                fontWeight: 600,
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                boxShadow: '0 8px 24px rgba(102, 126, 234, 0.3)',
                '&:hover': {
                  background: 'linear-gradient(135deg, #5a67d8 0%, #6b46c1 100%)',
                  transform: 'translateY(-2px)',
                  boxShadow: '0 12px 32px rgba(102, 126, 234, 0.4)'
                },
                '&:disabled': {
                  background: 'linear-gradient(135deg, #a0aec0 0%, #718096 100%)'
                },
                transition: 'all 0.3s ease-in-out'
              }}
            >
              REFRESH
        </Button>
      </Box>
        </Box>
      </Paper>

      {/* Enhanced Test Info */}
      <Paper 
        elevation={6} 
        sx={{ 
          mb: 4, 
          background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
          borderRadius: 3,
          overflow: 'hidden'
        }}
      >
        <Box sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', gap: 2, flexWrap: 'wrap', alignItems: 'center' }}>
            <Chip 
              label={results.test.type.toUpperCase()} 
              sx={{ 
                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                color: 'white',
                fontWeight: 600,
                boxShadow: '0 4px 12px rgba(102, 126, 234, 0.3)'
              }} 
            />
            <Chip 
              label={`Grade ${results.test.grade}`} 
              variant="outlined" 
              sx={{ 
                borderColor: '#667eea',
                color: '#667eea',
                fontWeight: 600
              }} 
            />
            <Chip 
              label={results.test.subject} 
              variant="outlined" 
              sx={{ 
                borderColor: '#764ba2',
                color: '#764ba2',
                fontWeight: 600
              }} 
            />
            <Chip 
              label={`Total Marks: ${results.test.totalMarks}`} 
              variant="outlined" 
              sx={{ 
                borderColor: '#f5576c',
                color: '#f5576c',
                fontWeight: 600
              }} 
            />
          </Box>
        </Box>
      </Paper>

      {/* Enhanced Summary Statistics */}
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', lg: 'repeat(4, 1fr)' }, gap: 3, mb: 4 }}>
        <Fade in={true} timeout={500}>
          <Paper 
            elevation={6}
            sx={{ 
              background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
              borderRadius: 3,
              overflow: 'hidden',
              transition: 'all 0.3s ease-in-out',
              '&:hover': {
                transform: 'translateY(-4px)',
                boxShadow: '0 12px 40px rgba(102, 126, 234, 0.15)'
              }
            }}
          >
            <Box sx={{ p: 3, textAlign: 'center' }}>
              <Avatar 
                sx={{ 
                  width: 64, 
                  height: 64, 
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  boxShadow: '0 8px 24px rgba(102, 126, 234, 0.3)',
                  mx: 'auto',
                  mb: 2
                }}
              >
                <People sx={{ fontSize: 32, color: 'white' }} />
              </Avatar>
              <Typography variant="h3" sx={{ fontWeight: 700, color: '#2c3e50', mb: 1 }}>
              {results.statistics.totalStudents}
            </Typography>
              <Typography variant="h6" sx={{ color: '#6b7280', fontWeight: 500 }}>
              Total Students
            </Typography>
            </Box>
          </Paper>
        </Fade>

        <Fade in={true} timeout={700}>
          <Paper 
            elevation={6}
            sx={{ 
              background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
              borderRadius: 3,
              overflow: 'hidden',
              transition: 'all 0.3s ease-in-out',
              '&:hover': {
                transform: 'translateY(-4px)',
                boxShadow: '0 12px 40px rgba(72, 187, 120, 0.15)'
              }
            }}
          >
            <Box sx={{ p: 3, textAlign: 'center' }}>
              <Avatar 
                sx={{ 
                  width: 64, 
                  height: 64, 
                  background: 'linear-gradient(135deg, #48bb78 0%, #38a169 100%)',
                  boxShadow: '0 8px 24px rgba(72, 187, 120, 0.3)',
                  mx: 'auto',
                  mb: 2
                }}
              >
                <Grade sx={{ fontSize: 32, color: 'white' }} />
              </Avatar>
              <Typography variant="h3" sx={{ fontWeight: 700, color: '#2c3e50', mb: 1 }}>
              {results.statistics.averageMarks}
            </Typography>
              <Typography variant="h6" sx={{ color: '#6b7280', fontWeight: 500 }}>
              Average Marks
            </Typography>
            </Box>
          </Paper>
        </Fade>

        <Fade in={true} timeout={900}>
          <Paper 
            elevation={6}
            sx={{ 
              background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
              borderRadius: 3,
              overflow: 'hidden',
              transition: 'all 0.3s ease-in-out',
              '&:hover': {
                transform: 'translateY(-4px)',
                boxShadow: '0 12px 40px rgba(59, 130, 246, 0.15)'
              }
            }}
          >
            <Box sx={{ p: 3, textAlign: 'center' }}>
              <Avatar 
                sx={{ 
                  width: 64, 
                  height: 64, 
                  background: 'linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%)',
                  boxShadow: '0 8px 24px rgba(59, 130, 246, 0.3)',
                  mx: 'auto',
                  mb: 2
                }}
              >
                <TrendingUp sx={{ fontSize: 32, color: 'white' }} />
              </Avatar>
              <Typography variant="h3" sx={{ fontWeight: 700, color: '#2c3e50', mb: 1 }}>
              {results.statistics.averagePercentage}%
            </Typography>
              <Typography variant="h6" sx={{ color: '#6b7280', fontWeight: 500 }}>
              Average Percentage
            </Typography>
            </Box>
          </Paper>
        </Fade>

        <Fade in={true} timeout={1100}>
          <Paper 
            elevation={6}
            sx={{ 
              background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
              borderRadius: 3,
              overflow: 'hidden',
              transition: 'all 0.3s ease-in-out',
              '&:hover': {
                transform: 'translateY(-4px)',
                boxShadow: '0 12px 40px rgba(245, 158, 11, 0.15)'
              }
            }}
          >
            <Box sx={{ p: 3, textAlign: 'center' }}>
              <Avatar 
                sx={{ 
                  width: 64, 
                  height: 64, 
                  background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
                  boxShadow: '0 8px 24px rgba(245, 158, 11, 0.3)',
                  mx: 'auto',
                  mb: 2
                }}
              >
                <MilitaryTech sx={{ fontSize: 32, color: 'white' }} />
              </Avatar>
              <Typography variant="h3" sx={{ fontWeight: 700, color: '#2c3e50', mb: 1 }}>
              {results.statistics.topScorers.length > 0 ? results.statistics.topScorers[0].percentage.toFixed(1) : 0}%
            </Typography>
              <Typography variant="h6" sx={{ color: '#6b7280', fontWeight: 500 }}>
              Highest Score
            </Typography>
            </Box>
          </Paper>
        </Fade>
      </Box>

      {/* Enhanced Charts */}
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: '1fr 1fr' }, gap: 4, mb: 4 }}>
        {/* Enhanced Marks Distribution */}
        <Slide direction="up" in={true} timeout={600}>
          <Paper 
            elevation={8}
            sx={{ 
              background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
              borderRadius: 3,
              overflow: 'hidden',
              transition: 'all 0.3s ease-in-out',
              '&:hover': {
                transform: 'translateY(-2px)',
                boxShadow: '0 16px 48px rgba(102, 126, 234, 0.15)'
              }
            }}
          >
            <Box sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                <Avatar 
                  sx={{ 
                    width: 48, 
                    height: 48, 
                    background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                    boxShadow: '0 8px 24px rgba(102, 126, 234, 0.3)'
                  }}
                >
                  <Assessment sx={{ fontSize: 24, color: 'white' }} />
                </Avatar>
                <Typography 
                  variant="h5" 
                  sx={{ 
                    fontWeight: 700,
                    color: '#2c3e50'
                  }}
                >
              Marks Distribution
            </Typography>
              </Box>
              <ResponsiveContainer width="100%" height={350}>
              <PieChart>
                <Pie
                  data={getMarksDistributionData()}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ range, count }: any) => `${range}: ${count}`}
                    outerRadius={100}
                  fill="#8884d8"
                  dataKey="count"
                    animationBegin={0}
                    animationDuration={1000}
                >
                  {getMarksDistributionData().map((_, index) => (
                      <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                  <Tooltip 
                    contentStyle={{
                      background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
                      border: 'none',
                      borderRadius: 12,
                      boxShadow: '0 8px 32px rgba(102, 126, 234, 0.15)'
                    }}
                  />
              </PieChart>
            </ResponsiveContainer>
            </Box>
          </Paper>
        </Slide>

        {/* Enhanced Grade-wise Performance */}
        <Slide direction="up" in={true} timeout={800}>
          <Paper 
            elevation={8}
            sx={{ 
              background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
              borderRadius: 3,
              overflow: 'hidden',
              transition: 'all 0.3s ease-in-out',
              '&:hover': {
                transform: 'translateY(-2px)',
                boxShadow: '0 16px 48px rgba(102, 126, 234, 0.15)'
              }
            }}
          >
            <Box sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                <Avatar 
                  sx={{ 
                    width: 48, 
                    height: 48, 
                    background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
                    boxShadow: '0 8px 24px rgba(240, 147, 251, 0.3)'
                  }}
                >
                  <School sx={{ fontSize: 24, color: 'white' }} />
                </Avatar>
                <Typography 
                  variant="h5" 
                  sx={{ 
                    fontWeight: 700,
                    color: '#2c3e50'
                  }}
                >
              Grade-wise Performance
            </Typography>
              </Box>
              <ResponsiveContainer width="100%" height={350}>
              <BarChart data={getGradeDistributionData()}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis 
                    dataKey="grade" 
                    tick={{ fill: '#6b7280', fontWeight: 600 }}
                    axisLine={{ stroke: '#e2e8f0' }}
                  />
                  <YAxis 
                    tick={{ fill: '#6b7280', fontWeight: 600 }}
                    axisLine={{ stroke: '#e2e8f0' }}
                  />
                  <Tooltip 
                    contentStyle={{
                      background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
                      border: 'none',
                      borderRadius: 12,
                      boxShadow: '0 8px 32px rgba(102, 126, 234, 0.15)'
                    }}
                  />
                <Legend />
                  <Bar 
                    dataKey="averageMarks" 
                    fill="url(#gradeGradient)" 
                    name="Average Marks"
                    radius={[4, 4, 0, 0]}
                    animationBegin={0}
                    animationDuration={1000}
                  />
                  <defs>
                    <linearGradient id="gradeGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#667eea" />
                      <stop offset="100%" stopColor="#764ba2" />
                    </linearGradient>
                  </defs>
              </BarChart>
            </ResponsiveContainer>
            </Box>
          </Paper>
        </Slide>
      </Box>

      {/* Enhanced Top Scorers */}
      {results.statistics.topScorers.length > 0 && (
        <Slide direction="up" in={true} timeout={1000}>
          <Paper 
            elevation={8}
            sx={{ 
              mb: 4, 
              background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
              borderRadius: 3,
              overflow: 'hidden'
            }}
          >
            <Box sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
                <Avatar 
                  sx={{ 
                    width: 48, 
                    height: 48, 
                    background: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)',
                    boxShadow: '0 8px 24px rgba(245, 158, 11, 0.3)'
                  }}
                >
                  <EmojiEvents sx={{ fontSize: 24, color: 'white' }} />
                </Avatar>
                <Typography 
                  variant="h5" 
                  sx={{ 
                    fontWeight: 700,
                    color: '#2c3e50'
                  }}
                >
              Top Scorers
            </Typography>
              </Box>
              <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' }, gap: 2 }}>
              {results.statistics.topScorers.map((scorer, index) => (
                  <Paper
                  key={index}
                    elevation={2}
                    sx={{
                      p: 2,
                      borderRadius: 2,
                      background: index < 3 
                        ? 'linear-gradient(135deg, rgba(245, 158, 11, 0.1) 0%, rgba(217, 119, 6, 0.1) 100%)'
                        : 'linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%)',
                      border: index < 3 
                        ? '2px solid #f59e0b'
                        : '1px solid rgba(102, 126, 234, 0.2)',
                      transition: 'all 0.3s ease-in-out',
                      '&:hover': {
                        transform: 'translateY(-2px)',
                        boxShadow: '0 8px 24px rgba(102, 126, 234, 0.15)'
                      }
                    }}
                  >
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                      <Avatar 
                        sx={{ 
                          width: 40, 
                          height: 40, 
                          background: index < 3 
                            ? 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)'
                            : 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                          boxShadow: '0 4px 12px rgba(102, 126, 234, 0.3)'
                        }}
                      >
                        {index === 0 && <MilitaryTech sx={{ fontSize: 20, color: 'white' }} />}
                        {index === 1 && <Star sx={{ fontSize: 20, color: 'white' }} />}
                        {index === 2 && <EmojiEvents sx={{ fontSize: 20, color: 'white' }} />}
                        {index > 2 && <Typography variant="body2" sx={{ color: 'white', fontWeight: 700 }}>
                          {index + 1}
                        </Typography>}
                      </Avatar>
                      <Box sx={{ flex: 1 }}>
                        <Typography variant="h6" sx={{ fontWeight: 600, color: '#2c3e50', mb: 0.5 }}>
                          {scorer.studentName}
                        </Typography>
                        <Typography variant="h5" sx={{ 
                          fontWeight: 700, 
                          color: index < 3 ? '#f59e0b' : '#667eea'
                        }}>
                          {scorer.percentage.toFixed(1)}%
                        </Typography>
                      </Box>
                    </Box>
                  </Paper>
                ))}
              </Box>
            </Box>
          </Paper>
        </Slide>
      )}

      {/* Enhanced Results Table */}
      <Slide direction="up" in={true} timeout={1200}>
        <Paper 
          elevation={8}
          sx={{ 
            background: 'linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%)',
            borderRadius: 3,
            overflow: 'hidden'
          }}
        >
          <Box sx={{ p: 3 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
              <Avatar 
                sx={{ 
                  width: 48, 
                  height: 48, 
                  background: 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)',
                  boxShadow: '0 8px 24px rgba(67, 233, 123, 0.3)'
                }}
              >
                <People sx={{ fontSize: 24, color: 'white' }} />
              </Avatar>
              <Typography 
                variant="h5" 
                sx={{ 
                  fontWeight: 700,
                  color: '#2c3e50'
                }}
              >
            Student Results ({results.results.length} students)
          </Typography>
            </Box>
            <TableContainer 
              component={Paper} 
              variant="outlined" 
              sx={{ 
                maxHeight: 500,
                borderRadius: 2,
                border: '1px solid rgba(102, 126, 234, 0.1)',
                boxShadow: '0 4px 16px rgba(102, 126, 234, 0.1)'
              }}
            >
            <Table stickyHeader>
              <TableHead>
                  <TableRow sx={{ background: 'linear-gradient(135deg, rgba(102, 126, 234, 0.05) 0%, rgba(118, 75, 162, 0.05) 100%)' }}>
                    <TableCell sx={{ fontWeight: 700, color: '#2c3e50' }}>Roll No</TableCell>
                    <TableCell sx={{ fontWeight: 700, color: '#2c3e50' }}>Name</TableCell>
                    <TableCell sx={{ fontWeight: 700, color: '#2c3e50' }}>Grade</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 700, color: '#2c3e50' }}>Marks Obtained</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 700, color: '#2c3e50' }}>Total Marks</TableCell>
                    <TableCell align="right" sx={{ fontWeight: 700, color: '#2c3e50' }}>Percentage</TableCell>
                    <TableCell sx={{ fontWeight: 700, color: '#2c3e50' }}>Submission Time</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                  {results.results.map((result) => (
                    <TableRow 
                      key={result.id}
                      sx={{ 
                        '&:hover': {
                          backgroundColor: 'rgba(102, 126, 234, 0.05)',
                          transform: 'scale(1.01)',
                          transition: 'all 0.2s ease-in-out'
                        },
                        transition: 'all 0.2s ease-in-out'
                      }}
                    >
                      <TableCell sx={{ fontWeight: 600, color: '#4a5568' }}>{result.rollNo}</TableCell>
                      <TableCell sx={{ fontWeight: 600, color: '#2c3e50' }}>{result.name}</TableCell>
                    <TableCell>
                        <Chip 
                          label={result.grade} 
                          size="small"
                          sx={{
                            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                            color: 'white',
                            fontWeight: 600
                          }}
                        />
                      </TableCell>
                      <TableCell align="right" sx={{ fontWeight: 600, color: '#2c3e50' }}>
                        {result.marksObtained}
                      </TableCell>
                      <TableCell align="right" sx={{ fontWeight: 600, color: '#6b7280' }}>
                        {result.totalMarks}
                      </TableCell>
                      <TableCell align="right">
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', gap: 1 }}>
                          <LinearProgress
                            variant="determinate"
                            value={result.percentage}
                            sx={{
                              width: 60,
                              height: 8,
                              borderRadius: 4,
                              backgroundColor: 'rgba(102, 126, 234, 0.1)',
                              '& .MuiLinearProgress-bar': {
                                background: result.percentage >= 80 
                                  ? 'linear-gradient(135deg, #48bb78 0%, #38a169 100%)'
                                  : result.percentage >= 60
                                  ? 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)'
                                  : 'linear-gradient(135deg, #f56565 0%, #e53e3e 100%)',
                                borderRadius: 4
                              }
                            }}
                          />
                          <Typography 
                            variant="body2" 
                            sx={{ 
                              fontWeight: 700,
                              color: result.percentage >= 80 
                                ? '#48bb78'
                                : result.percentage >= 60
                                ? '#f59e0b'
                                : '#f56565',
                              minWidth: 45
                            }}
                          >
                            {result.percentage.toFixed(1)}%
                          </Typography>
                        </Box>
                      </TableCell>
                      <TableCell sx={{ color: '#6b7280', fontSize: '0.875rem' }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                          <Schedule sx={{ fontSize: 16, color: '#9ca3af' }} />
                      {new Date(result.submittedAt).toLocaleString()}
                        </Box>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          </Box>
        </Paper>
      </Slide>

      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbarOpen}
        autoHideDuration={6000}
        onClose={() => setSnackbarOpen(false)}
        message={snackbarMessage}
      />
    </Box>
  );
};

export default SchoolResultsView;

