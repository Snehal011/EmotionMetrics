import React, { useState, useEffect } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer
} from 'recharts';
import {
  RefreshCw,
  TrendingUp,
  Users,
  Award,
  Target,
  School,
  BarChart3,
  Star,
  Trophy,
  Clock,
  Building2,
  AlertCircle
} from 'lucide-react';
import { getSchools, getSchoolAssignedTests, getSchoolTestResultsAdmin } from '../lib/api';

const PIE_COLORS = ['#667eea', '#f5576c', '#00f2fe', '#38f9d7', '#fee140'];

interface School {
  id: string;
  name: string;
  school_name: string;
  email: string;
}

interface AssignedTest {
  id: string;
  testLinkId: string;
  name: string;
  type: 'pre' | 'post';
  grade: string;
  subject: string;
  durationMinutes: number;
  status: 'draft' | 'active' | 'expired' | 'completed';
  startTime: string;
  endTime: string;
  linkHash: string;
  url: string;
  createdAt: string;
}

interface SchoolTestResult {
  id: string;
  rollNo: string;
  name: string;
  grade: string;
  marksObtained: number;
  totalMarks: number;
  percentage: number;
  submittedAt: string;
  status: string;
}

interface SchoolTestResults {
  test: {
    id: string;
    name: string;
    type: string;
    grade: string;
    subject: string;
    totalMarks: number;
  };
  statistics: {
    totalStudents: number;
    averageMarks: number;
    averagePercentage: number;
    topScorers: Array<{
      studentName: string;
      grade: string;
      marksObtained: number;
      percentage: number;
    }>;
  };
  results: SchoolTestResult[];
}

const AdminResultsView: React.FC = () => {
  const [schools, setSchools] = useState<School[]>([]);
  const [selectedSchoolId, setSelectedSchoolId] = useState<string>('');
  const [assignedTests, setAssignedTests] = useState<AssignedTest[]>([]);
  const [selectedTestId, setSelectedTestId] = useState<string>('');
  const [testResults, setTestResults] = useState<SchoolTestResults | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchSchools();
  }, []);

  useEffect(() => {
    if (selectedSchoolId) {
      fetchAssignedTests(selectedSchoolId);
      setSelectedTestId(''); // Reset test selection when school changes
      setTestResults(null); // Clear results when school changes
    }
  }, [selectedSchoolId]);

  useEffect(() => {
    if (selectedTestId && selectedSchoolId) {
      fetchTestResults(selectedSchoolId, selectedTestId);
    }
  }, [selectedTestId, selectedSchoolId]);

  const fetchSchools = async () => {
    try {
      setLoading(true);
      const response = await getSchools();
      setSchools(response);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch schools');
    } finally {
      setLoading(false);
    }
  };

  const fetchAssignedTests = async (schoolId: string) => {
    try {
      setLoading(true);
      setError(null);
      const response = await getSchoolAssignedTests(schoolId);
      setAssignedTests(response.tests || []);
    } catch (err: any) {
      setError(err.message || 'Failed to fetch assigned tests');
      setAssignedTests([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchTestResults = async (schoolId: string, testId: string) => {
    try {
      setLoading(true);
      setError(null);
      const response = await getSchoolTestResultsAdmin(schoolId, testId);
      
      // Check if the response indicates no results
      if ((response as any).message && (response as any).message.includes('No test results found')) {
        setTestResults({
          test: null as any,
          statistics: {
            totalStudents: 0,
            averageMarks: 0,
            averagePercentage: 0,
            topScorers: []
          },
          results: []
        });
      } else {
        setTestResults(response);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to fetch test results');
      setTestResults(null);
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    if (selectedTestId && selectedSchoolId) {
      fetchTestResults(selectedSchoolId, selectedTestId);
    }
  };


  const getMarksDistributionData = () => {
    if (!testResults?.results) return [];
    
    const ranges = [
      { range: '0-20%', min: 0, max: 20, count: 0 },
      { range: '21-40%', min: 21, max: 40, count: 0 },
      { range: '41-60%', min: 41, max: 60, count: 0 },
      { range: '61-80%', min: 61, max: 80, count: 0 },
      { range: '81-100%', min: 81, max: 100, count: 0 }
    ];

    testResults.results.forEach(result => {
      const percentage = result.percentage;
      const range = ranges.find(r => percentage >= r.min && percentage <= r.max);
      if (range) range.count++;
    });

    return ranges;
  };

  const getGradeDistributionData = () => {
    if (!testResults?.results) return [];
    
    const gradeMap = new Map<string, { count: number; totalMarks: number }>();
    
    testResults.results.forEach(result => {
      const grade = result.grade;
      if (!gradeMap.has(grade)) {
        gradeMap.set(grade, { count: 0, totalMarks: 0 });
      }
      const gradeData = gradeMap.get(grade)!;
      gradeData.count++;
      gradeData.totalMarks += result.marksObtained;
    });

    return Array.from(gradeMap.entries()).map(([grade, data]) => ({
      grade,
      count: data.count,
      averageMarks: Math.round((data.totalMarks / data.count) * 100) / 100
    }));
  };

  const selectedSchool = schools.find(school => school.id === selectedSchoolId);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Modern Header with Actions */}
        <div className="bg-white/80 backdrop-blur-sm shadow-xl border border-white/20 rounded-2xl mb-8">
          <div className="p-6">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
              <div className="flex items-center space-x-4">
                <div className="p-4 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl shadow-lg">
                  <BarChart3 className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h2 className="text-3xl font-bold bg-gradient-to-r from-slate-900 to-slate-700 bg-clip-text text-transparent">
                    Test Results Dashboard
                  </h2>
                  <p className="text-slate-600 mt-1 text-lg leading-relaxed">
                  Admin Dashboard - School Test Results
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3">
                <button
              onClick={handleRefresh}
              disabled={loading || !selectedTestId}
                  className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-xl hover:from-emerald-600 hover:to-emerald-700 disabled:from-gray-400 disabled:to-gray-500 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:scale-105 disabled:transform-none disabled:shadow-none"
                >
                  <RefreshCw className={`h-5 w-5 ${loading ? 'animate-spin' : ''}`} />
                  <span className="font-semibold">REFRESH</span>
                </button>
              </div>
            </div>
          </div>
        </div>

      {/* School and Test Selection */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* School Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <div className="flex items-center space-x-2">
                    <Building2 className="h-4 w-4 text-emerald-600" />
                    <span>Select School</span>
                  </div>
                </label>
                <select
                value={selectedSchoolId}
                onChange={(e) => setSelectedSchoolId(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-white shadow-sm font-medium"
              >
                  <option value="">Choose a school...</option>
                {schools.map((school) => (
                    <option key={school.id} value={school.id}>
                      {school.school_name || school.name} - {school.email}
                    </option>
                  ))}
                </select>
              </div>

            {/* Test Selection */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-emerald-600" />
                    <span>Select Test</span>
                  </div>
                </label>
                <select
                value={selectedTestId}
                onChange={(e) => setSelectedTestId(e.target.value)}
                  disabled={!selectedSchoolId}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-white shadow-sm font-medium disabled:bg-gray-100 disabled:cursor-not-allowed"
                >
                  <option value="">Choose a test...</option>
                {assignedTests.map((test) => (
                    <option key={test.id} value={test.id}>
                      {test.name} ({test.type}, Grade {test.grade}) - {test.status}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        </div>

      {error && (
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6">
            <div className="flex items-center space-x-3">
              <div className="flex-shrink-0">
                <AlertCircle className="h-5 w-5 text-red-600" />
              </div>
              <div className="text-sm text-red-700 font-medium">
          {error}
              </div>
            </div>
          </div>
      )}

      {loading && (
          <div className="flex justify-center items-center py-12">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-600 mx-auto mb-4"></div>
              <p className="text-gray-600 font-medium">Loading test results...</p>
            </div>
          </div>
      )}

      {testResults && !loading && (
        <>
          {/* Test Info */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
            <div className="p-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                {testResults.test ? testResults.test.name : 'Test Results'}
              </h3>
              <div className="flex flex-wrap gap-3">
                {testResults.test ? (
                  <>
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-gradient-to-r from-emerald-500 to-emerald-600 text-white">
                      {testResults.test.type.toUpperCase()}
                    </span>
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                      Grade {testResults.test.grade}
                    </span>
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-blue-50 text-blue-700 border border-blue-200">
                      {testResults.test.subject}
                    </span>
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-purple-50 text-purple-700 border border-purple-200">
                      Total Marks: {testResults.test.totalMarks}
                    </span>
                  </>
                ) : (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-yellow-50 text-yellow-700 border border-yellow-200">
                    No Test Data Available
                  </span>
                )}
                {selectedSchool && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-50 text-green-700 border border-green-200">
                    School: {selectedSchool.school_name || selectedSchool.name}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Summary Statistics */}
          {testResults.test && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 group">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:scale-105 transition-transform">
                    <Users className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900 mb-1">
                    {testResults.statistics.totalStudents}
                  </h3>
                  <p className="text-gray-600 font-medium">
                    Total Students
                  </p>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 group">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:scale-105 transition-transform">
                    <Award className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900 mb-1">
                    {testResults.statistics.averageMarks}
                  </h3>
                  <p className="text-gray-600 font-medium">
                    Average Marks
                  </p>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 group">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:scale-105 transition-transform">
                    <TrendingUp className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900 mb-1">
                    {testResults.statistics.averagePercentage}%
                  </h3>
                  <p className="text-gray-600 font-medium">
                    Average Percentage
                  </p>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200 group">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:scale-105 transition-transform">
                    <Trophy className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-3xl font-bold text-gray-900 mb-1">
                    {testResults.statistics.topScorers.length > 0 ? testResults.statistics.topScorers[0].percentage.toFixed(1) : 0}%
                  </h3>
                  <p className="text-gray-600 font-medium">
                    Highest Score
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Charts */}
          {testResults.test && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Marks Distribution */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
                    <Target className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">
                      Marks Distribution
                  </h3>
                </div>
                  <ResponsiveContainer width="100%" height={350}>
                    <PieChart>
                      <Pie
                        data={getMarksDistributionData()}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ range, count }: any) => `${range}: ${count}`}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="count"
                        animationBegin={0}
                        animationDuration={1000}
                      >
                        {getMarksDistributionData().map((_, index) => (
                          <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip 
                        contentStyle={{
                        background: 'white',
                        border: '1px solid #e5e7eb',
                          borderRadius: 12,
                        boxShadow: '0 10px 25px rgba(0, 0, 0, 0.1)'
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
              </div>

            {/* Grade-wise Performance */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all duration-200">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                    <School className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">
                      Grade-wise Performance
                  </h3>
                </div>
                  <ResponsiveContainer width="100%" height={350}>
                    <BarChart data={getGradeDistributionData()}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                      <XAxis 
                        dataKey="grade" 
                        tick={{ fill: '#6b7280', fontWeight: 600 }}
                      axisLine={{ stroke: '#e5e7eb' }}
                      />
                      <YAxis 
                        tick={{ fill: '#6b7280', fontWeight: 600 }}
                      axisLine={{ stroke: '#e5e7eb' }}
                      />
                      <Tooltip 
                        contentStyle={{
                        background: 'white',
                        border: '1px solid #e5e7eb',
                          borderRadius: 12,
                        boxShadow: '0 10px 25px rgba(0, 0, 0, 0.1)'
                        }}
                      />
                      <Legend />
                      <Bar 
                        dataKey="averageMarks" 
                        fill="url(#gradeGradient)" 
                        name="Average Marks"
                        radius={[4, 4, 0, 0]}
                        animationBegin={0}
                        animationDuration={1000}
                      />
                      <defs>
                        <linearGradient id="gradeGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#10b981" />
                        <stop offset="100%" stopColor="#059669" />
                        </linearGradient>
                      </defs>
                    </BarChart>
                  </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* Top Scorers */}
          {testResults.test && testResults.statistics.topScorers.length > 0 && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
              <div className="p-6">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-xl flex items-center justify-center shadow-lg">
                    <Award className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">
                      Top Scorers
                  </h3>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {testResults.statistics.topScorers.map((scorer, index) => (
                    <div
                        key={index}
                      className={`p-4 rounded-xl border-2 transition-all duration-200 hover:shadow-md ${
                        index < 3 
                          ? 'bg-gradient-to-r from-yellow-50 to-yellow-100 border-yellow-300' 
                          : 'bg-gray-50 border-gray-200'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shadow-lg ${
                          index < 3 
                            ? 'bg-gradient-to-br from-yellow-500 to-yellow-600' 
                            : 'bg-gradient-to-br from-gray-500 to-gray-600'
                        }`}>
                          {index === 0 && <Trophy className="h-5 w-5 text-white" />}
                          {index === 1 && <Star className="h-5 w-5 text-white" />}
                          {index === 2 && <Award className="h-5 w-5 text-white" />}
                          {index > 2 && <span className="text-white font-bold text-sm">{index + 1}</span>}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900 mb-1">
                              {scorer.studentName}
                          </h4>
                          <p className={`text-2xl font-bold ${
                            index < 3 ? 'text-yellow-600' : 'text-gray-600'
                          }`}>
                              {scorer.percentage.toFixed(1)}%
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Results Table */}
          {testResults.test && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 mb-8">
              <div className="p-6">
                <div className="flex items-center space-x-3 mb-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
                    <Users className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900">
                    Student Results ({testResults.results.length} students)
                  </h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left py-3 px-4 font-semibold text-gray-900">Roll No</th>
                        <th className="text-left py-3 px-4 font-semibold text-gray-900">Name</th>
                        <th className="text-left py-3 px-4 font-semibold text-gray-900">Grade</th>
                        <th className="text-right py-3 px-4 font-semibold text-gray-900">Marks Obtained</th>
                        <th className="text-right py-3 px-4 font-semibold text-gray-900">Total Marks</th>
                        <th className="text-right py-3 px-4 font-semibold text-gray-900">Percentage</th>
                        <th className="text-left py-3 px-4 font-semibold text-gray-900">Submission Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      {testResults.results.map((result) => (
                        <tr 
                          key={result.id}
                          className="border-b border-gray-100 hover:bg-gray-50 transition-colors"
                        >
                          <td className="py-3 px-4 font-medium text-gray-900">{result.rollNo}</td>
                          <td className="py-3 px-4 font-medium text-gray-900">{result.name}</td>
                          <td className="py-3 px-4">
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                              {result.grade}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-right font-medium text-gray-900">
                            {result.marksObtained}
                          </td>
                          <td className="py-3 px-4 text-right font-medium text-gray-600">
                            {result.totalMarks}
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end space-x-2">
                              <div className="w-16 bg-gray-200 rounded-full h-2">
                                <div 
                                  className={`h-2 rounded-full ${
                                    result.percentage >= 80 
                                      ? 'bg-green-500'
                                      : result.percentage >= 60
                                      ? 'bg-yellow-500'
                                      : 'bg-red-500'
                                  }`}
                                  style={{ width: `${result.percentage}%` }}
                                ></div>
                              </div>
                              <span className={`font-bold text-sm ${
                                result.percentage >= 80 
                                  ? 'text-green-600'
                                    : result.percentage >= 60
                                  ? 'text-yellow-600'
                                  : 'text-red-600'
                              }`}>
                                {result.percentage.toFixed(1)}%
                              </span>
                            </div>
                          </td>
                          <td className="py-3 px-4 text-gray-600 text-sm">
                            <div className="flex items-center space-x-1">
                              <Clock className="h-4 w-4 text-gray-400" />
                              <span>{new Date(result.submittedAt).toLocaleString()}</span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* No Test Results Message */}
      {testResults && !testResults.test && !loading && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-12 text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Target className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">
              No Test Results Found
              </h3>
              <p className="text-gray-600 text-lg">
              {selectedSchool?.school_name || selectedSchool?.name} has no test results for the selected test yet
              </p>
            </div>
          </div>
      )}

      {!selectedSchoolId && !loading && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-12 text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Building2 className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">
              Select a School to View Test Results
              </h3>
              <p className="text-gray-600 text-lg">
              Choose a school from the dropdown above to see their assigned tests and results
              </p>
            </div>
          </div>
      )}

      {selectedSchoolId && !selectedTestId && !loading && assignedTests.length === 0 && (
          <div className="bg-white rounded-xl shadow-sm border border-gray-200">
            <div className="p-12 text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-yellow-500 to-yellow-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Target className="h-10 w-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">
              No Tests Assigned
              </h3>
              <p className="text-gray-600 text-lg">
              {selectedSchool?.school_name || selectedSchool?.name} has no tests assigned yet
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminResultsView;
