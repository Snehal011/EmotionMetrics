import { useEffect, useState } from 'react';
import { Plus, Save, Trash2, Undo2, Send, CheckCircle, AlertCircle } from 'lucide-react';
import { getSchools, publishQuestionnaire, testAdminRoutes, testServerHealth, testPublicAdminEndpoint } from '../lib/api';

type Option = { id: string; text: string };
type Question = { id: string; text: string; options: Option[]; correctOptionId?: string };
type Section = { id: string; title: string; intro?: string; questions: Question[] };

type Questionnaire = {
  title: string;
  description: string;
  ratingScaleText: string;
  sections: Section[];
};

const fivePointOptions = (): Option[] => [
  { id: crypto.randomUUID(), text: '1 - Poor' },
  { id: crypto.randomUUID(), text: '2 - Fair' },
  { id: crypto.randomUUID(), text: '3 - Good' },
  { id: crypto.randomUUID(), text: '4 - Very Good' },
  { id: crypto.randomUUID(), text: '5 - Excellent' },
];

const defaultQuestionnaire = (): Questionnaire => ({
  title: 'Happy Art Project - Student Assessment',
  description:
    'Teachers rate each statement on a 1–5 scale: 1-Poor, 2-Fair, 3-Good, 4-Very Good, 5-Excellent. Assess before and after the Happy Art Project.',
  ratingScaleText:
    'Rating Scale: 1 - Poor   2 - Fair    3 - Good    4 - Very Good    5 - Excellent',
  sections: [
    {
      id: 'section-a',
      title: 'A. Academic Behavior',
      intro: "Rate the following statements based on your observation of the student's academic behavior.",
      questions: [
        { id: crypto.randomUUID(), text: 'The student is actively engaged in learning activities.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'The student consistently completes assignments on time.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'The student participates actively in class discussions.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'The student demonstrates improvement in academic performance over time.', options: fivePointOptions() },
      ],
    },
    {
      id: 'section-b',
      title: 'B. Social Behavior',
      intro: "Rate the following statements based on your observation of the student's social behavior.",
      questions: [
        { id: crypto.randomUUID(), text: 'The student communicates effectively with fellow students and teachers.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'The student collaborates well with classmates on group projects.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'The student handles conflicts with fellow students in a constructive manner.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'The student builds and maintains healthy relationships with others.', options: fivePointOptions() },
      ],
    },
    {
      id: 'section-c',
      title: 'C. Emotional Behavior',
      intro: "Rate the following statements based on your observation of the student's emotional behavior.",
      questions: [
        { id: crypto.randomUUID(), text: 'The student manages their emotions effectively.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'The student responds to stress and frustration in a healthy way.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'The student manages his/her anger effectively.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'The student demonstrates overall emotional well-being.', options: fivePointOptions() },
      ],
    },
    {
      id: 'section-d',
      title: 'D. Happiness',
      intro: 'Rate the following statements based on your observation of the student’s happiness.',
      questions: [
        { id: crypto.randomUUID(), text: 'The student expresses happiness in small achievements.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'The student enjoys participating in learning activities.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'The student exhibits a positive attitude towards the daily routine.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'The student expresses general satisfaction with their school experience.', options: fivePointOptions() },
        { id: crypto.randomUUID(), text: 'How is the student’s overall emotional expression?', options: fivePointOptions() },
      ],
    },
  ],
});

const STORAGE_KEY = 'hap-default-questionnaire-v1';

export default function DefaultQuestionnaireEditor() {
  const [questionnaire, setQuestionnaire] = useState<Questionnaire>(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        return JSON.parse(raw) as Questionnaire;
      } catch {}
    }
    return defaultQuestionnaire();
  });

  // Publish functionality state
  const [schools, setSchools] = useState<Array<{ id: string; name: string; email: string }>>([]);
  const [selectedSchoolId, setSelectedSchoolId] = useState<string>('');
  const [isPublishing, setIsPublishing] = useState(false);
  const [showPublishDropdown, setShowPublishDropdown] = useState(false);
  const [publishStatus, setPublishStatus] = useState<{
    type: 'success' | 'error' | null;
    message: string;
  }>({ type: null, message: '' });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(questionnaire));
  }, [questionnaire]);

  // Fetch schools on component mount
  useEffect(() => {
    const fetchSchools = async () => {
      try {
        // Test server health first
        try {
          console.log('Testing server health...');
          const healthResult = await testServerHealth();
          console.log('Server health result:', healthResult);
        } catch (healthError) {
          console.error('Server health check failed:', healthError);
          console.log('Health error response:', healthError.response);
          console.log('Health error status:', healthError.response?.status);
        }
        
        // Test public admin endpoint
        try {
          console.log('Testing public admin endpoint...');
          const publicResult = await testPublicAdminEndpoint();
          console.log('Public admin endpoint result:', publicResult);
        } catch (publicError) {
          console.error('Public admin endpoint failed:', publicError);
          console.log('Public error response:', publicError.response);
          console.log('Public error status:', publicError.response?.status);
        }
        
        // Test admin routes (but don't let it block schools loading)
        try {
          console.log('Testing admin routes...');
          const testResult = await testAdminRoutes();
          console.log('Admin routes test result:', testResult);
        } catch (testError) {
          console.warn('Admin routes test failed:', testError);
        }
        
        // Check if user is authenticated
        const token = localStorage.getItem('auth_token');
        console.log('Auth token present:', !!token);
        console.log('Token value:', token ? token.substring(0, 20) + '...' : 'No token');
        
        const schoolsData = await getSchools();
        console.log('Schools data:', schoolsData);
        
        // Transform the data to match expected format
        const transformedSchools = schoolsData.map((school: any) => ({
          id: school._id,
          name: school.school_name || school.name,
          email: school.email
        }));
        
        console.log('Transformed schools:', transformedSchools);
        setSchools(transformedSchools);
      } catch (error) {
        console.error('Error fetching schools:', error);
        console.log('Full error object:', error);
        console.log('Error response:', error.response);
        console.log('Error response data:', error.response?.data);
        setPublishStatus({
          type: 'error',
          message: 'Failed to load schools. Please try again.'
        });
      }
    };

    fetchSchools();
  }, []);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as Element;
      if (showPublishDropdown && !target.closest('.publish-dropdown')) {
        setShowPublishDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showPublishDropdown]);

  const addQuestion = (sectionId: string) => {
    setQuestionnaire((prev) => ({
      ...prev,
      sections: prev.sections.map((s) =>
        s.id === sectionId
          ? {
              ...s,
              questions: [
                ...s.questions,
                {
                  id: crypto.randomUUID(),
                  text: `New question ${s.questions.length + 1}`,
                  options: fivePointOptions(),
                  correctOptionId: undefined,
                },
              ],
            }
          : s
      ),
    }));
  };

  const removeQuestion = (sectionId: string, questionId: string) => {
    setQuestionnaire((prev) => ({
      ...prev,
      sections: prev.sections.map((s) =>
        s.id === sectionId ? { ...s, questions: s.questions.filter((q) => q.id !== questionId) } : s
      ),
    }));
  };

  const updateQuestionText = (sectionId: string, questionId: string, text: string) => {
    setQuestionnaire((prev) => ({
      ...prev,
      sections: prev.sections.map((s) =>
        s.id === sectionId
          ? {
              ...s,
              questions: s.questions.map((q) => (q.id === questionId ? { ...q, text } : q)),
            }
          : s
      ),
    }));
  };

  const updateOptionText = (sectionId: string, questionId: string, optionId: string, text: string) => {
    setQuestionnaire((prev) => ({
      ...prev,
      sections: prev.sections.map((s) =>
        s.id === sectionId
          ? {
              ...s,
              questions: s.questions.map((q) =>
                q.id === questionId
                  ? { ...q, options: q.options.map((o) => (o.id === optionId ? { ...o, text } : o)) }
                  : q
              ),
            }
          : s
      ),
    }));
  };

  const removeOption = (sectionId: string, questionId: string, optionId: string) => {
    setQuestionnaire((prev) => ({
      ...prev,
      sections: prev.sections.map((s) =>
        s.id === sectionId
          ? {
              ...s,
              questions: s.questions.map((q) => {
                if (q.id === questionId) {
                  const newOptions = q.options.filter((o) => o.id !== optionId);
                  const newCorrect = q.correctOptionId === optionId ? undefined : q.correctOptionId;
                  return { ...q, options: newOptions, correctOptionId: newCorrect };
                }
                return q;
              }),
            }
          : s
      ),
    }));
  };
  const markCorrectOption = (sectionId: string, questionId: string, optionId: string) => {
    setQuestionnaire((prev) => ({
      ...prev,
      sections: prev.sections.map((s) =>
        s.id === sectionId
          ? {
              ...s,
              questions: s.questions.map((q) =>
                q.id === questionId ? { ...q, correctOptionId: optionId } : q
              ),
            }
          : s
      ),
    }));
  };

  const addOption = (sectionId: string, questionId: string) => {
    setQuestionnaire((prev) => ({
      ...prev,
      sections: prev.sections.map((s) =>
        s.id === sectionId
          ? {
              ...s,
              questions: s.questions.map((q) =>
                q.id === questionId
                  ? {
                      ...q,
                      options: [...q.options, { id: crypto.randomUUID(), text: `Option ${q.options.length + 1}` }],
                    }
                  : q
              ),
            }
          : s
      ),
    }));
  };

  const handleSave = () => {
    // Save current questionnaire to localStorage
    localStorage.setItem(STORAGE_KEY, JSON.stringify(questionnaire));
    
    // Create a new saved questionnaire set
    const savedQuestionnaire = {
      id: crypto.randomUUID(),
      title: questionnaire.title,
      description: questionnaire.description,
      ratingScaleText: questionnaire.ratingScaleText,
      createdAt: new Date().toISOString(),
      sections: questionnaire.sections,
      totalQuestions: questionnaire.sections.reduce((total, section) => total + section.questions.length, 0)
    };
    
    // Get existing saved questionnaires
    const existingSaved = JSON.parse(localStorage.getItem('saved-questionnaires') || '[]');
    const updatedSaved = [...existingSaved, savedQuestionnaire];
    
    // Save updated list
    localStorage.setItem('saved-questionnaires', JSON.stringify(updatedSaved));
    
    alert('Questionnaire saved successfully! You can now view it in the saved questionnaires section.');
  };

  const handleReset = () => {
    if (confirm('Reset to the original default questionnaire?')) {
      const d = defaultQuestionnaire();
      setQuestionnaire(d);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(d));
    }
  };

  const handlePublish = async () => {
    if (!selectedSchoolId) {
      setPublishStatus({
        type: 'error',
        message: 'Please select a school to publish to.'
      });
      return;
    }

    setIsPublishing(true);
    setPublishStatus({ type: null, message: '' });

    try {
      // Generate a unique questionnaire ID based on the current questionnaire
      const questionnaireId = `questionnaire_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      console.log('Publishing questionnaire with data:', {
        questionnaireId,
        schoolId: selectedSchoolId
      });
      
      const response = await publishQuestionnaire({
        questionnaireId,
        schoolId: selectedSchoolId
      });
      
      console.log('Publish response:', response);

      setPublishStatus({
        type: 'success',
        message: `Questionnaire published successfully to ${schools.find(s => s.id === selectedSchoolId)?.name}!`
      });

      // Reset selection
      setSelectedSchoolId('');
      setShowPublishDropdown(false);

      // Clear status after 3 seconds
      setTimeout(() => {
        setPublishStatus({ type: null, message: '' });
      }, 3000);

    } catch (error: any) {
      console.error('Error publishing questionnaire:', error);
      console.log('Full error object:', error);
      console.log('Error response:', error.response);
      console.log('Error response data:', error.response?.data);
      console.log('Error message:', error.message);
      console.log('Error stack:', error.stack);
      
      setPublishStatus({
        type: 'error',
        message: error.response?.data?.message || error.message || 'Failed to publish questionnaire. Please try again.'
      });
    } finally {
      setIsPublishing(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow border border-gray-200">
      <div className="p-6 border-b border-gray-200">
        <h2 className="text-xl font-bold text-gray-900">Edit Default Questionnaire</h2>
        <p className="text-gray-600 text-sm">Update the quiz students will take.</p>
      </div>

      <div className="p-6 space-y-6">
        {/* Title */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
          <input
            type="text"
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            value={questionnaire.title}
            onChange={(e) => setQuestionnaire({ ...questionnaire, title: e.target.value })}
          />
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
          <textarea
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            value={questionnaire.description}
            onChange={(e) => setQuestionnaire({ ...questionnaire, description: e.target.value })}
          />
        </div>

        <div className="text-sm text-gray-700 bg-gray-50 rounded-lg p-3 border border-gray-200 break-words whitespace-normal">
          {questionnaire.ratingScaleText}
        </div>

        {/* Sections */}
        <div className="space-y-6">
          <h3 className="text-lg font-semibold text-gray-900">Questions</h3>
          {questionnaire.sections.map((section) => (
            <div key={section.id} className="border rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-semibold text-gray-900">{section.title}</h4>
                  {section.intro && <p className="text-sm text-gray-600 mt-1">{section.intro}</p>}
                </div>
                <button
                  onClick={() => addQuestion(section.id)}
                  className="inline-flex items-center px-3 py-1.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm"
                >
                  <Plus className="w-4 h-4 mr-1" /> Add question
                </button>
              </div>

              <div className="mt-4 space-y-4">
                {section.questions.map((q, idx) => (
                  <div key={q.id} className="bg-white border rounded-lg">
                    <div className="flex items-center justify-between p-3 border-b">
                      <div className="text-sm font-medium text-gray-700">Question {idx + 1}</div>
                      <button
                        onClick={() => removeQuestion(section.id, q.id)}
                        className="text-red-600 hover:bg-red-50 rounded px-2 py-1 text-sm inline-flex items-center"
                        title="Remove"
                      >
                        <Trash2 className="w-4 h-4 mr-1" /> Remove
                      </button>
                    </div>
                    <div className="p-3 space-y-3">
                      <input
                        value={q.text}
                        onChange={(e) => updateQuestionText(section.id, q.id, e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                      <div>
                        <div className="text-sm font-medium text-gray-700 mb-2">Options</div>
                        <div className="space-y-2">
                          {q.options.map((opt) => (
                            <div key={opt.id} className="flex items-center gap-2">
                              <div className={`w-4 h-4 rounded-full border border-gray-300 bg-gray-50`}></div>
                              <input
                                value={opt.text}
                                onChange={(e) => updateOptionText(section.id, q.id, opt.id, e.target.value)}
                                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                              />
                              <button
                                onClick={() => removeOption(section.id, q.id, opt.id)}
                                className="text-red-600 hover:bg-red-50 rounded px-2 py-1 text-sm"
                              >
                                Delete
                              </button>
                            </div>
                          ))}
                        </div>
                        <button
                          onClick={() => addOption(section.id, q.id)}
                          className="mt-2 inline-flex items-center px-3 py-1.5 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 text-sm"
                        >
                          <Plus className="w-4 h-4 mr-1" /> Add option
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Status Messages */}
        {publishStatus.type && (
          <div className={`p-4 rounded-lg flex items-center ${
            publishStatus.type === 'success' 
              ? 'bg-green-50 border border-green-200 text-green-800' 
              : 'bg-red-50 border border-red-200 text-red-800'
          }`}>
            {publishStatus.type === 'success' ? (
              <CheckCircle className="w-5 h-5 mr-2" />
            ) : (
              <AlertCircle className="w-5 h-5 mr-2" />
            )}
            <span className="font-medium">{publishStatus.message}</span>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center">
          <div className="flex gap-3">
            <button
              onClick={handleReset}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              <Undo2 className="w-4 h-4 mr-2" /> Reset
            </button>
            <button
              onClick={handleSave}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Save className="w-4 h-4 mr-2" /> Save changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
