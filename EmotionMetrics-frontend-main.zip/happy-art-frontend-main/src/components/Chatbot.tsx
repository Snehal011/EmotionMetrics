import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageCircle, 
  X, 
  Send, 
  Bot, 
  User, 
  Loader2, 
  BarChart3,
  Heart,
  Calendar,
  FileText,
  Lightbulb,
  TrendingUp,
  Target,
  Upload,
  Palette,
  Building2,
  ClipboardList,
  AlertCircle
} from 'lucide-react';
import { analyzeMood, checkMoodAnalysisHealth, MoodAnalysisResponse } from '../lib/api';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  type?: 'text' | 'suggestion' | 'help' | 'mood_analysis';
  imageData?: string;
  moodAnalysis?: {
    mood: string;
    recommendations: string[];
  };
}

interface ChatbotProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Chatbot({ isOpen, onClose }: ChatbotProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: "Hello! I'm your HappyArt assistant. I can help you with system management, school administration, test creation, analytics, and art therapy programs. How can I assist you today?",
      sender: 'bot',
      timestamp: new Date(),
      type: 'text'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [moodAnalysisAvailable, setMoodAnalysisAvailable] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  // Check if mood analysis service is available
  useEffect(() => {
    const checkMoodAnalysis = async () => {
      try {
        await checkMoodAnalysisHealth();
        setMoodAnalysisAvailable(true);
      } catch (error) {
        console.log('Mood analysis service not available');
        setMoodAnalysisAvailable(false);
      }
    };
    
    if (isOpen) {
      checkMoodAnalysis();
    }
  }, [isOpen]);

  const quickSuggestions = [
    { text: "Show me student happiness trends", icon: TrendingUp },
    { text: "How do I create a questionnaire?", icon: FileText },
    { text: "What's the average improvement rate?", icon: BarChart3 },
    { text: "Analyze student artwork mood", icon: Palette },
    { text: "Help with analytics dashboard", icon: Target },
    { text: "Explain art therapy benefits", icon: Heart },
    { text: "Schedule a session", icon: Calendar },
    { text: "How do I manage schools?", icon: Building2 },
    { text: "Create and publish tests", icon: ClipboardList },
    { text: "View system analytics", icon: BarChart3 }
  ];

  const handleSendMessage = async () => {
    if (!inputText.trim() && !isUploading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText.trim(),
      sender: 'user',
      timestamp: new Date(),
      type: 'text'
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    try {
      // Simulate bot response based on user input
      const response = await generateBotResponse(inputText.trim());
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response.text || '',
        sender: 'bot',
        timestamp: new Date(),
        type: response.type || 'text',
        moodAnalysis: response.moodAnalysis,
        imageData: response.imageData
      };

      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Error generating response:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: "I'm sorry, I encountered an error. Please try again.",
        sender: 'bot',
        timestamp: new Date(),
        type: 'text'
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const generateBotResponse = async (userInput: string): Promise<Partial<Message>> => {
    const lowerInput = userInput.toLowerCase();

    // Handle mood analysis requests
    if (lowerInput.includes('analyze') && lowerInput.includes('artwork') && moodAnalysisAvailable) {
      return {
        text: "I can help you analyze artwork for mood detection! Please upload an image of the artwork using the upload button below.",
        type: 'text'
      };
    }

    // Handle other common queries
    if (lowerInput.includes('happiness') || lowerInput.includes('trend')) {
      return {
        text: "Based on recent data, student happiness scores have improved by 15% this month. The average happiness score is 8.7/10, with group art therapy sessions showing the highest impact.",
        type: 'text'
      };
    }

    if (lowerInput.includes('questionnaire') || lowerInput.includes('create')) {
      return {
        text: "To create a questionnaire:\n1. Go to the Questionnaires section\n2. Click 'Create New Questionnaire'\n3. Add your questions and options\n4. Set the duration and target grade\n5. Publish when ready\n\nWould you like me to guide you through any specific step?",
        type: 'text'
      };
    }

    if (lowerInput.includes('analytics') || lowerInput.includes('dashboard')) {
      return {
        text: "Our analytics dashboard provides comprehensive insights including:\n• Student progress tracking\n• Session effectiveness metrics\n• Happiness score trends\n• School performance comparisons\n\nYou can access detailed analytics in the Analytics section of your dashboard.",
        type: 'text'
      };
    }

    if (lowerInput.includes('art therapy') || lowerInput.includes('benefits')) {
      return {
        text: "Art therapy offers numerous benefits for students:\n• Improved emotional expression\n• Enhanced creativity and problem-solving\n• Reduced stress and anxiety\n• Better social skills through group activities\n• Increased self-confidence and self-awareness\n\nStudies show 85% of students report improved mood after art therapy sessions.",
        type: 'text'
      };
    }

    // Default response
    return {
      text: "I'm here to help you with system management, school administration, test creation, analytics, and art therapy programs. You can ask me about student happiness trends, creating questionnaires, or analyzing artwork. How can I assist you today?",
      type: 'text'
    };
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'application/pdf'];
    if (!validTypes.includes(file.type)) {
      alert('Please upload a JPG, PNG, or PDF file.');
      return;
    }

    // Validate file size (10MB limit)
    if (file.size > 10 * 1024 * 1024) {
      alert('File size must be less than 10MB.');
      return;
    }

    setIsUploading(true);

    // Add user message showing the upload
    const userMessage: Message = {
      id: Date.now().toString(),
      text: `Uploaded artwork: ${file.name}`,
      sender: 'user',
      timestamp: new Date(),
      type: 'text',
      imageData: URL.createObjectURL(file)
    };

    setMessages(prev => [...prev, userMessage]);

    try {
      const response: MoodAnalysisResponse = await analyzeMood(file);
      
      if (response.success && response.analysis) {
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          text: "I've analyzed your artwork! Here are the results:",
          sender: 'bot',
          timestamp: new Date(),
          type: 'mood_analysis',
          imageData: response.image_data,
          moodAnalysis: {
            mood: response.analysis.mood_description,
            recommendations: response.analysis.recommendations
          }
        };
        setMessages(prev => [...prev, botMessage]);
      } else {
        throw new Error(response.error || 'Analysis failed');
      }
    } catch (error) {
      console.error('Mood analysis error:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: "I'm sorry, I couldn't analyze the artwork. Please make sure the image is clear and try again.",
        sender: 'bot',
        timestamp: new Date(),
        type: 'text'
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsUploading(false);
      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-end">
      {/* Overlay for modal effect */}
      <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" onClick={onClose}></div>
      {/* Chat Window - fixed position */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md h-[600px] flex flex-col z-50 m-8">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-2xl">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <Bot className="h-6 w-6" />
            </div>
            <div>
              <h3 className="font-semibold">HappyArt Assistant</h3>
              <p className="text-xs opacity-90">Online now</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-full transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex items-start space-x-2 max-w-[80%] ${message.sender === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  message.sender === 'user' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 text-gray-600'
                }`}>
                  {message.sender === 'user' ? (
                    <User className="h-4 w-4" />
                  ) : (
                    <Bot className="h-4 w-4" />
                  )}
                </div>
                <div className={`rounded-2xl px-4 py-2 ${
                  message.sender === 'user'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-900'
                }`}>
                  <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                  {/* Mood Analysis Display */}
                  {message.type === 'mood_analysis' && message.moodAnalysis && (
                    <div className="mt-3 space-y-3">
                      {/* Image Display */}
                      {message.imageData && (
                        <div className="bg-white rounded-lg p-2">
                          <img 
                            src={message.imageData} 
                            alt="Analyzed artwork" 
                            className="max-w-full h-auto rounded-lg shadow-sm"
                          />
                        </div>
                      )}
                      {/* Mood Result */}
                      <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-3 border border-purple-200">
                        <div className="flex items-center space-x-2 mb-2">
                          <Palette className="h-4 w-4 text-purple-600" />
                          <span className="text-sm font-semibold text-purple-800">Mood Analysis</span>
                        </div>
                        <p className="text-sm text-purple-700 font-medium">
                          {message.moodAnalysis.mood}
                        </p>
                      </div>
                      {/* Recommendations */}
                      <div className="bg-green-50 rounded-lg p-3 border border-green-200">
                        <div className="flex items-center space-x-2 mb-2">
                          <Lightbulb className="h-4 w-4 text-green-600" />
                          <span className="text-sm font-semibold text-green-800">Recommendations</span>
                        </div>
                        <ul className="space-y-1">
                          {message.moodAnalysis.recommendations.map((rec, index) => (
                            <li key={index} className="text-sm text-green-700 flex items-start space-x-2">
                              <span className="text-green-500 mt-1">•</span>
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                  <p className={`text-xs mt-1 ${
                    message.sender === 'user' ? 'text-blue-100' : 'text-gray-500'
                  }`}>
                    {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="flex items-start space-x-2">
                <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                  <Bot className="h-4 w-4 text-gray-600" />
                </div>
                <div className="bg-gray-100 rounded-2xl px-4 py-2">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
        {/* Quick Suggestions */}
        {messages.length === 1 && (
          <div className="px-4 pb-2">
            <p className="text-xs text-gray-500 mb-2">Quick suggestions:</p>
            <div className="grid grid-cols-1 gap-1">
              {quickSuggestions
                .filter(suggestion => 
                  moodAnalysisAvailable || 
                  !suggestion.text.toLowerCase().includes('analyze') || 
                  !suggestion.text.toLowerCase().includes('artwork')
                )
                .slice(0, 3)
                .map((suggestion, index) => (
                <button
                  key={index}
                  onClick={() => setInputText(suggestion.text)}
                  className="flex items-center space-x-2 p-2 text-left text-xs bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <suggestion.icon className="h-3 w-3 text-gray-500" />
                  <span className="text-gray-700">{suggestion.text}</span>
                </button>
              ))}
            </div>
          </div>
        )}
        {/* Input */}
        <div className="p-4 border-t border-gray-200 bg-gray-50 rounded-b-2xl">
          <form
            onSubmit={e => { e.preventDefault(); handleSendMessage(); }}
            className="flex items-center space-x-2"
          >
            <input
              ref={inputRef}
              type="text"
              className="flex-1 px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Type your message..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={isTyping || isUploading}
            />
            {/* Image Upload Button */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,.pdf"
              onChange={handleImageUpload}
              className="hidden"
              disabled={isTyping || isUploading || !moodAnalysisAvailable}
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isTyping || isUploading || !moodAnalysisAvailable}
              className="p-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              title={moodAnalysisAvailable ? "Upload artwork for mood analysis" : "Mood analysis service unavailable"}
            >
              <Upload className="h-4 w-4" />
            </button>
            <button
              type="submit"
              disabled={!inputText.trim() || isTyping || isUploading}
              className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isTyping ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Send className="h-4 w-4" />
              )}
            </button>
          </form>
          {/* Upload Status */}
          {isUploading && (
            <div className="mt-2 text-xs text-purple-600 flex items-center space-x-1">
              <Loader2 className="h-3 w-3 animate-spin" />
              <span>Analyzing artwork...</span>
            </div>
          )}
          {/* Mood Analysis Status */}
          {!moodAnalysisAvailable && (
            <div className="mt-2 text-xs text-orange-600 flex items-center space-x-1">
              <AlertCircle className="h-3 w-3" />
              <span>Mood analysis service unavailable</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// Floating Chat Button Component
export function ChatButton({ onClick }: { onClick: () => void }) {
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      setIsVisible(scrollTop < 100);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!isVisible) return null;

  return (
    <button
      onClick={onClick}
      className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 z-40 flex items-center justify-center"
      aria-label="Open chat assistant"
    >
      <MessageCircle className="h-6 w-6" />
    </button>
  );
}
