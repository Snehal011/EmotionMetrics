import { useState, useRef, useEffect } from 'react';
import { Camera, Video, StopCircle, Loader2, AlertCircle, CheckCircle, Heart } from 'lucide-react';

interface EmotionScores {
  happy: number;
  angry: number;
  stress: number;
  anxiety: number;
}

interface PredictionResult {
  emotion: string;
  all_scores: EmotionScores;
}

export default function HappinessDetection() {
  const [isCamera, setIsCamera] = useState(false);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [emotionScores, setEmotionScores] = useState<Partial<Record<string, number>>>({});
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Start camera
  const startCamera = async () => {
    try {
      setError(null);
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user'
        } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setIsCamera(true);
      }
    } catch (err) {
      setError('Unable to access camera. Please grant camera permissions.');
      console.error('Camera error:', err);
    }
  };

  // Stop camera
  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsCamera(false);
  };

  // Capture frame and send to Flask API
  const captureAndPredict = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    setLoading(true);
    setError(null);

    try {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;

      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Unable to get canvas context');
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

      const imageData = canvas.toDataURL('image/jpeg', 0.8);

      const response = await fetch('http://localhost:5001/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: imageData }),
      });

      if (!response.ok) throw new Error(`API error: ${response.status}`);

      const result: PredictionResult = await response.json();

      // *Jugaad swap: happy <-> stress*
      const swappedEmotion = result.emotion === 'happy'
        ? 'stress'
        : result.emotion === 'stress'
        ? 'happy'
        : result.emotion;

      setPrediction({
        ...result,
        emotion: swappedEmotion
      });

      if (result && result.all_scores) {
        setEmotionScores({
          Happy: result.all_scores.stress || 0,   // swapped
          Angry: result.all_scores.angry || 0,
          Stress: result.all_scores.happy || 0,   // swapped
          Anxiety: result.all_scores.anxiety || 0
        });
      } else {
        setEmotionScores({});
      }

    } catch (err: any) {
      setError(err.message || 'Failed to analyze emotion. Please try again.');
      console.error('Prediction error:', err);
    } finally {
      setLoading(false);
    }
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => stopCamera();
  }, []);

  const getEmotionColor = (emotion: string) => {
    switch (emotion.toLowerCase()) {
      case 'happy':
        return 'text-green-600 bg-green-100';
      case 'angry':
        return 'text-red-600 bg-red-100';
      case 'stress':
        return 'text-orange-600 bg-orange-100';
      case 'anxiety':
        return 'text-yellow-600 bg-yellow-100';
      default:
        return 'text-gray-600 bg-gray-100';
    }
  };

  const getEmotionEmoji = (emotion: string) => {
    switch (emotion.toLowerCase()) {
      case 'happy':
        return '😊';
      case 'angry':
        return '😠';
      case 'stress':
        return '😰';
      case 'anxiety':
        return '😟';
      default:
        return '😐';
    }
  };

  return (
    <div className="p-4 lg:p-8 max-w-7xl mx-auto w-full">
      <div className="bg-white rounded-2xl shadow-lg p-6">
        {/* Header */}
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-3 bg-gradient-to-br from-pink-500 to-rose-600 rounded-xl">
            <Heart className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Happiness Detection</h2>
            <p className="text-gray-600">Detect and analyze emotional states before and after art sessions.</p>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start space-x-3">
            <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-red-800">Error</p>
              <p className="text-sm text-red-600">{error}</p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Camera Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Real-time Emotion Detection</h3>
            <div className="relative bg-gray-900 rounded-xl overflow-hidden aspect-video">
              <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
              <canvas ref={canvasRef} className="hidden" />

              {!isCamera && (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
                  <div className="text-center text-white">
                    <Camera className="h-16 w-16 mx-auto mb-4 opacity-50" />
                    <p className="text-sm opacity-75">Camera is off</p>
                  </div>
                </div>
              )}

              {loading && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                  <div className="text-center text-white">
                    <Loader2 className="h-12 w-12 mx-auto mb-2 animate-spin" />
                    <p className="text-sm">Analyzing emotion...</p>
                  </div>
                </div>
              )}
            </div>

            <div className="flex space-x-3">
              {!isCamera ? (
                <button
                  onClick={startCamera}
                  className="flex-1 flex items-center justify-center space-x-2 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-4 py-3 rounded-lg font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
                >
                  <Video className="h-5 w-5" />
                  <span>Start Camera</span>
                </button>
              ) : (
                <>
                  <button
                    onClick={captureAndPredict}
                    disabled={loading}
                    className="flex-1 flex items-center justify-center space-x-2 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-4 py-3 rounded-lg font-medium transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Camera className="h-5 w-5" />
                    <span>{loading ? 'Analyzing...' : 'Capture'}</span>
                  </button>
                  <button
                    onClick={stopCamera}
                    className="flex items-center justify-center space-x-2 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white px-4 py-3 rounded-lg font-medium transition-all duration-200 shadow-lg hover:shadow-xl"
                  >
                    <StopCircle className="h-5 w-5" />
                    <span>Stop Camera</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Results Section */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-gray-900">Emotion Analysis Results</h3>

            {prediction ? (
              <div className="space-y-4">
                {/* Primary Emotion */}
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-6 border border-purple-200">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-sm font-medium text-gray-700">Detected Emotion</h4>
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  </div>
                  <div className="text-center">
                    <div className="text-6xl mb-3">{getEmotionEmoji(prediction.emotion)}</div>
                    <span className={`inline-block px-4 py-2 rounded-full text-lg font-bold capitalize ${getEmotionColor(prediction.emotion)}`}>
                      {prediction.emotion}
                    </span>
                  </div>
                </div>

                {/* All Emotion Scores */}
                <div className="bg-gray-50 rounded-xl p-6">
                  <h4 className="text-sm font-medium text-gray-700 mb-4">Emotion Breakdown</h4>
                  <div className="space-y-3">
                    {Object.entries(emotionScores).map(([emotion, score]) => (
                      <div key={emotion}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium text-gray-700 capitalize flex items-center space-x-2">
                            <span>{getEmotionEmoji(emotion)}</span>
                            <span>{emotion}</span>
                          </span>
                          <span className="text-sm font-bold text-gray-900">
                            {(score! * 100).toFixed(1)}%
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className={`h-2 rounded-full transition-all duration-500 ${prediction && emotion.toLowerCase() === prediction.emotion.toLowerCase() ? 'bg-gradient-to-r from-purple-600 to-pink-600' : 'bg-gray-400'}`}
                            style={{ width: `${score! * 100}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recommendations */}
                <div className="bg-blue-50 rounded-xl p-6 border border-blue-200">
                  <h4 className="text-sm font-medium text-blue-900 mb-3">💡 Recommendations</h4>
                  <ul className="space-y-2 text-sm text-blue-800">
                    {prediction && prediction.emotion.toLowerCase() === 'happy' && (
                      <>
                        <li>• Continue with positive reinforcement activities</li>
                        <li>• Great time for collaborative art projects</li>
                        <li>• Encourage sharing of creative work</li>
                      </>
                    )}
                    {prediction && prediction.emotion.toLowerCase() === 'angry' && (
                      <>
                        <li>• Consider calming art activities (e.g., mandala coloring)</li>
                        <li>• Use cool colors in artwork</li>
                        <li>• Provide a quiet, comfortable space</li>
                      </>
                    )}
                    {prediction && prediction.emotion.toLowerCase() === 'stress' && (
                      <>
                        <li>• Focus on relaxing art techniques</li>
                        <li>• Include breathing exercises before art session</li>
                        <li>• Use soothing music during activities</li>
                      </>
                    )}
                    {prediction && prediction.emotion.toLowerCase() === 'anxiety' && (
                      <>
                        <li>• Start with simple, guided art activities</li>
                        <li>• Provide clear instructions and structure</li>
                        <li>• Create a supportive, non-judgmental environment</li>
                      </>
                    )}
                  </ul>
                </div>
              </div>
            ) : (
              <div className="bg-gray-50 rounded-xl p-12 text-center">
                <Heart className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                <p className="text-gray-600 font-medium mb-2">No emotion detected yet</p>
                <p className="text-sm text-gray-500">
                  Start the camera and capture to analyze emotions
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Info Section */}
        <div className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6 border border-blue-200">
          <h4 className="text-sm font-semibold text-gray-900 mb-3">ℹ How it works</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-700">
            <div>
              <span className="font-medium text-blue-600">Step 1:</span>
              <p>Click "Start Camera" to enable webcam access</p>
            </div>
            <div>
              <span className="font-medium text-purple-600">Step 2:</span>
              <p>Position your face in the camera view</p>
            </div>
            <div>
              <span className="font-medium text-pink-600">Step 3:</span>
              <p>Click "Capture" to analyze your current emotion</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}