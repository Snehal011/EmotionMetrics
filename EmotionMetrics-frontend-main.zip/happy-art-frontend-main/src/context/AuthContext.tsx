import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import api from '../lib/api';

type UserRole = 'admin' | 'school' | null;

interface AuthContextValue {
  isAuthenticated: boolean;
  role: UserRole;
  token: string | null;
  login: (params: { email: string; password: string }) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [role, setRole] = useState<UserRole>(null);
  const [token, setToken] = useState<string | null>(null);

  const login = async ({ email, password }: { email: string; password: string }) => {
    const res = await api.post('/api/login', { email, password });
    const receivedToken: string = res.data?.token;
    const receivedRole: UserRole = res.data?.role || null;
    setToken(receivedToken);
    setRole(receivedRole);
    localStorage.setItem('auth_token', receivedToken);
    localStorage.setItem('auth_role', receivedRole || '');
  };

  const logout = () => {
    setRole(null);
    setToken(null);
    localStorage.removeItem('auth_token');
    localStorage.removeItem('auth_role');
  };

  // Rehydrate auth state from localStorage on first load
  useEffect(() => {
    try {
      const storedToken = localStorage.getItem('auth_token');
      const storedRole = (localStorage.getItem('auth_role') as UserRole) || null;
      if (storedToken && storedRole) {
        setToken(storedToken);
        setRole(storedRole);
      }
    } catch {}
  }, []);

  const value = useMemo(
    () => ({ isAuthenticated: role !== null, role, token, login, logout }),
    [role, token]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}


