export interface User {
  id: string;
  email: string;
  user_type: 'admin' | 'school';
  school_name?: string;
  created_at: string;
}

export interface School {
  id: string;
  name: string;
  admin_id: string;
  visited: boolean;
  visit_date?: string;
  created_at: string;
}

export interface Question {
  id: string;
  question_text: string;
  question_type: 'pre_test' | 'post_test';
  admin_id: string;
  active: boolean;
  target_school_id?: string;
  created_at: string;
}

export interface StudentResponse {
  id: string;
  student_roll_no: string;
  school_id: string;
  question_id: string;
  response_value: number;
  response_type: 'pre_test' | 'post_test';
  created_at: string;
}

export interface HappinessScore {
  id: string;
  student_roll_no: string;
  school_id: string;
  pre_test_score?: number;
  post_test_score?: number;
  overall_score: number;
  created_at: string;
  updated_at: string;
}