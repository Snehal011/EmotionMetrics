import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000',
  withCredentials: true,
});

// Attach Authorization header from localStorage if present
api.interceptors.request.use((config) => {
  try {
    const token = localStorage.getItem('auth_token');
    if (token) {
      config.headers = config.headers || {};
      (config.headers as any).Authorization = `Bearer ${token}`;
    }
  } catch {}
  return config;
});

// Optional place for response handling; do not clear tokens automatically
api.interceptors.response.use(
  (response) => response,
  (error) => Promise.reject(error)
);

// Test Management API Functions
export interface Test {
  _id: string;
  id?: string; // Optional for compatibility
  name: string;
  type: 'pre' | 'post';
  grade: string;
  subject: string;
  durationMinutes: number;
  startTime: string;
  endTime: string;
  questions: Question[];
  status: 'draft' | 'active' | 'expired' | 'completed';
  totalMarks: number;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
  assignedSchools?: Array<{
    _id: string;
    school_name: string;
  }>;
  schoolNames?: string[];
  __v?: number;
}

export interface Question {
  qid: string;
  text: string;
  type: 'mcq' | 'subjective';
  options?: string[];
  correctOption?: string;
  marks: number;
}

export interface TestResult {
  testId: string;
  testName: string;
  testType: string;
  grade: string;
  subject: string;
  totalMarks: number;
  statistics: {
    totalStudents: number;
    averageMarks: number;
    averagePercentage: number;
    topScores: Array<{
      studentName: string;
      grade: string;
      schoolName: string;
      marksObtained: number;
      percentage: number;
    }>;
    gradeStats: Record<string, {
      count: number;
      totalMarks: number;
      averageMarks: number;
      students: Array<{
        studentName: string;
        marksObtained: number;
        percentage: number;
      }>;
    }>;
  };
  results: Array<{
    studentName: string;
    grade: string;
    schoolName: string;
    marksObtained: number;
    percentage: number;
    submittedAt: string;
  }>;
}

export interface School {
  id: string;
  name: string;
  email: string;
  school_name: string;
}

// Test Management Functions
export const getTests = async (params?: {
  page?: number;
  limit?: number;
  type?: string;
  grade?: string;
  status?: string;
}) => {
  const response = await api.get('/api/admin/tests', { params });
  return response.data;
};

export const createTest = async (testData: {
  name: string;
  type: 'pre' | 'post';
  grade: string;
  subject: string;
  durationMinutes: number;
  startTime: string;
  endTime: string;
  questions: Question[];
}) => {
  const response = await api.post('/api/admin/test', testData);
  return response.data;
};

export const editTest = async (testId: string, testData: {
  name?: string;
  type?: 'pre' | 'post';
  grade?: string;
  subject?: string;
  durationMinutes?: number;
  startTime?: string;
  endTime?: string;
  questions?: Question[];
}) => {
  const response = await api.put(`/api/admin/test/${testId}`, testData);
  return response.data;
};

export const publishTest = async (testId: string, schoolIds: string[]) => {
  const response = await api.post(`/api/admin/test/${testId}/publish`, { schoolIds });
  return response.data;
};

export const expireTest = async (testId: string) => {
  const response = await api.post(`/api/admin/test/${testId}/expire`);
  return response.data;
};

export const deleteTest = async (testId: string) => {
  const response = await api.delete(`/api/admin/test/${testId}`);
  return response.data;
};

export const getTestResults = async (testId: string): Promise<TestResult> => {
  const response = await api.get(`/api/admin/test/${testId}/results`);
  return response.data;
};

export const getSchools = async () => {
  const response = await api.get('/api/admin/schools');
  return response.data;
};

// Test function to check if admin routes are working
export const testAdminRoutes = async () => {
  const response = await api.get('/api/admin/test');
  return response.data;
};

// Test function to check server health
export const testServerHealth = async () => {
  const response = await api.get('/health');
  return response.data;
};

// Test function to check public admin endpoint
export const testPublicAdminEndpoint = async () => {
  const response = await api.get('/api/admin/test-public');
  return response.data;
};

// School Management Functions
export interface AssignedTest {
  id: string;
  testLinkId: string;
  name: string;
  type: 'pre' | 'post';
  grade: string;
  subject: string;
  durationMinutes: number;
  status: 'draft' | 'active' | 'expired' | 'completed';
  startTime: string;
  endTime: string;
  linkHash: string;
  url: string;
  createdAt: string;
}

export interface SchoolTestResult {
  id: string;
  rollNo: string;
  name: string;
  grade: string;
  marksObtained: number;
  totalMarks: number;
  percentage: number;
  submittedAt: string;
  status: string;
}

export interface SchoolTestResults {
  test: {
    id: string;
    name: string;
    type: string;
    grade: string;
    subject: string;
    totalMarks: number;
  };
  statistics: {
    totalStudents: number;
    averageMarks: number;
    averagePercentage: number;
    topScorers: Array<{
      studentName: string;
      grade: string;
      marksObtained: number;
      percentage: number;
    }>;
  };
  results: SchoolTestResult[];
}

export const getAssignedTests = async (): Promise<{ tests: AssignedTest[]; count: number }> => {
  const response = await api.get('/api/school/tests');
  return response.data;
};

export const getSchoolTestResults = async (testId: string): Promise<SchoolTestResults> => {
  const response = await api.get(`/api/school/test/${testId}/results`);
  return response.data;
};

// Admin API Functions for School Results
export const getSchoolAssignedTests = async (schoolId: string): Promise<{ tests: AssignedTest[]; count: number }> => {
  const response = await api.get(`/api/admin/school/${schoolId}/tests`);
  return response.data;
};

export const getSchoolTestResultsAdmin = async (schoolId: string, testId: string): Promise<SchoolTestResults> => {
  const response = await api.get(`/api/admin/school/${schoolId}/test/${testId}/results`);
  return response.data;
};

// Authentication Functions
export const login = async (email: string, password: string) => {
  const response = await api.post('/api/login', { email, password });
  return response.data;
};

export const logout = () => {
  localStorage.removeItem('auth_token');
  localStorage.removeItem('user_role');
};

// Public Test API Functions (no authentication required)
export interface PublicTest {
  testId: string;
  name: string;
  type: string;
  durationMinutes: number;
  grade: string;
  subject: string;
  questions: Array<{
    qid: string;
    text: string;
    type: 'mcq' | 'subjective';
    options?: string[];
    marks: number;
  }>;
  linkInfo: {
    linkHash: string;
    startTime: string;
    endTime: string;
    schoolName: string;
  };
}

export interface PublicTestSubmission {
  name: string;
  rollNo: string;
  answers: Array<{
    qid: string;
    answerText?: string;
    selectedOptionIndex?: number;
  }>;
}

export interface PublicTestResult {
  resultId: string;
  marksObtained: number;
  totalMarks: number;
  percentage: number;
  message: string;
}

// Create a separate API instance for public routes (no auth)
const publicApi = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000',
  withCredentials: false,
});

export const getPublicTest = async (linkHash: string): Promise<PublicTest> => {
  const response = await publicApi.get(`/public/test/${linkHash}`);
  return response.data;
};

export const submitPublicTest = async (linkHash: string, submission: PublicTestSubmission): Promise<PublicTestResult> => {
  const response = await publicApi.post(`/public/test/${linkHash}/submit`, submission);
  return response.data;
};

export const getPublicTestResult = async (linkHash: string, resultId: string) => {
  const response = await publicApi.get(`/public/test/${linkHash}/result/${resultId}`);
  return response.data;
};

// Mood Analysis API Functions
export interface MoodAnalysisRequest {
  file: File;
}

export interface MoodAnalysisResponse {
  success: boolean;
  analysis?: {
    mood_description: string;
    recommendations: string[];
  };
  image_data?: string;
  error?: string;
}

export interface MoodInfo {
  success: boolean;
  mood_categories: Record<string, string>;
  supported_formats: string[];
  max_file_size: string;
}

// Create a separate API instance for mood analysis (different port)
const moodAnalysisApi = axios.create({
  baseURL: 'http://localhost:5001',
  withCredentials: false,
});

export const analyzeMood = async (file: File): Promise<MoodAnalysisResponse> => {
  const formData = new FormData();
  formData.append('mandala', file);
  
  const response = await moodAnalysisApi.post('/api/mood-analysis', formData, {
    headers: {
      'Content-Type': 'multipart/form-data',
    },
  });
  
  return response.data;
};

export const getMoodInfo = async (): Promise<MoodInfo> => {
  const response = await moodAnalysisApi.get('/api/mood-analysis/info');
  return response.data;
};

export const checkMoodAnalysisHealth = async () => {
  const response = await moodAnalysisApi.get('/api/health');
  return response.data;
};

// Questionnaire Management Functions
export interface QuestionnairePublishRequest {
  questionnaireId: string;
  schoolId: string;
}

export const publishQuestionnaire = async (data: QuestionnairePublishRequest) => {
  const response = await api.post('/api/questionnaire/publish', data);
  return response.data;
};

export default api;


