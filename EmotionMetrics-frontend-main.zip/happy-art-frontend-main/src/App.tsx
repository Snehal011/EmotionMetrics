import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import CreateAccountPage from './components/CreateAccountPage';
import SignInPage from './components/SignInPage';
import PrivateRoute from './components/PrivateRoute';
import AdminPlaceholder from './components/AdminPlaceholder';
import SchoolPlaceholder from './components/SchoolPlaceholder';
import SchoolResultsView from './components/SchoolResultsView';
import PublicTestPage from './components/PublicTestPage';
import AssignedTests from './components/AssignedTests';
import SchoolResults from './components/SchoolResults';

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Navigate to="/login" replace />} />
      <Route path="/signup" element={<CreateAccountPage />} />
      <Route path="/login" element={<SignInPage />} />
      
      {/* Public routes - no authentication required */}
      <Route path="/public/test/:hash" element={<PublicTestPage />} />
      
      {/* Private routes - authentication required */}
      <Route
        path="/admin-dashboard"
        element={
          <PrivateRoute allowedRoles={['admin']}>
            <AdminPlaceholder />
          </PrivateRoute>
        }
      />
      <Route
        path="/school-dashboard"
        element={
          <PrivateRoute allowedRoles={['school']}>
            <SchoolPlaceholder />
          </PrivateRoute>
        }
      />
      <Route
        path="/school-dashboard/assigned-tests"
        element={
          <PrivateRoute allowedRoles={['school']}>
            <AssignedTests />
          </PrivateRoute>
        }
      />
      <Route
        path="/school-dashboard/results"
        element={
          <PrivateRoute allowedRoles={['school']}>
            <SchoolResults />
          </PrivateRoute>
        }
      />
      <Route
        path="/school-dashboard/results/:testId"
        element={
          <PrivateRoute allowedRoles={['school']}>
            <SchoolResultsView />
          </PrivateRoute>
        }
      />
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;