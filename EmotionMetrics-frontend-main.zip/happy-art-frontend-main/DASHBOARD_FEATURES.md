# HappyArt School Dashboard

A comprehensive school dashboard for managing art therapy programs, student questionnaires, and analytics.

## Features

### 🎨 Dashboard Overview
- **Modern UI**: Clean, professional interface with responsive design
- **Real-time Stats**: Live updates on student participation and happiness scores
- **Quick Actions**: Easy access to common tasks
- **Recent Activity**: Track latest activities and updates

### 📊 Pre & Post Test Questionnaire
- **Dual Assessment**: Pre-test and post-test questionnaires on a single page
- **Happiness Tracking**: Monitor student emotional well-being before and after art therapy
- **Visual Analytics**: 
  - Bar charts showing pre-test vs post-test scores
  - Pie charts displaying emotional distribution
  - Individual student performance cards
- **Class Management**: Filter by specific classes or view all students
- **Detailed Analysis**: Click on any student for personalized insights

### 📈 Analytics Dashboard
- **Comprehensive Analysis**: Deep insights into student progress and program effectiveness
- **Multiple View Modes**:
  - **Overview**: Class-wide statistics and trends
  - **Detailed Analysis**: Individual student progress tracking
  - **Comparison**: Pre-test vs post-test comparisons across all students
- **Trend Analysis**: Weekly happiness progression charts
- **Performance Metrics**: Participation rates, session completion, and improvement percentages
- **Top Performers**: Identify students with the highest improvement rates

### 🤖 AI Chatbot Assistant
- **24/7 Support**: Always available help for dashboard navigation
- **Smart Responses**: Context-aware answers about:
  - Student happiness trends and analytics
  - Questionnaire management
  - Art therapy benefits and methods
  - Session scheduling
  - Technical troubleshooting
- **Quick Suggestions**: Pre-defined helpful queries
- **Floating Button**: Easy access from anywhere on the dashboard

## Key Components

### 1. QuestionnairePage.tsx
- Pre-test and post-test questionnaire management
- Real-time happiness score tracking
- Emotional distribution analysis
- Individual student performance cards
- Export functionality for reports

### 2. AnalyticsPage.tsx
- Comprehensive analytics dashboard
- Multiple visualization modes
- Trend analysis and comparisons
- Performance metrics and insights
- Personalized student reports

### 3. Chatbot.tsx
- AI-powered assistant
- Context-aware responses
- Quick suggestion system
- Floating chat interface
- Real-time typing indicators

### 4. SchoolPlaceholder.tsx (Updated)
- Main dashboard container
- Navigation between pages
- Sidebar with page routing
- Chatbot integration
- Responsive design

## API Endpoints

### Dashboard Data
- `GET /api/dashboard/summary` - Dashboard overview statistics
- `GET /api/dashboard/recent` - Recent activities
- `GET /api/dashboard/actions` - Quick action items

### Questionnaire & Analytics
- `GET /api/questionnaire/data` - Questionnaire data for analytics
- `GET /api/analytics/data` - Comprehensive analytics data
- `POST /api/reports/export` - Export reports in various formats

### User Management
- `GET /api/user/profile` - Current user information
- `POST /api/logout` - User logout

## Data Structure

### Student Analytics
```typescript
interface StudentAnalytics {
  id: string;
  name: string;
  grade: string;
  preTestScore: number;
  postTestScore: number;
  happinessImprovement: number;
  emotionalTrend: {
    week1: number;
    week2: number;
    week3: number;
    week4: number;
  };
  participationRate: number;
  artSessionCount: number;
  lastSessionDate: string;
}
```

### Class Analytics
```typescript
interface ClassAnalytics {
  className: string;
  totalStudents: number;
  averagePreTest: number;
  averagePostTest: number;
  averageImprovement: number;
  students: StudentAnalytics[];
  trends: {
    weeklyImprovement: number[];
    participationRate: number;
    sessionCompletion: number;
  };
}
```

## Features Highlights

### 🎯 Pre-Test vs Post-Test Analysis
- **Before Coloring**: Baseline happiness assessment
- **After Coloring**: Post-therapy happiness measurement
- **Improvement Tracking**: Percentage increase in happiness scores
- **Individual Reports**: Personalized improvement statements

### 📊 Visual Analytics
- **Bar Charts**: Pre-test vs post-test score comparisons
- **Pie Charts**: Emotional distribution analysis
- **Trend Lines**: Weekly happiness progression
- **Comparison Graphs**: Class-wide performance metrics

### 🎨 Modern UI Design
- **Professional Look**: Clean, official appearance
- **Responsive Design**: Works on all device sizes
- **Interactive Elements**: Hover effects and smooth transitions
- **Color-coded Data**: Intuitive visual indicators

### 📈 Advanced Analytics
- **Student-specific Delta**: "Your Happiness improved by +22%"
- **Personalized Graphs**: Individual student progress tracking
- **Download Reports**: Export functionality for detailed analysis
- **Real-time Updates**: Live data synchronization

## Usage

1. **Navigate**: Use the sidebar to switch between Dashboard, Questionnaire, and Analytics
2. **View Data**: Click on statistics cards for detailed information
3. **Analyze Students**: Use filters to view specific classes or students
4. **Get Help**: Click the floating chat button for AI assistance
5. **Export Reports**: Use the export buttons to download data

## Technical Stack

- **Frontend**: React, TypeScript, Tailwind CSS
- **Backend**: Node.js, Express.js
- **Icons**: Lucide React
- **Charts**: Custom CSS-based visualizations
- **State Management**: React hooks
- **API**: RESTful endpoints

## Getting Started

1. Install dependencies: `npm install`
2. Start the development server: `npm run dev`
3. Access the dashboard at `http://localhost:3000`
4. Sign in with school credentials
5. Explore the different pages and features

## Future Enhancements

- Real-time data synchronization
- Advanced charting libraries integration
- Mobile app development
- AI-powered insights and recommendations
- Parent portal integration
- Advanced reporting features
