# Admin Dashboard Features

## Overview
The Admin Dashboard provides comprehensive management and analytics for the Mandala Art Therapy program across multiple schools. After admin login, users can access detailed information about schools, students, sessions, and program impact.

## 🏠 Dashboard Overview Page

### Key Metrics Display
- **Total Schools Reached**: Number of schools participating in the program
- **Books Distributed**: Total mandala art books distributed across all schools
- **Children Impacted**: Total number of students who have participated
- **Happiness Improvement**: Aggregate improvement in happiness scores (before vs after art sessions)

### Interactive Features
- **Clickable Cards**: Each metric card has a "View Details" button that opens detailed popup modals
- **Recent Sessions**: List of latest completed sessions with school names, dates, participants, and improvement percentages
- **Real-time Data**: All data is fetched from the backend API and updates automatically

### Detailed Popup Modals
- **Schools List**: Complete list of all schools with student counts and book distribution
- **Books Distribution**: School-wise breakdown of books distributed
- **Children Impact**: Detailed student impact per school
- **Happiness Scores**: Before/after comparison with improvement percentages

## 🏫 School-wise Distribution Page

### School Cards Display
Each school is displayed as an interactive card showing:
- School name and principal information
- Total number of students
- Books distributed count
- Happiness index (improvement percentage)
- Last activity date
- Photo count
- Status (active/inactive)

### Interactive Features
- **View Details Button**: Opens comprehensive school details modal
- **Sessions Button**: Shows recent sessions for that specific school
- **Add New School**: Button to add new schools to the program

### School Details Modal
Comprehensive information including:
- Basic school information (name, principal, contact details)
- Statistics (students, books, photos, sessions)
- Recent sessions with dates, participants, and improvements
- Complete session history

## 📸 Photo Gallery (Memories Section)

### Gallery Features
- **Grid Layout**: Photos displayed in responsive grid (1-4 columns based on screen size)
- **School-wise Organization**: Photos grouped by school with clear labeling
- **Date Information**: Upload dates displayed for each photo
- **Tag System**: Photos can have multiple tags for categorization
- **Upload Functionality**: Button to upload new photos with school selection

### Photo Details Modal
- **Full-size Image Display**: Large view of the selected photo
- **Metadata**: Description, school name, upload date
- **Tag Display**: All associated tags shown as colored badges
- **School Information**: Context about which school the photo belongs to

## 📈 Analytics Page

### Summary Cards
- **Total Schools**: Count of active schools
- **Total Students**: Aggregate student count across all schools
- **Books Distributed**: Total books given out
- **Average Improvement**: Mean happiness improvement percentage

### School Performance Comparison
- **Side-by-side Comparison**: All schools listed with key metrics
- **Performance Indicators**: Students, books, and happiness improvement for each school
- **Visual Hierarchy**: Clear display of top-performing schools

### Detailed Analytics Modal
- **Time Range Selection**: Different time periods (1 month, 3 months, 6 months, 1 year)
- **Happiness Trends**: Historical data showing improvement over time
- **Comprehensive Metrics**: Detailed breakdown of all analytics data

## ⚙️ Admin Panel

### School Management
- **Add New School**: Complete form to register new schools
- **Update Records**: Modify existing school information
- **Status Management**: Activate/deactivate schools

### Session Management
- **Schedule Sessions**: Plan new art therapy sessions
- **Session Data Entry**: Add pre/post session scores
- **Progress Tracking**: Monitor session completion and effectiveness

### Photo Management
- **Upload Photos**: Add new photos with descriptions and tags
- **Tag Management**: Create and assign tags to photos
- **Organization**: Sort and filter photos by school, date, or tags

### Data Import/Export
- **Excel Import**: Upload school records and session data via Excel files
- **Report Generation**: Create comprehensive reports
- **Data Export**: Export data in various formats

### Settings
- **System Configuration**: Adjust dashboard settings
- **User Preferences**: Customize display options
- **Notification Settings**: Configure alerts and updates

## 🔍 Detailed Popup Information

### Every Button Provides Detailed Information
- **Comprehensive Data**: All popups show detailed, accurate information
- **Interactive Elements**: Buttons within modals for further actions
- **Responsive Design**: Modals adapt to different screen sizes
- **Easy Navigation**: Clear close buttons and intuitive navigation

### Modal Types
1. **School Details**: Complete school information and statistics
2. **Photo Details**: Full photo view with metadata
3. **Analytics Details**: Comprehensive analytics breakdown
4. **List Views**: Detailed lists of schools, books, students, etc.
5. **Form Modals**: Add/edit forms for schools, sessions, photos
6. **Report Modals**: Data export and report generation

## 🎨 User Interface Features

### Design Elements
- **Modern UI**: Clean, professional design with Tailwind CSS
- **Color-coded Metrics**: Different colors for different types of data
- **Icons**: Intuitive icons for easy navigation
- **Responsive Layout**: Works on desktop, tablet, and mobile devices

### Navigation
- **Tab-based Navigation**: Easy switching between different sections
- **Breadcrumb Navigation**: Clear indication of current location
- **Quick Actions**: Fast access to common tasks

### Data Visualization
- **Progress Indicators**: Visual representation of improvements
- **Status Badges**: Clear status indicators for schools and sessions
- **Trend Arrows**: Visual indicators for positive/negative trends

## 🔧 Technical Features

### Backend Integration
- **RESTful API**: Complete API integration for all data operations
- **Real-time Updates**: Data refreshes automatically
- **Error Handling**: Graceful error handling with user feedback
- **Loading States**: Visual feedback during data loading

### Data Management
- **Comprehensive Models**: School, Session, Analytics, and Photo models
- **Relationship Mapping**: Proper relationships between schools, sessions, and photos
- **Data Validation**: Server-side validation for all data inputs
- **Security**: Role-based access control for admin functions

### Performance
- **Optimized Queries**: Efficient database queries for fast loading
- **Lazy Loading**: Images and data loaded as needed
- **Caching**: Smart caching for frequently accessed data
- **Pagination**: Large datasets handled efficiently

## 📊 Data Accuracy and Detail

### Comprehensive Data Collection
- **Student Information**: Complete student records with participation history
- **Session Tracking**: Detailed session data with pre/post scores
- **Photo Metadata**: Rich metadata for all photos including tags and descriptions
- **Analytics**: Historical data for trend analysis

### Real-time Updates
- **Live Data**: All information reflects current state
- **Automatic Refresh**: Data updates without manual refresh
- **Change Tracking**: Last activity dates and modification tracking

### Detailed Reporting
- **Granular Metrics**: Detailed breakdowns at school and student level
- **Historical Analysis**: Long-term trend analysis
- **Comparative Data**: School-to-school comparisons
- **Impact Measurement**: Quantified impact of the art therapy program

This admin dashboard provides a complete solution for managing and monitoring the Mandala Art Therapy program across multiple schools, with detailed information available at every level and comprehensive popup modals for deep-dive analysis.
