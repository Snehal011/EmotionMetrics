const mongoose = require('mongoose');
const Test = require('./models/Test');
const TestLink = require('./models/TestLink');
const School = require('./models/School');
require('dotenv').config();

async function createTestData() {
    try {
        // Connect to MongoDB
        const MONGODB_URI = process.env.MONGODB_URI || process.env.MONGO_URI || process.env.MONGODB_URL;
        if (!MONGODB_URI) {
            console.error('MONGODB_URI not found in environment variables');
            process.exit(1);
        }
        
        await mongoose.connect(MONGODB_URI);
        console.log('Connected to MongoDB');

        // Create a test school
        let school = await School.findOne({ email: 'testschool@example.com' });
        if (!school) {
            school = new School({
                name: 'Test School Admin',
                email: 'testschool@example.com',
                role: 'school',
                school_name: 'Test School',
                password: 'school123'
            });
            await school.save();
            console.log('Test school created');
        }

        // Create a test
        let test = await Test.findOne({ name: 'Public Test Example' });
        if (!test) {
            test = new Test({
                name: 'Public Test Example',
                type: 'pre',
                grade: '5',
                subject: 'Mathematics',
                durationMinutes: 30,
                startTime: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours from now
                endTime: new Date(Date.now() + 25 * 60 * 60 * 1000), // 25 hours from now
                questions: [
                    {
                        qid: 'q1',
                        text: 'What is 2 + 2?',
                        type: 'mcq',
                        options: ['3', '4', '5', '6'],
                        correctOption: '4',
                        marks: 5
                    },
                    {
                        qid: 'q2',
                        text: 'Explain addition',
                        type: 'subjective',
                        marks: 10
                    }
                ],
                createdBy: '507f1f77bcf86cd799439011', // Use existing admin ID
                status: 'active'
            });
            await test.save();
            console.log('Test created');
        }

        // Create a test link
        let testLink = await TestLink.findOne({ test: test._id, school: school._id });
        if (!testLink) {
            testLink = new TestLink({
                test: test._id,
                school: school._id,
                grade: '5',
                linkHash: 'a1b2c3d4',
                url: '/public/test/a1b2c3d4',
                status: 'active',
                startTime: test.startTime,
                endTime: test.endTime
            });
            await testLink.save();
            console.log('Test link created');
        }

        console.log('\n=== Test Data Created ===');
        console.log('Test Link Hash:', testLink.linkHash);
        console.log('Test URL:', `http://localhost:5000/public/test/${testLink.linkHash}`);
        console.log('Test Name:', test.name);
        console.log('School:', school.school_name);
        console.log('Start Time:', testLink.startTime);
        console.log('End Time:', testLink.endTime);
        console.log('\nYou can now test the public route with this link hash!');

        await mongoose.connection.close();
        console.log('Disconnected from MongoDB');
    } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
    }
}

createTestData();

