const mongoose = require('mongoose');
require('dotenv').config();

const TestLink = require('./models/TestLink');

async function checkTestLinks() {
    try {
        await mongoose.connect(process.env.MONGODB_URI || process.env.MONGO_URI || process.env.MONGODB_URL);
        console.log('Connected to MongoDB');

        // Get all test links
        const testLinks = await TestLink.find({})
            .populate('test', 'name startTime endTime status')
            .populate('school', 'school_name')
            .sort({ createdAt: -1 });

        console.log(`\n=== Found ${testLinks.length} Test Links ===\n`);

        const now = new Date();
        console.log('Current Time:', now.toISOString());
        console.log('Current Time Local:', now.toString());
        console.log('');

        testLinks.forEach((link, index) => {
            const isActive = link.status === 'active';
            const isTimeValid = now >= link.startTime && now <= link.endTime;
            const isFullyActive = isActive && isTimeValid;

            console.log(`Test Link ${index + 1}:`);
            console.log(`  Hash: ${link.linkHash}`);
            console.log(`  URL: http://localhost:5174/public/test/${link.linkHash}`);
            console.log(`  Test Name: ${link.test?.name || 'N/A'}`);
            console.log(`  School: ${link.school?.school_name || 'N/A'}`);
            console.log(`  Status: ${link.status}`);
            console.log(`  Start Time: ${link.startTime.toISOString()}`);
            console.log(`  End Time: ${link.endTime.toISOString()}`);
            console.log(`  Test Start: ${link.test?.startTime?.toISOString() || 'N/A'}`);
            console.log(`  Test End: ${link.test?.endTime?.toISOString() || 'N/A'}`);
            console.log(`  Test Status: ${link.test?.status || 'N/A'}`);
            console.log(`  Is Time Valid: ${isTimeValid}`);
            console.log(`  Is Fully Active: ${isFullyActive}`);
            
            if (!isTimeValid) {
                if (now < link.startTime) {
                    const diff = link.startTime.getTime() - now.getTime();
                    const hours = Math.floor(diff / (1000 * 60 * 60));
                    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                    console.log(`  ⚠️  Test starts in ${hours}h ${minutes}m`);
                } else if (now > link.endTime) {
                    const diff = now.getTime() - link.endTime.getTime();
                    const hours = Math.floor(diff / (1000 * 60 * 60));
                    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                    console.log(`  ❌ Test expired ${hours}h ${minutes}m ago`);
                }
            }
            console.log('  ' + '-'.repeat(50));
        });

        await mongoose.disconnect();
        console.log('\nDisconnected from MongoDB');
    } catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}

checkTestLinks();
