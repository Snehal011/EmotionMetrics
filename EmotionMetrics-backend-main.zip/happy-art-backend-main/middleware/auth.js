const jwt = require('jsonwebtoken');

function verifyToken(req, res, next) {
	try {
		const authHeader = req.headers && req.headers.authorization;
		if (!authHeader || typeof authHeader !== 'string') {
			return res.status(401).json({ message: 'Unauthorized' });
		}

		const parts = authHeader.split(' ');
		if (parts.length !== 2 || parts[0] !== 'Bearer') {
			return res.status(401).json({ message: 'Unauthorized' });
		}

		const token = parts[1];
		const jwtSecret = process.env.JWT_SECRET;
		if (!jwtSecret) {
			return res.status(500).json({ message: 'JWT secret not configured' });
		}

		const decoded = jwt.verify(token, jwtSecret);
		req.user = decoded;
		return next();
	} catch (error) {
		return res.status(401).json({ message: 'Unauthorized' });
	}
}

function requireRole(role) {
	return function (req, res, next) {
		if (req.user && req.user.role === role) {
			return next();
		}
		return res.status(403).json({ message: 'Access denied' });
	};
}

module.exports = { verifyToken, requireRole };


