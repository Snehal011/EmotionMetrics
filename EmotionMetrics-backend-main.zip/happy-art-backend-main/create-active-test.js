const mongoose = require('mongoose');
require('dotenv').config();

const Test = require('./models/Test');
const TestLink = require('./models/TestLink');
const School = require('./models/School');

async function createActiveTest() {
    try {
        await mongoose.connect(process.env.MONGODB_URI || process.env.MONGO_URI || process.env.MONGODB_URL);
        console.log('Connected to MongoDB');

        // Find or create a school
        let school = await School.findOne({ school_name: 'Test School' });
        if (!school) {
            school = new School({
                school_name: 'Test School',
                email: 'test@school.com',
                password: 'hashedpassword',
                role: 'school'
            });
            await school.save();
            console.log('Test school created');
        }

        // Create times for an active test (30 minutes ago to 30 minutes from now)
        const startTime = new Date(Date.now() - 30 * 60 * 1000); // 30 minutes ago
        const endTime = new Date(Date.now() + 30 * 60 * 1000);   // 30 minutes from now

        // Create an active test
        let test = await Test.findOne({ name: 'Active Test for Demo' });
        if (!test) {
            test = new Test({
                name: 'Active Test for Demo',
                type: 'pre',
                grade: '5',
                subject: 'Mathematics',
                durationMinutes: 60,
                startTime: startTime,
                endTime: endTime,
                questions: [
                    {
                        qid: 'active_demo_q1',
                        text: 'What is 5 + 3?',
                        type: 'mcq',
                        options: ['6', '7', '8', '9'],
                        correctOption: '8',
                        marks: 5
                    },
                    {
                        qid: 'active_demo_q2',
                        text: 'What is the capital of India?',
                        type: 'mcq',
                        options: ['Mumbai', 'Delhi', 'Bangalore', 'Kolkata'],
                        correctOption: 'Delhi',
                        marks: 5
                    },
                    {
                        qid: 'active_demo_q3',
                        text: 'Explain what you learned in this test.',
                        type: 'subjective',
                        marks: 10
                    }
                ],
                createdBy: '507f1f77bcf86cd799439011', // Use existing admin ID
                status: 'active'
            });
            await test.save();
            console.log('Active test created');
        }

        // Create an active test link
        let testLink = await TestLink.findOne({ linkHash: 'active123' });
        if (!testLink) {
            testLink = new TestLink({
                test: test._id,
                school: school._id,
                grade: '5',
                linkHash: 'active123',
                url: '/public/test/active123',
                status: 'active',
                startTime: startTime,
                endTime: endTime
            });
            await testLink.save();
            console.log('Active test link created');
        }

        console.log('\n=== Active Test Created ===');
        console.log('Test Link Hash: active123');
        console.log('Test URL: http://localhost:5173/public/test/active123');
        console.log('Test Name:', test.name);
        console.log('School:', school.school_name);
        console.log('Start Time:', testLink.startTime);
        console.log('End Time:', testLink.endTime);
        console.log('Current Time:', new Date());
        console.log('Is Active:', new Date() >= testLink.startTime && new Date() <= testLink.endTime);

        await mongoose.disconnect();
        console.log('Disconnected from MongoDB');
    } catch (error) {
        console.error('Error:', error);
        process.exit(1);
    }
}

createActiveTest();
