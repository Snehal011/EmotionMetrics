const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const { startCron, stopCron } = require('./cron/expireJobs');
require('dotenv').config();

const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI || process.env.MONGO_URI || process.env.MONGODB_URL;

const app = express();

// Middleware
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || 'http://localhost:5173';
app.use(
    cors({
        origin: FRONTEND_ORIGIN,
        credentials: true,
    })
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
const accountRouter = require('./routes/account');
const authRouter = require('./routes/auth');
const dashboardRouter = require('./routes/dashboard');
const adminRouter = require('./routes/admin');
const schoolRouter = require('./routes/school');
const publicRouter = require('./routes/public');

// Health route (no authentication required)
app.get('/health', (req, res) => {
	res.json({ ok: true });
});

// Apply public routes (no authentication required)
app.use('/public', publicRouter);

// Apply authenticated routes
app.use(accountRouter);
app.use(authRouter);
app.use(dashboardRouter);
app.use('/api/admin', adminRouter);
app.use('/api/school', schoolRouter);

// Connect to MongoDB via Mongoose and start server
async function start() {
	if (!MONGODB_URI) {
		throw new Error('Missing MONGODB_URI in environment');
	}
	await mongoose.connect(MONGODB_URI);
	console.log('Connected to MongoDB (Mongoose)');
	return app.listen(PORT, () => {
		console.log(`Server listening on http://localhost:${PORT}`);
	});
}

let httpServer;
let cronJob;
start()
	.then((serverInstance) => {
		httpServer = serverInstance;
		// Start cron job after successful database connection
		cronJob = startCron();
	})
	.catch((error) => {
		console.error('Failed to start server:', error.message);
		process.exitCode = 1;
	});

process.on('SIGINT', async () => {
	try {
		// Stop cron job
		if (cronJob) {
			stopCron(cronJob);
		}
		await mongoose.connection.close();
		if (httpServer) {
			httpServer.close();
		}
		console.log('Graceful shutdown complete');
	} finally {
		process.exit(0);
	}
});

module.exports = app;


