const mongoose = require('mongoose');
const Test = require('./models/Test');
const TestLink = require('./models/TestLink');
const School = require('./models/School');
const { runExpireJobOnce } = require('./cron/expireJobs');
require('dotenv').config();

async function testCronJob() {
    try {
        // Connect to MongoDB
        const MONGODB_URI = process.env.MONGODB_URI || process.env.MONGO_URI || process.env.MONGODB_URL;
        if (!MONGODB_URI) {
            console.error('MONGODB_URI not found in environment variables');
            process.exit(1);
        }
        
        await mongoose.connect(MONGODB_URI);
        console.log('Connected to MongoDB');

        // Find or create test school
        let school = await School.findOne({ email: 'testschool@example.com' });
        if (!school) {
            school = new School({
                name: 'Test School Admin',
                email: 'testschool@example.com',
                role: 'school',
                school_name: 'Test School',
                password: 'school123'
            });
            await school.save();
            console.log('Test school created');
        }

        // Create test data with past end time (should be expired)
        const pastTime = new Date(Date.now() - 60 * 60 * 1000); // 1 hour ago
        const futureTime = new Date(Date.now() + 60 * 60 * 1000); // 1 hour from now

        console.log('\n=== Creating Test Data ===');
        console.log('Past time (should expire):', pastTime.toISOString());
        console.log('Future time (should not expire):', futureTime.toISOString());

        // Create expired test
        let expiredTest = await Test.findOne({ name: 'Expired Test Example' });
        if (!expiredTest) {
            expiredTest = new Test({
                name: 'Expired Test Example',
                type: 'pre',
                grade: '5',
                subject: 'Mathematics',
                durationMinutes: 30,
                startTime: new Date(pastTime.getTime() - 60 * 60 * 1000), // 2 hours ago
                endTime: pastTime, // 1 hour ago (expired)
                questions: [
                    {
                        qid: 'expired_q1',
                        text: 'What is 2 + 2?',
                        type: 'mcq',
                        options: ['3', '4', '5', '6'],
                        correctOption: '4',
                        marks: 5
                    }
                ],
                createdBy: '507f1f77bcf86cd799439011',
                status: 'active' // Should be changed to 'expired'
            });
            await expiredTest.save();
            console.log('Expired test created with status:', expiredTest.status);
        }

        // Create active test (should not expire)
        let activeTest = await Test.findOne({ name: 'Active Test Example' });
        if (!activeTest) {
            activeTest = new Test({
                name: 'Active Test Example',
                type: 'post',
                grade: '6',
                subject: 'Science',
                durationMinutes: 45,
                startTime: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
                endTime: futureTime, // 1 hour from now (not expired)
                questions: [
                    {
                        qid: 'active_q1',
                        text: 'What is photosynthesis?',
                        type: 'subjective',
                        marks: 10
                    }
                ],
                createdBy: '507f1f77bcf86cd799439011',
                status: 'active' // Should remain 'active'
            });
            await activeTest.save();
            console.log('Active test created with status:', activeTest.status);
        }

        // Create expired test link
        let expiredTestLink = await TestLink.findOne({ linkHash: 'expired1' });
        if (!expiredTestLink) {
            expiredTestLink = new TestLink({
                test: expiredTest._id,
                school: school._id,
                grade: '5',
                linkHash: 'expired1',
                url: '/public/test/expired1',
                status: 'active', // Should be changed to 'expired'
                startTime: new Date(pastTime.getTime() - 60 * 60 * 1000),
                endTime: pastTime // 1 hour ago (expired)
            });
            await expiredTestLink.save();
            console.log('Expired test link created with status:', expiredTestLink.status);
        }

        // Create active test link
        let activeTestLink = await TestLink.findOne({ linkHash: 'active1' });
        if (!activeTestLink) {
            activeTestLink = new TestLink({
                test: activeTest._id,
                school: school._id,
                grade: '6',
                linkHash: 'active1',
                url: '/public/test/active1',
                status: 'active', // Should remain 'active'
                startTime: new Date(Date.now() - 30 * 60 * 1000),
                endTime: futureTime // 1 hour from now (not expired)
            });
            await activeTestLink.save();
            console.log('Active test link created with status:', activeTestLink.status);
        }

        console.log('\n=== Before Cron Job ===');
        console.log('Expired test status:', expiredTest.status);
        console.log('Active test status:', activeTest.status);
        console.log('Expired test link status:', expiredTestLink.status);
        console.log('Active test link status:', activeTestLink.status);

        // Run the cron job once manually
        console.log('\n=== Running Cron Job ===');
        await runExpireJobOnce();

        // Check status after cron job
        console.log('\n=== After Cron Job ===');
        const updatedExpiredTest = await Test.findById(expiredTest._id);
        const updatedActiveTest = await Test.findById(activeTest._id);
        const updatedExpiredTestLink = await TestLink.findById(expiredTestLink._id);
        const updatedActiveTestLink = await TestLink.findById(activeTestLink._id);

        console.log('Expired test status:', updatedExpiredTest.status);
        console.log('Active test status:', updatedActiveTest.status);
        console.log('Expired test link status:', updatedExpiredTestLink.status);
        console.log('Active test link status:', updatedActiveTestLink.status);

        // Verify results
        console.log('\n=== Verification ===');
        if (updatedExpiredTest.status === 'expired') {
            console.log('✅ Expired test correctly marked as expired');
        } else {
            console.log('❌ Expired test was not marked as expired');
        }

        if (updatedActiveTest.status === 'active') {
            console.log('✅ Active test correctly remained active');
        } else {
            console.log('❌ Active test was incorrectly changed');
        }

        if (updatedExpiredTestLink.status === 'expired') {
            console.log('✅ Expired test link correctly marked as expired');
        } else {
            console.log('❌ Expired test link was not marked as expired');
        }

        if (updatedActiveTestLink.status === 'active') {
            console.log('✅ Active test link correctly remained active');
        } else {
            console.log('❌ Active test link was incorrectly changed');
        }

        await mongoose.connection.close();
        console.log('\nDisconnected from MongoDB');
    } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
    }
}

testCronJob();

