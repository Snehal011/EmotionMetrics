const cron = require('node-cron');
const Test = require('../models/Test');
const TestLink = require('../models/TestLink');

// Function to expire tests and test links
const expireTestsAndLinks = async () => {
	try {
		const now = new Date();
		console.log(`[CRON] Running expire job at ${now.toISOString()}`);

		// 1. Find and expire Test documents with endTime < now and status != 'expired'
		const expiredTests = await Test.updateMany(
			{
				endTime: { $lt: now },
				status: { $ne: 'expired' }
			},
			{
				$set: { status: 'expired' }
			}
		);

		// 2. Find and expire TestLink documents with endTime < now and status != 'expired'
		const expiredTestLinks = await TestLink.updateMany(
			{
				endTime: { $lt: now },
				status: { $ne: 'expired' }
			},
			{
				$set: { status: 'expired' }
			}
		);

		// 3. Log summary of expired tests and links
		if (expiredTests.modifiedCount > 0 || expiredTestLinks.modifiedCount > 0) {
			console.log(`[CRON] Expiration Summary:`);
			console.log(`  - Tests expired: ${expiredTests.modifiedCount}`);
			console.log(`  - Test links expired: ${expiredTestLinks.modifiedCount}`);
			console.log(`  - Total expired: ${expiredTests.modifiedCount + expiredTestLinks.modifiedCount}`);
		} else {
			console.log(`[CRON] No tests or links expired at ${now.toISOString()}`);
		}

		// Optional: Get details of expired items for logging
		if (expiredTests.modifiedCount > 0) {
			const expiredTestDetails = await Test.find({
				endTime: { $lt: now },
				status: 'expired'
			}).select('name type grade subject endTime').limit(5);

			console.log(`[CRON] Recently expired tests:`);
			expiredTestDetails.forEach(test => {
				console.log(`  - ${test.name} (${test.type}, Grade ${test.grade}, ${test.subject}) - Ended: ${test.endTime.toISOString()}`);
			});
		}

		if (expiredTestLinks.modifiedCount > 0) {
			const expiredLinkDetails = await TestLink.find({
				endTime: { $lt: now },
				status: 'expired'
			}).populate('test', 'name type grade subject').populate('school', 'school_name').limit(5);

			console.log(`[CRON] Recently expired test links:`);
			expiredLinkDetails.forEach(link => {
				console.log(`  - ${link.test?.name || 'Unknown Test'} (${link.test?.type || 'Unknown'}, Grade ${link.grade}) - School: ${link.school?.school_name || 'Unknown'} - Ended: ${link.endTime.toISOString()}`);
			});
		}

	} catch (error) {
		console.error('[CRON] Error in expire job:', error.message);
		console.error('[CRON] Stack trace:', error.stack);
	}
};

// Function to start the cron job
const startCron = () => {
	console.log('[CRON] Starting expire jobs cron...');
	
	// Run every minute: '* * * * *'
	const job = cron.schedule('* * * * *', async () => {
		await expireTestsAndLinks();
	}, {
		scheduled: false, // Don't start immediately
		timezone: 'UTC'
	});

	// Start the job
	job.start();
	console.log('[CRON] Expire jobs cron started - will run every minute');

	// Return the job instance for potential cleanup
	return job;
};

// Function to stop the cron job
const stopCron = (job) => {
	if (job) {
		job.stop();
		console.log('[CRON] Expire jobs cron stopped');
	}
};

// Function to run the expire job once manually (for testing)
const runExpireJobOnce = async () => {
	console.log('[CRON] Running expire job once manually...');
	await expireTestsAndLinks();
};

module.exports = {
	startCron,
	stopCron,
	runExpireJobOnce,
	expireTestsAndLinks
};

