const mongoose = require('mongoose');
const Test = require('./models/Test');
const TestLink = require('./models/TestLink');
const StudentResult = require('./models/StudentResult');
const School = require('./models/School');
require('dotenv').config();

async function testResultViewing() {
    try {
        // Connect to MongoDB
        const MONGODB_URI = process.env.MONGODB_URI || process.env.MONGO_URI || process.env.MONGODB_URL;
        if (!MONGODB_URI) {
            console.error('MONGODB_URI not found in environment variables');
            process.exit(1);
        }
        
        await mongoose.connect(MONGODB_URI);
        console.log('Connected to MongoDB');

        // Find the test link and result we created earlier
        const testLink = await TestLink.findOne({ linkHash: 'a1b2c3d4' })
            .populate('test')
            .populate('school');

        if (!testLink) {
            console.log('Test link not found. Please run test-public-route.js first.');
            process.exit(1);
        }

        console.log('Found test link:', testLink.linkHash);
        console.log('Test:', testLink.test.name);

        // Find the student result
        const studentResult = await StudentResult.findOne({ 
            testLinkId: testLink._id,
            studentId: 'STU001'
        }).populate('schoolId', 'school_name');

        if (!studentResult) {
            console.log('Student result not found. Please run test-submit-route.js first.');
            process.exit(1);
        }

        console.log('\n=== Found Student Result ===');
        console.log('Result ID:', studentResult._id);
        console.log('Student Name:', studentResult.studentName);
        console.log('Roll Number:', studentResult.studentId);
        console.log('Marks Obtained:', studentResult.marksObtained);
        console.log('Total Marks:', studentResult.totalMarks);
        console.log('Percentage:', studentResult.percentage + '%');

        // Simulate the result viewing process
        console.log('\n=== Simulating Result Viewing Process ===');
        
        // Check link validation (simulating the controller logic)
        const now = new Date();
        const isLinkValid = testLink.status === 'active' && 
                           now >= testLink.startTime && 
                           now <= testLink.endTime;

        console.log('Link Status:', testLink.status);
        console.log('Current Time:', now);
        console.log('Start Time:', testLink.startTime);
        console.log('End Time:', testLink.endTime);
        console.log('Is Link Valid:', isLinkValid);

        if (isLinkValid) {
            console.log('\n✅ Link is valid. Proceeding with result retrieval...');
            
            // Simulate the response data
            const responseData = {
                resultId: studentResult._id,
                studentName: studentResult.studentName,
                rollNo: studentResult.studentId,
                grade: studentResult.grade,
                schoolName: studentResult.schoolId?.school_name,
                testInfo: {
                    testId: testLink.test._id,
                    testName: testLink.test.name,
                    testType: testLink.test.type,
                    subject: testLink.test.subject,
                },
                marksObtained: studentResult.marksObtained,
                totalMarks: studentResult.totalMarks,
                percentage: studentResult.percentage,
                submittedAt: studentResult.submittedAt,
                answers: studentResult.answers.map(answer => ({
                    qid: answer.qid,
                    answer: answer.answer,
                    marksObtained: answer.marksObtained,
                    isCorrect: answer.isCorrect,
                })),
            };

            console.log('\n=== Result Data (as would be returned by API) ===');
            console.log(JSON.stringify(responseData, null, 2));

            console.log('\n=== Per-Question Breakdown ===');
            responseData.answers.forEach((answer, index) => {
                console.log(`${index + 1}. Question ID: ${answer.qid}`);
                console.log(`   Answer: ${answer.answer}`);
                console.log(`   Marks Obtained: ${answer.marksObtained}`);
                console.log(`   Correct: ${answer.isCorrect ? 'Yes' : 'No'}`);
                console.log('');
            });

        } else {
            console.log('❌ Link is invalid or expired. Result access would be denied.');
        }

        // Test URL construction
        const resultUrl = `http://localhost:5000/public/test/${testLink.linkHash}/result/${studentResult._id}`;
        console.log('\n=== Test URL ===');
        console.log('GET', resultUrl);

        await mongoose.connection.close();
        console.log('\nDisconnected from MongoDB');
    } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
    }
}

testResultViewing();

