const mongoose = require('mongoose');
const Test = require('./models/Test');
const TestLink = require('./models/TestLink');
const StudentResult = require('./models/StudentResult');
const School = require('./models/School');
require('dotenv').config();

async function testSubmitFunctionality() {
    try {
        // Connect to MongoDB
        const MONGODB_URI = process.env.MONGODB_URI || process.env.MONGO_URI || process.env.MONGODB_URL;
        if (!MONGODB_URI) {
            console.error('MONGODB_URI not found in environment variables');
            process.exit(1);
        }
        
        await mongoose.connect(MONGODB_URI);
        console.log('Connected to MongoDB');

        // Find the test link we created earlier
        const testLink = await TestLink.findOne({ linkHash: 'a1b2c3d4' })
            .populate('test')
            .populate('school');

        if (!testLink) {
            console.log('Test link not found. Please run test-public-route.js first.');
            process.exit(1);
        }

        console.log('Found test link:', testLink.linkHash);
        console.log('Test:', testLink.test.name);
        console.log('School:', testLink.school.school_name);

        // Check if there are any existing results
        const existingResults = await StudentResult.find({ testId: testLink.test._id });
        console.log(`\nExisting results for this test: ${existingResults.length}`);

        // Create sample test submission data
        const sampleSubmission = {
            name: "John Doe",
            rollNo: "STU001",
            answers: [
                {
                    qid: "q1",
                    selectedOptionIndex: 1, // This should be correct (index 1 = "4")
                    answerText: ""
                },
                {
                    qid: "q2",
                    selectedOptionIndex: undefined,
                    answerText: "Addition is the process of combining two or more numbers to get a total."
                }
            ]
        };

        console.log('\n=== Sample Test Submission ===');
        console.log('Student Name:', sampleSubmission.name);
        console.log('Roll Number:', sampleSubmission.rollNo);
        console.log('Answers:', JSON.stringify(sampleSubmission.answers, null, 2));

        // Simulate the submission process
        console.log('\n=== Simulating Submission Process ===');
        
        // Check if student already submitted
        const existingResult = await StudentResult.findOne({
            testId: testLink.test._id,
            studentId: sampleSubmission.rollNo,
        });

        if (existingResult) {
            console.log('Student has already submitted this test.');
            console.log('Previous result:', {
                marksObtained: existingResult.marksObtained,
                totalMarks: existingResult.totalMarks,
                percentage: existingResult.percentage
            });
        } else {
            console.log('Student has not submitted yet. Proceeding with submission...');
            
            // Calculate marks (simulating the controller logic)
            let totalMarksObtained = 0;
            const processedAnswers = sampleSubmission.answers.map(answer => {
                const question = testLink.test.questions.find(q => q.qid === answer.qid);
                if (!question) {
                    return {
                        qid: answer.qid,
                        answer: answer.answerText || '',
                        marksObtained: 0,
                        isCorrect: false,
                    };
                }

                let marksObtained = 0;
                let isCorrect = false;

                if (question.type === 'mcq') {
                    const selectedOption = question.options[answer.selectedOptionIndex];
                    if (selectedOption === question.correctOption) {
                        marksObtained = question.marks;
                        isCorrect = true;
                    }
                } else if (question.type === 'subjective') {
                    marksObtained = question.marks;
                    isCorrect = true;
                }

                totalMarksObtained += marksObtained;

                return {
                    qid: answer.qid,
                    answer: answer.answerText || (answer.selectedOptionIndex !== undefined ? question.options[answer.selectedOptionIndex] : ''),
                    marksObtained,
                    isCorrect,
                };
            });

            const totalMarks = testLink.test.questions.reduce((sum, question) => sum + question.marks, 0);
            const percentage = Math.round((totalMarksObtained / totalMarks) * 100 * 100) / 100;

            console.log('\n=== Calculated Results ===');
            console.log('Total Marks Obtained:', totalMarksObtained);
            console.log('Total Marks Available:', totalMarks);
            console.log('Percentage:', percentage + '%');
            console.log('Processed Answers:', JSON.stringify(processedAnswers, null, 2));

            // Create the student result
            const studentResult = new StudentResult({
                testId: testLink.test._id,
                testLinkId: testLink._id,
                studentId: sampleSubmission.rollNo,
                studentName: sampleSubmission.name,
                grade: testLink.test.grade,
                schoolId: testLink.school._id,
                answers: processedAnswers,
                totalMarks,
                marksObtained: totalMarksObtained,
                submittedAt: new Date(),
                status: 'submitted',
            });

            await studentResult.save();
            console.log('\n✅ Student result saved successfully!');
            console.log('Result ID:', studentResult._id);
        }

        // Show all results for this test
        const allResults = await StudentResult.find({ testId: testLink.test._id })
            .populate('schoolId', 'school_name');
        
        console.log('\n=== All Results for This Test ===');
        allResults.forEach((result, index) => {
            console.log(`${index + 1}. ${result.studentName} (${result.studentId})`);
            console.log(`   Marks: ${result.marksObtained}/${result.totalMarks} (${result.percentage}%)`);
            console.log(`   School: ${result.schoolId.school_name}`);
            console.log(`   Submitted: ${result.submittedAt}`);
        });

        await mongoose.connection.close();
        console.log('\nDisconnected from MongoDB');
    } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
    }
}

testSubmitFunctionality();

