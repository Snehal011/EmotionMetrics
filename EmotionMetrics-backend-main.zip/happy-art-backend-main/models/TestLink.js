const mongoose = require('mongoose');
const { v4: uuidv4 } = require('uuid');

const { Schema } = mongoose;

const TestLinkSchema = new Schema(
	{
		test: {
			type: Schema.Types.ObjectId,
			ref: 'Test',
			required: [true, 'Test reference is required'],
		},
		school: {
			type: Schema.Types.ObjectId,
			ref: 'School',
			required: [true, 'School reference is required'],
		},
		grade: {
			type: String,
			required: [true, 'Grade is required'],
			trim: true,
		},
		linkHash: {
			type: String,
			required: [true, 'Link hash is required'],
			unique: true,
			default: () => uuidv4().replace(/-/g, ''), // Remove hyphens to get hex string
		},
		url: {
			type: String,
			required: [true, 'URL is required'],
			trim: true,
		},
		status: {
			type: String,
			enum: ['active', 'expired', 'disabled'],
			default: 'active',
		},
		startTime: {
			type: Date,
			required: [true, 'Start time is required'],
		},
		endTime: {
			type: Date,
			required: [true, 'End time is required'],
		},
	},
	{ timestamps: true }
);

// Index already defined in field definition with unique: true

// Compound index for efficient queries
TestLinkSchema.index({ school: 1, test: 1 });
TestLinkSchema.index({ status: 1, endTime: 1 });

module.exports = mongoose.models.TestLink || mongoose.model('TestLink', TestLinkSchema);

