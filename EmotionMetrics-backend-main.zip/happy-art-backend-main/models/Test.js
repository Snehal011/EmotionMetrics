const mongoose = require('mongoose');

const { Schema } = mongoose;

const QuestionSchema = new Schema({
	qid: {
		type: String,
		required: true,
		unique: true,
	},
	text: {
		type: String,
		required: [true, 'Question text is required'],
		trim: true,
	},
	type: {
		type: String,
		required: [true, 'Question type is required'],
		enum: ['mcq', 'subjective'],
	},
	options: [{
		type: String,
		trim: true,
	}],
	correctOption: {
		type: String,
		trim: true,
	},
	marks: {
		type: Number,
		required: [true, 'Marks are required'],
		min: [1, 'Marks must be at least 1'],
	},
}, { _id: false });

const TestSchema = new Schema(
	{
		name: {
			type: String,
			required: [true, 'Test name is required'],
			trim: true,
		},
		type: {
			type: String,
			required: [true, 'Test type is required'],
			enum: ['pre', 'post'],
		},
		grade: {
			type: String,
			required: [true, 'Grade is required'],
			trim: true,
		},
		subject: {
			type: String,
			required: [true, 'Subject is required'],
			trim: true,
		},
		durationMinutes: {
			type: Number,
			required: [true, 'Duration is required'],
			min: [1, 'Duration must be at least 1 minute'],
		},
		startTime: {
			type: Date,
			required: [true, 'Start time is required'],
		},
		endTime: {
			type: Date,
			required: [true, 'End time is required'],
		},
		questions: [QuestionSchema],
		status: {
			type: String,
			enum: ['draft', 'active', 'expired', 'completed'],
			default: 'draft',
		},
		createdBy: {
			type: Schema.Types.ObjectId,
			ref: 'Admin',
			required: true,
		},
		totalMarks: {
			type: Number,
			default: 0,
		},
		assignedSchools: [{
			type: Schema.Types.ObjectId,
			ref: 'School',
		}],
		schoolNames: [{
			type: String,
			trim: true,
		}],
	},
	{ timestamps: true }
);

// Calculate total marks before saving
TestSchema.pre('save', function (next) {
	if (this.questions && this.questions.length > 0) {
		this.totalMarks = this.questions.reduce((total, question) => total + question.marks, 0);
	}
	next();
});

// Validate that endTime is after startTime
TestSchema.pre('save', function (next) {
	if (this.endTime <= this.startTime) {
		return next(new Error('End time must be after start time'));
	}
	next();
});

// Indexes for efficient queries
TestSchema.index({ createdBy: 1, status: 1 });
TestSchema.index({ type: 1, grade: 1 });
TestSchema.index({ startTime: 1, endTime: 1 });

module.exports = mongoose.models.Test || mongoose.model('Test', TestSchema);

