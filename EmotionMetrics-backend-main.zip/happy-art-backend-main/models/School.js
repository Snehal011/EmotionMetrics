const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const { Schema } = mongoose;

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const SchoolSchema = new Schema(
	{
		name: {
			type: String,
			required: [true, 'Name is required'],
			trim: true,
		},
		email: {
			type: String,
			required: [true, 'Email is required'],
			unique: true,
			lowercase: true,
			trim: true,
			validate: {
				validator: (value) => emailRegex.test(value),
				message: 'Invalid email address',
			},
		},
		role: {
			type: String,
			required: true,
			enum: ['school'],
			default: 'school',
			lowercase: true,
			trim: true,
		},
		school_name: {
			type: String,
			required: [true, 'School name is required'],
			trim: true,
		},
        password: {
            type: String,
            required: [true, 'Password is required'],
            minlength: [6, 'Password must be at least 6 characters'],
            trim: true,
        },
		// Additional fields for comprehensive data
		address: {
			type: String,
			trim: true,
		},
		phone: {
			type: String,
			trim: true,
		},
		principal_name: {
			type: String,
			trim: true,
		},
		total_students: {
			type: Number,
			default: 0,
		},
		books_distributed: {
			type: Number,
			default: 0,
		},
		last_activity: {
			type: Date,
			default: Date.now,
		},
		happiness_scores: {
			before_art: {
				type: Number,
				default: 0,
			},
			after_art: {
				type: Number,
				default: 0,
			},
			average_improvement: {
				type: Number,
				default: 0,
			},
		},
		photos: [{
			url: String,
			uploaded_at: {
				type: Date,
				default: Date.now,
			},
			tags: [String],
			description: String,
		}],
		sessions: [{
			session_date: Date,
			participants: Number,
			pre_session_scores: [Number],
			post_session_scores: [Number],
			photos: [String],
			notes: String,
		}],
		status: {
			type: String,
			enum: ['active', 'inactive', 'pending'],
			default: 'active',
		},
	},
	{ timestamps: true }
);

// Hash password before saving
SchoolSchema.pre('save', async function (next) {
	try {
		if (!this.isModified('password')) return next();
		const salt = await bcrypt.genSalt(10);
		this.password = await bcrypt.hash(this.password, salt);
		return next();
	} catch (error) {
		return next(error);
	}
});

// Index already defined in field definition with unique: true

module.exports = mongoose.models.School || mongoose.model('School', SchoolSchema);


