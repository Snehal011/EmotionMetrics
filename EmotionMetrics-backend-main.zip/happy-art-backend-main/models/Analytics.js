const mongoose = require('mongoose');

const { Schema } = mongoose;

const AnalyticsSchema = new Schema(
	{
		school_id: {
			type: Schema.Types.ObjectId,
			ref: 'School',
			required: true,
		},
		date: {
			type: Date,
			required: true,
		},
		metrics: {
			total_students: Number,
			books_distributed: Number,
			average_happiness_before: Number,
			average_happiness_after: Number,
			improvement_percentage: Number,
			sessions_conducted: Number,
			photos_uploaded: Number,
			emotional_transitions: [{
				emotion: String,
				count: Number,
				percentage: Number,
			}],
		},
		weekly_trends: {
			week_start: Date,
			week_end: Date,
			happiness_scores: [Number],
			participation_rates: [Number],
			session_completion: Number,
		},
		monthly_summary: {
			month: Number,
			year: Number,
			total_impact: Number,
			peak_happiness_day: Date,
			most_active_school: String,
		},
	},
	{ timestamps: true }
);

AnalyticsSchema.index({ school_id: 1, date: -1 });
AnalyticsSchema.index({ date: -1 });

module.exports = mongoose.models.Analytics || mongoose.model('Analytics', AnalyticsSchema);
