const mongoose = require('mongoose');

const { Schema } = mongoose;

const AnswerSchema = new Schema({
	qid: {
		type: String,
		required: true,
	},
	answer: {
		type: String,
		required: true,
		trim: true,
	},
	marksObtained: {
		type: Number,
		default: 0,
	},
	isCorrect: {
		type: Boolean,
		default: false,
	},
}, { _id: false });

const StudentResultSchema = new Schema(
	{
		testId: {
			type: Schema.Types.ObjectId,
			ref: 'Test',
			required: [true, 'Test reference is required'],
		},
		testLinkId: {
			type: Schema.Types.ObjectId,
			ref: 'TestLink',
			required: [true, 'Test link reference is required'],
		},
		studentId: {
			type: String,
			required: [true, 'Student ID is required'],
			trim: true,
		},
		studentName: {
			type: String,
			required: [true, 'Student name is required'],
			trim: true,
		},
		grade: {
			type: String,
			required: [true, 'Grade is required'],
			trim: true,
		},
		schoolId: {
			type: Schema.Types.ObjectId,
			ref: 'School',
			required: [true, 'School reference is required'],
		},
		answers: [AnswerSchema],
		totalMarks: {
			type: Number,
			required: [true, 'Total marks is required'],
		},
		marksObtained: {
			type: Number,
			required: [true, 'Marks obtained is required'],
			default: 0,
		},
		percentage: {
			type: Number,
			required: [true, 'Percentage is required'],
			default: 0,
		},
		submittedAt: {
			type: Date,
			default: Date.now,
		},
		timeSpent: {
			type: Number, // in minutes
			default: 0,
		},
		status: {
			type: String,
			enum: ['in_progress', 'submitted', 'graded'],
			default: 'submitted',
		},
	},
	{ timestamps: true }
);

// Calculate percentage before saving
StudentResultSchema.pre('save', function (next) {
	if (this.totalMarks > 0) {
		this.percentage = Math.round((this.marksObtained / this.totalMarks) * 100 * 100) / 100; // Round to 2 decimal places
	}
	next();
});

// Indexes for efficient queries
StudentResultSchema.index({ testId: 1, schoolId: 1 });
StudentResultSchema.index({ studentId: 1, testId: 1 }, { unique: true }); // One result per student per test
StudentResultSchema.index({ schoolId: 1, grade: 1 });
StudentResultSchema.index({ submittedAt: 1 });

module.exports = mongoose.models.StudentResult || mongoose.model('StudentResult', StudentResultSchema);

