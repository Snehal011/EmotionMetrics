const mongoose = require('mongoose');

const { Schema } = mongoose;

const SessionSchema = new Schema(
	{
		school_id: {
			type: Schema.Types.ObjectId,
			ref: 'School',
			required: true,
		},
		session_date: {
			type: Date,
			required: true,
		},
		session_type: {
			type: String,
			enum: ['mandala_art', 'happiness_assessment', 'group_activity'],
			required: true,
		},
		participants: [{
			student_id: String,
			student_name: String,
			grade: String,
			pre_session_score: Number,
			post_session_score: Number,
			emotional_state_before: String,
			emotional_state_after: String,
		}],
		total_participants: {
			type: Number,
			required: true,
		},
		books_distributed: {
			type: Number,
			default: 0,
		},
		average_happiness_before: {
			type: Number,
			required: true,
		},
		average_happiness_after: {
			type: Number,
			required: true,
		},
		improvement_percentage: {
			type: Number,
			required: true,
		},
		photos: [{
			url: String,
			description: String,
			tags: [String],
			uploaded_at: {
				type: Date,
				default: Date.now,
			},
		}],
		videos: [{
			url: String,
			description: String,
			tags: [String],
			uploaded_at: {
				type: Date,
				default: Date.now,
			},
		}],
		notes: {
			type: String,
			trim: true,
		},
		status: {
			type: String,
			enum: ['scheduled', 'in_progress', 'completed', 'cancelled'],
			default: 'scheduled',
		},
		created_by: {
			type: Schema.Types.ObjectId,
			ref: 'Admin',
			required: true,
		},
	},
	{ timestamps: true }
);

SessionSchema.index({ school_id: 1, session_date: -1 });
SessionSchema.index({ created_by: 1 });

module.exports = mongoose.models.Session || mongoose.model('Session', SessionSchema);
