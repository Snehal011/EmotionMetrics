const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const { Schema } = mongoose;

// Simple RFC 5322-like email regex for basic validation
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const AdminSchema = new Schema(
	{
		email: {
			type: String,
			required: [true, 'Email is required'],
			unique: true,
			lowercase: true,
			trim: true,
			validate: {
				validator: (value) => emailRegex.test(value),
				message: 'Invalid email address',
			},
		},
		role: {
			type: String,
			required: true,
			enum: ['admin'],
			default: 'admin',
			lowercase: true,
			trim: true,
		},
		password: {
			type: String,
			required: [true, 'Password is required'],
			minlength: [6, 'Password must be at least 6 characters'],
			trim: true,
		},
	},
	{ timestamps: true }
);

// Hash password before saving
AdminSchema.pre('save', async function (next) {
	try {
		if (!this.isModified('password')) return next();
		const salt = await bcrypt.genSalt(10);
		this.password = await bcrypt.hash(this.password, salt);
		return next();
	} catch (error) {
		return next(error);
	}
});

// Index already defined in field definition with unique: true

module.exports = mongoose.models.Admin || mongoose.model('Admin', AdminSchema);


