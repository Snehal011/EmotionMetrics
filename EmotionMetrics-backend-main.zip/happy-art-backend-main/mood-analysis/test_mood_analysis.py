#!/usr/bin/env python3
"""
Test script for Mood Analysis API
This script tests the mood analysis functionality with a sample image.
"""

import requests
import json
from PIL import Image, ImageDraw
import io
import base64

def create_test_image():
    """Create a simple test image with bright colors"""
    # Create a 200x200 image with a gradient from yellow to blue
    img = Image.new('RGB', (200, 200), color='white')
    draw = ImageDraw.Draw(img)
    
    # Draw a colorful mandala-like pattern
    colors = ['red', 'orange', 'yellow', 'green', 'blue', 'purple', 'pink']
    for i, color in enumerate(colors):
        x = 50 + i * 15
        y = 50 + i * 15
        draw.ellipse([x, y, x+100, y+100], fill=color, outline='black', width=2)
    
    return img

def test_mood_analysis():
    """Test the mood analysis API"""
    print("🧪 Testing Mood Analysis API...")
    print("=" * 50)
    
    # Create test image
    print("Creating test image...")
    test_img = create_test_image()
    
    # Save image to bytes
    img_buffer = io.BytesIO()
    test_img.save(img_buffer, format='PNG')
    img_buffer.seek(0)
    
    # Test the API
    url = 'http://localhost:5001/api/mood-analysis'
    files = {'mandala': ('test_image.png', img_buffer, 'image/png')}
    
    print("Sending request to mood analysis API...")
    try:
        response = requests.post(url, files=files)
        
        if response.status_code == 200:
            data = response.json()
            print("✅ API Response received successfully!")
            print(f"Status: {data.get('success', 'Unknown')}")
            
            if data.get('success'):
                analysis = data.get('analysis', {})
                print(f"🎨 Mood Description: {analysis.get('mood_description', 'Unknown')}")
                print("💡 Recommendations:")
                for i, rec in enumerate(analysis.get('recommendations', []), 1):
                    print(f"   {i}. {rec}")
                
                # Check if image data is returned
                if data.get('image_data'):
                    print("🖼️  Image data received successfully")
                else:
                    print("⚠️  No image data in response")
            else:
                print(f"❌ Analysis failed: {data.get('error', 'Unknown error')}")
        else:
            print(f"❌ HTTP Error: {response.status_code}")
            print(f"Response: {response.text}")
            
    except requests.exceptions.ConnectionError:
        print("❌ Connection Error: Could not connect to the API")
        print("Make sure the Flask server is running on http://localhost:5001")
    except Exception as e:
        print(f"❌ Error: {e}")
    
    print("=" * 50)

def test_health_endpoint():
    """Test the health endpoint"""
    print("🏥 Testing Health Endpoint...")
    try:
        response = requests.get('http://localhost:5001/api/health')
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Health Check: {data.get('status', 'Unknown')}")
            print(f"Service: {data.get('service', 'Unknown')}")
            print(f"Version: {data.get('version', 'Unknown')}")
        else:
            print(f"❌ Health Check Failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Health Check Error: {e}")

def test_info_endpoint():
    """Test the info endpoint"""
    print("ℹ️  Testing Info Endpoint...")
    try:
        response = requests.get('http://localhost:5001/api/mood-analysis/info')
        if response.status_code == 200:
            data = response.json()
            print(f"✅ Info Endpoint: {data.get('success', 'Unknown')}")
            print(f"Supported formats: {data.get('supported_formats', [])}")
            print(f"Max file size: {data.get('max_file_size', 'Unknown')}")
            print(f"Mood categories: {len(data.get('mood_categories', {}))}")
        else:
            print(f"❌ Info Endpoint Failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Info Endpoint Error: {e}")

if __name__ == "__main__":
    print("🎨 HappyArt Mood Analysis API Test")
    print("=" * 50)
    
    # Test health endpoint first
    test_health_endpoint()
    print()
    
    # Test info endpoint
    test_info_endpoint()
    print()
    
    # Test mood analysis
    test_mood_analysis()
    
    print("\n✨ Test completed!")
