# Mood Analysis Service

This service provides AI-powered mood analysis for student artwork using color analysis techniques.

## 📁 Project Structure

```
server/mood-analysis/
├── src/
│   ├── __init__.py
│   ├── routes.py              # Flask API routes
│   └── utils/
│       ├── __init__.py
│       ├── color_analysis.py  # Color analysis algorithms
│       └── recommendations.py # Recommendation generation
├── app.py                     # Main Flask application
├── run.py                     # Server runner script
├── test_mood_analysis.py      # Test script
├── requirements.txt           # Python dependencies
└── README.md                  # This file
```

## 🚀 Quick Start

### Installation

1. **Install Dependencies:**
   ```bash
   cd server/mood-analysis
   pip install -r requirements.txt
   ```

2. **Run the Server:**
   ```bash
   python app.py
   ```

   Or use the runner script:
   ```bash
   python run.py
   ```

### Testing

Run the test script to verify functionality:
```bash
python test_mood_analysis.py
```

## 🔧 API Endpoints

### POST /api/mood-analysis
Analyzes uploaded artwork for mood detection.

**Request:**
- Method: POST
- Content-Type: multipart/form-data
- Body: Form data with 'mandala' field containing the file

**Response:**
```json
{
  "success": true,
  "analysis": {
    "mood_description": "Happy and cheerful",
    "recommendations": [
      "Continue engaging in activities that bring joy",
      "Share positive energy with classmates",
      "Document this positive state for future reference"
    ]
  },
  "image_data": "data:image/png;base64,..."
}
```

### GET /api/health
Health check endpoint.

**Response:**
```json
{
  "status": "healthy",
  "service": "Mood Analysis API",
  "version": "1.0.0"
}
```

### GET /api/mood-analysis/info
Get information about available mood categories.

**Response:**
```json
{
  "success": true,
  "mood_categories": {
    "red": "Energetic or passionate",
    "orange": "Excited or enthusiastic",
    "yellow": "Happy and cheerful",
    "green": "Calm and relaxed",
    "blue": "Creative or introspective",
    "purple": "Thoughtful or dreamy",
    "pink": "Romantic or imaginative",
    "black": "Serious or somber",
    "white": "Balanced mood",
    "gray": "Balanced mood",
    "brown": "Grounded or stable"
  },
  "supported_formats": ["JPG", "PNG", "PDF"],
  "max_file_size": "10MB"
}
```

## 🎨 Mood Analysis Algorithm

The mood analysis uses a sophisticated color analysis algorithm:

1. **Image Preprocessing**: Resize to 150x150 pixels for consistent analysis
2. **Color Filtering**: Remove very dark, very light, and low-saturation colors
3. **K-means Clustering**: Group similar colors into clusters (default: 5 clusters)
4. **HSV Analysis**: Convert RGB to HSV for better color categorization
5. **Weighted Scoring**: Calculate mood based on color frequency and intensity

## 📦 Dependencies

- **Flask**: Web framework
- **Flask-CORS**: Cross-origin request handling
- **Pillow**: Image processing
- **numpy**: Numerical computing
- **scikit-learn**: Machine learning (K-means clustering)
- **pdf2image**: PDF processing

## 🔒 Security Features

- File type validation (JPG, PNG, PDF only)
- File size limits (10MB maximum)
- Input sanitization
- Error handling for corrupted files
- CORS configuration for secure cross-origin requests

## 🧪 Testing

The test script (`test_mood_analysis.py`) includes:

- Health endpoint testing
- Info endpoint testing
- Mood analysis with sample image
- Error handling verification

## 🚀 Production Deployment

For production deployment:

1. **Use a production WSGI server:**
   ```bash
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:5001 app:app
   ```

2. **Set environment variables:**
   ```bash
   export FLASK_ENV=production
   export FLASK_DEBUG=False
   ```

## 📊 Performance

- **Processing Time**: Typically 1-3 seconds per image
- **Memory Usage**: Optimized for minimal memory footprint
- **Concurrent Requests**: Supports multiple simultaneous analyses
- **File Size Limit**: 10MB maximum per upload

## 🔧 Configuration

The service runs on:
- **Host**: 0.0.0.0 (all interfaces)
- **Port**: 5001
- **Debug Mode**: Enabled in development

To change configuration, modify the `main()` function in `app.py`.

## 📝 Logging

The service provides detailed logging for:
- API requests and responses
- Error conditions
- Processing times
- File upload status

## 🤝 Integration

This service is designed to integrate seamlessly with the HappyArt School Dashboard:

- Frontend: React chatbot component
- Backend: Node.js/Express server
- Database: MongoDB (via main server)

The mood analysis results are returned in a format that's directly compatible with the frontend chatbot interface.
