#!/usr/bin/env python3
"""
Mood Analysis Server Runner
This script starts the Flask server for mood analysis functionality.
"""

import subprocess
import sys
import os

def install_requirements():
    """Install required packages"""
    print("Installing required packages...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ Requirements installed successfully!")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Failed to install requirements: {e}")
        return False

def start_server():
    """Start the mood analysis server"""
    print("Starting Mood Analysis Server...")
    print("=" * 50)
    print("🎨 HappyArt Mood Analysis API")
    print("=" * 50)
    print("Server will be available at: http://localhost:5001")
    print("API Endpoints:")
    print("  POST /api/mood-analysis - Analyze artwork mood")
    print("  GET /api/health - Health check")
    print("  GET /api/mood-analysis/info - Get mood categories info")
    print("=" * 50)
    print("Press Ctrl+C to stop the server")
    print("=" * 50)
    
    try:
        subprocess.run([sys.executable, "app.py"])
    except KeyboardInterrupt:
        print("\n🛑 Server stopped by user")
    except Exception as e:
        print(f"❌ Error starting server: {e}")

if __name__ == "__main__":
    # Check if requirements.txt exists
    if not os.path.exists("requirements.txt"):
        print("❌ requirements.txt not found!")
        sys.exit(1)
    
    # Install requirements
    if not install_requirements():
        sys.exit(1)
    
    # Start server
    start_server()
