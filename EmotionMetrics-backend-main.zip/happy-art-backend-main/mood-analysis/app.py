"""
Mood Analysis Flask Application
Main application file for the mood analysis service.
"""

from flask import Flask
from flask_cors import CORS
from src import create_mood_analysis_routes

def create_app():
    """
    Create and configure the Flask application.
    
    Returns:
        Flask: Configured Flask application
    """
    app = Flask(__name__)
    
    # Enable CORS for all routes
    CORS(app)
    
    # Register mood analysis routes
    create_mood_analysis_routes(app)
    
    return app

def main():
    """
    Main function to run the Flask application.
    """
    app = create_app()
    
    print("Starting Mood Analysis Server...")
    print("=" * 50)
    print("🎨 HappyArt Mood Analysis API")
    print("=" * 50)
    print("Server will be available at: http://localhost:5001")
    print("API Endpoints:")
    print("  POST /api/mood-analysis - Analyze artwork mood")
    print("  GET /api/health - Health check")
    print("  GET /api/mood-analysis/info - Get mood categories info")
    print("=" * 50)
    print("Press Ctrl+C to stop the server")
    print("=" * 50)
    
    app.run(debug=True, host='0.0.0.0', port=5001)

if __name__ == "__main__":
    main()
