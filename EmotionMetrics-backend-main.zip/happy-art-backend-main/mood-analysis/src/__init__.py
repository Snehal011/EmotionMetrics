"""
Mood Analysis Package
This package provides mood analysis functionality for artwork.
"""

from .routes import create_mood_analysis_routes

__all__ = ['create_mood_analysis_routes']
