"""
Mood Analysis API Routes
This module contains the Flask routes for mood analysis functionality.
"""

from flask import request, jsonify
from PIL import Image
from io import BytesIO
import base64
from pdf2image import convert_from_bytes

from .utils import get_weighted_mood, generate_recommendations

def create_mood_analysis_routes(app):
    """
    Create and register mood analysis routes with the Flask app.
    
    Args:
        app (Flask): The Flask application instance
    """
    
    @app.route('/api/mood-analysis', methods=['POST'])
    def analyze_mood():
        """
        Analyze uploaded artwork for mood detection.
        
        Returns:
            JSON response with mood analysis results
        """
        try:
            if 'mandala' not in request.files:
                return jsonify({
                    'success': False,
                    'error': 'No file uploaded'
                }), 400

            file = request.files['mandala']
            if file.filename == '':
                return jsonify({
                    'success': False,
                    'error': 'No file selected'
                }), 400

            try:
                filename = file.filename.lower()
                if filename.endswith('.pdf'):
                    pages = convert_from_bytes(file.read(), first_page=1, last_page=1)
                    image = pages[0].convert('RGB')
                else:
                    image_stream = BytesIO(file.read())
                    image = Image.open(image_stream).convert('RGB')
            except Exception as e:
                return jsonify({
                    'success': False,
                    'error': f'Could not open file. Use JPG, PNG, or PDF. Error: {str(e)}'
                }), 400

            # Analyze mood
            mood_description = get_weighted_mood(image)
            recommendations = generate_recommendations(mood_description)
            
            # Convert image to base64 for frontend display
            buffered = BytesIO()
            image.save(buffered, format="PNG")
            img_str = base64.b64encode(buffered.getvalue()).decode()
            img_data = f"data:image/png;base64,{img_str}"

            return jsonify({
                'success': True,
                'analysis': {
                    'mood_description': mood_description,
                    'recommendations': recommendations
                },
                'image_data': img_data
            })

        except Exception as e:
            return jsonify({
                'success': False,
                'error': f'Analysis failed: {str(e)}'
            }), 500

    @app.route('/api/health', methods=['GET'])
    def health_check():
        """
        Health check endpoint for the mood analysis service.
        
        Returns:
            JSON response with service status
        """
        return jsonify({
            'status': 'healthy',
            'service': 'Mood Analysis API',
            'version': '1.0.0'
        })

    @app.route('/api/mood-analysis/info', methods=['GET'])
    def get_mood_info():
        """
        Get information about available mood categories.
        
        Returns:
            JSON response with mood categories and descriptions
        """
        from .utils import get_color_mood_mapping
        
        return jsonify({
            'success': True,
            'mood_categories': get_color_mood_mapping(),
            'supported_formats': ['JPG', 'PNG', 'PDF'],
            'max_file_size': '10MB'
        })
