"""
Color Analysis Utilities
This module contains functions for analyzing colors in artwork to determine mood.
"""

import colorsys
import numpy as np
from sklearn.cluster import KMeans

# Color to mood mapping
COLOR_MOOD = {
    'red': 'Energetic or passionate',
    'orange': 'Excited or enthusiastic',
    'yellow': 'Happy and cheerful',
    'green': 'Calm and relaxed',
    'blue': 'Creative or introspective',
    'purple': 'Thoughtful or dreamy',
    'pink': 'Romantic or imaginative',
    'black': 'Serious or somber',
    'white': 'Balanced mood',
    'gray': 'Balanced mood',
    'brown': 'Grounded or stable'
}

def rgb_to_hsv_basic(r, g, b):
    """
    Convert RGB values to HSV and categorize into basic color groups.
    
    Args:
        r (int): Red value (0-255)
        g (int): Green value (0-255)
        b (int): Blue value (0-255)
    
    Returns:
        str: Basic color category
    """
    r_n, g_n, b_n = r/255, g/255, b/255
    h, s, v = colorsys.rgb_to_hsv(r_n, g_n, b_n)
    
    # Handle very dark colors
    if v < 0.2:
        return 'black'
    
    # Handle very light colors
    if v > 0.95 and s < 0.3:
        return 'white'
    
    # Handle low saturation colors
    if s < 0.2:
        return 'gray'
    
    # Categorize by hue
    if h < 0.05 or h > 0.9:
        return 'red'
    elif h < 0.1:
        return 'orange'
    elif h < 0.17:
        return 'yellow'
    elif h < 0.42:
        return 'green'
    elif h < 0.58:
        return 'blue'
    elif h < 0.75:
        return 'purple'
    elif h < 0.9:
        return 'pink'
    else:
        return 'gray'

def get_weighted_mood(image, n_clusters=5):
    """
    Analyze an image to determine the dominant mood based on color analysis.
    
    Args:
        image (PIL.Image): The image to analyze
        n_clusters (int): Number of color clusters for K-means analysis
    
    Returns:
        str: The dominant mood description
    """
    # Resize image for consistent analysis
    image = image.resize((150, 150))
    pixels = np.array(image).reshape(-1, 3)
    
    # Filter out very dark, very light, and low-saturation colors
    filtered_pixels = []
    for r, g, b in pixels:
        r_n, g_n, b_n = r/255, g/255, b/255
        h, s, v = colorsys.rgb_to_hsv(r_n, g_n, b_n)
        if 0.2 < v < 0.95 and s > 0.2:
            filtered_pixels.append([r, g, b])
    
    # If too few pixels after filtering, use all pixels
    if len(filtered_pixels) < 10:
        filtered_pixels = pixels.tolist()
    
    filtered_pixels = np.array(filtered_pixels)
    
    # Perform K-means clustering to find dominant colors
    kmeans = KMeans(n_clusters=n_clusters, random_state=42)
    labels = kmeans.fit_predict(filtered_pixels)
    counts = np.bincount(labels)
    cluster_centers = kmeans.cluster_centers_.astype(int)
    
    # Calculate mood scores based on color clusters
    mood_scores = {}
    total_pixels = sum(counts)
    
    for i, center in enumerate(cluster_centers):
        base_color = rgb_to_hsv_basic(*center)
        mood = COLOR_MOOD.get(base_color, 'Balanced mood')
        weight = counts[i] / total_pixels
        mood_scores[mood] = mood_scores.get(mood, 0) + weight
    
    # Return the mood with the highest score
    return max(mood_scores, key=mood_scores.get)

def get_color_mood_mapping():
    """
    Get the color to mood mapping dictionary.
    
    Returns:
        dict: Color to mood mapping
    """
    return COLOR_MOOD.copy()
