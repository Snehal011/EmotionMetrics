"""
Recommendations Generator
This module generates personalized recommendations based on mood analysis results.
"""

def generate_recommendations(mood):
    """
    Generate recommendations based on mood analysis.
    
    Args:
        mood (str): The mood description from color analysis
    
    Returns:
        list: List of recommendation strings
    """
    recommendations = []
    mood_lower = mood.lower()
    
    if 'energetic' in mood_lower or 'passionate' in mood_lower:
        recommendations.extend([
            "Consider channeling this energy into creative projects",
            "Engage in physical activities or sports",
            "Use this energy for leadership roles in group activities"
        ])
    elif 'excited' in mood_lower or 'enthusiastic' in mood_lower:
        recommendations.extend([
            "Maintain this positive energy throughout the day",
            "Share enthusiasm with peers in collaborative projects",
            "Use this excitement to tackle challenging tasks"
        ])
    elif 'happy' in mood_lower or 'cheerful' in mood_lower:
        recommendations.extend([
            "Continue engaging in activities that bring joy",
            "Share positive energy with classmates",
            "Document this positive state for future reference"
        ])
    elif 'calm' in mood_lower or 'relaxed' in mood_lower:
        recommendations.extend([
            "This is a great state for focused learning",
            "Consider meditation or mindfulness activities",
            "Use this calmness for problem-solving tasks"
        ])
    elif 'creative' in mood_lower or 'introspective' in mood_lower:
        recommendations.extend([
            "Engage in artistic and creative projects",
            "Spend time in quiet reflection or journaling",
            "Explore new creative mediums and techniques"
        ])
    elif 'thoughtful' in mood_lower or 'dreamy' in mood_lower:
        recommendations.extend([
            "Use this state for planning and goal setting",
            "Engage in creative writing or storytelling",
            "Consider sharing thoughts and ideas with others"
        ])
    elif 'romantic' in mood_lower or 'imaginative' in mood_lower:
        recommendations.extend([
            "Channel imagination into creative projects",
            "Engage in storytelling or role-playing activities",
            "Explore fantasy and creative writing"
        ])
    elif 'serious' in mood_lower or 'somber' in mood_lower:
        recommendations.extend([
            "Consider discussing feelings with a trusted adult",
            "Engage in calming activities like drawing or music",
            "Practice stress-relief techniques"
        ])
    elif 'grounded' in mood_lower or 'stable' in mood_lower:
        recommendations.extend([
            "Maintain this stable foundation for learning",
            "Use this stability to help others",
            "Continue with consistent daily routines"
        ])
    else:
        # Default recommendations for balanced mood
        recommendations.extend([
            "Continue with current activities",
            "Monitor emotional state regularly",
            "Engage in a variety of activities to maintain balance"
        ])
    
    return recommendations[:3]  # Return top 3 recommendations

def get_mood_insights(mood):
    """
    Get additional insights about the mood.
    
    Args:
        mood (str): The mood description
    
    Returns:
        dict: Additional insights about the mood
    """
    insights = {
        'mood': mood,
        'energy_level': 'moderate',
        'social_tendency': 'balanced',
        'learning_style': 'mixed'
    }
    
    mood_lower = mood.lower()
    
    if 'energetic' in mood_lower or 'excited' in mood_lower:
        insights['energy_level'] = 'high'
        insights['social_tendency'] = 'outgoing'
        insights['learning_style'] = 'active'
    elif 'calm' in mood_lower or 'relaxed' in mood_lower:
        insights['energy_level'] = 'low'
        insights['social_tendency'] = 'introverted'
        insights['learning_style'] = 'focused'
    elif 'creative' in mood_lower or 'imaginative' in mood_lower:
        insights['energy_level'] = 'moderate'
        insights['social_tendency'] = 'creative'
        insights['learning_style'] = 'visual'
    elif 'serious' in mood_lower or 'somber' in mood_lower:
        insights['energy_level'] = 'low'
        insights['social_tendency'] = 'withdrawn'
        insights['learning_style'] = 'analytical'
    
    return insights
