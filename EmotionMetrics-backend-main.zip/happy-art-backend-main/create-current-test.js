const mongoose = require('mongoose');
const Test = require('./models/Test');
const TestLink = require('./models/TestLink');
const School = require('./models/School');
require('dotenv').config();

async function createCurrentTest() {
    try {
        // Connect to MongoDB
        const MONGODB_URI = process.env.MONGODB_URI || process.env.MONGO_URI || process.env.MONGODB_URL;
        if (!MONGODB_URI) {
            console.error('MONGODB_URI not found in environment variables');
            process.exit(1);
        }
        
        await mongoose.connect(MONGODB_URI);
        console.log('Connected to MongoDB');

        // Find or create test school
        let school = await School.findOne({ email: 'testschool@example.com' });
        if (!school) {
            school = new School({
                name: 'Test School Admin',
                email: 'testschool@example.com',
                role: 'school',
                school_name: 'Test School',
                password: 'school123'
            });
            await school.save();
            console.log('Test school created');
        }

        // Create a test with current time
        const now = new Date();
        const startTime = new Date(now.getTime() - 30 * 60 * 1000); // 30 minutes ago
        const endTime = new Date(now.getTime() + 30 * 60 * 1000); // 30 minutes from now

        let test = await Test.findOne({ name: 'Current Test Example' });
        if (!test) {
            test = new Test({
                name: 'Current Test Example',
                type: 'pre',
                grade: '5',
                subject: 'Mathematics',
                durationMinutes: 30,
                startTime: startTime,
                endTime: endTime,
                questions: [
                    {
                        qid: 'current_q1',
                        text: 'What is 3 + 3?',
                        type: 'mcq',
                        options: ['5', '6', '7', '8'],
                        correctOption: '6',
                        marks: 5
                    },
                    {
                        qid: 'current_q2',
                        text: 'Explain multiplication',
                        type: 'subjective',
                        marks: 10
                    }
                ],
                createdBy: '507f1f77bcf86cd799439011', // Use existing admin ID
                status: 'active'
            });
            await test.save();
            console.log('Current test created');
        }

        // Create a test link with current time
        let testLink = await TestLink.findOne({ linkHash: 'current1' });
        if (!testLink) {
            testLink = new TestLink({
                test: test._id,
                school: school._id,
                grade: '5',
                linkHash: 'current1',
                url: '/public/test/current1',
                status: 'active',
                startTime: startTime,
                endTime: endTime
            });
            await testLink.save();
            console.log('Current test link created');
        }

        console.log('\n=== Current Test Data Created ===');
        console.log('Test Link Hash:', testLink.linkHash);
        console.log('Test URL:', `http://localhost:5000/public/test/${testLink.linkHash}`);
        console.log('Test Name:', test.name);
        console.log('School:', school.school_name);
        console.log('Start Time:', testLink.startTime);
        console.log('End Time:', testLink.endTime);
        console.log('Current Time:', now);
        console.log('Is Active:', now >= testLink.startTime && now <= testLink.endTime);

        await mongoose.connection.close();
        console.log('\nDisconnected from MongoDB');
    } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
    }
}

createCurrentTest();
