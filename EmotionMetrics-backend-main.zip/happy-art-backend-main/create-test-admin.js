const mongoose = require('mongoose');
const Admin = require('./models/Admin');
require('dotenv').config();

async function createTestAdmin() {
    try {
        // Connect to MongoDB
        const MONGODB_URI = process.env.MONGODB_URI || process.env.MONGO_URI || process.env.MONGODB_URL;
        if (!MONGODB_URI) {
            console.error('MONGODB_URI not found in environment variables');
            process.exit(1);
        }
        
        await mongoose.connect(MONGODB_URI);
        console.log('Connected to MongoDB');

        // Check if admin already exists
        const existingAdmin = await Admin.findOne({ email: 'admin@test.com' });
        if (existingAdmin) {
            console.log('Test admin already exists:');
            console.log('Email: admin@test.com');
            console.log('Password: admin123');
            console.log('ID:', existingAdmin._id);
        } else {
            // Create test admin
            const admin = new Admin({
                email: 'admin@test.com',
                password: 'admin123',
                role: 'admin'
            });

            await admin.save();
            console.log('Test admin created successfully:');
            console.log('Email: admin@test.com');
            console.log('Password: admin123');
            console.log('ID:', admin._id);
        }

        await mongoose.connection.close();
        console.log('Disconnected from MongoDB');
    } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
    }
}

createTestAdmin();

