const { v4: uuidv4 } = require('uuid');
const Test = require('../models/Test');
const TestLink = require('../models/TestLink');
const StudentResult = require('../models/StudentResult');
const School = require('../models/School');

// Helper function to generate unique question ID
const generateQuestionId = () => {
	return `q_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

// Helper function to generate link hash
const generateLinkHash = () => {
	return uuidv4().replace(/-/g, '').slice(0, 8);
};

// 1. Create a new test
const createTest = async (req, res) => {
	try {
		const { name, type, grade, subject, durationMinutes, startTime, endTime, questions } = req.body;
		const adminId = req.user.id;

		// Generate qid for questions that don't have one
		const processedQuestions = questions.map(question => ({
			...question,
			qid: question.qid || generateQuestionId(),
		}));

		const test = new Test({
			name,
			type,
			grade,
			subject,
			durationMinutes,
			startTime: new Date(startTime),
			endTime: new Date(endTime),
			questions: processedQuestions,
			createdBy: adminId,
			status: 'draft',
		});

		await test.save();

		res.status(201).json({
			message: 'Test created successfully',
			test: {
				id: test._id,
				name: test.name,
				type: test.type,
				grade: test.grade,
				subject: test.subject,
				durationMinutes: test.durationMinutes,
				startTime: test.startTime,
				endTime: test.endTime,
				questions: test.questions,
				status: test.status,
				totalMarks: test.totalMarks,
				createdAt: test.createdAt,
			},
		});
	} catch (error) {
		console.error('Error creating test:', error);
		res.status(500).json({
			message: 'Failed to create test',
			error: error.message,
		});
	}
};

// 2. Update test metadata and questions
const updateTest = async (req, res) => {
	try {
		const { testId } = req.params;
		const { name, type, grade, subject, durationMinutes, startTime, endTime, questions } = req.body;

		const test = await Test.findById(testId);
		if (!test) {
			return res.status(404).json({ message: 'Test not found' });
		}

		// Check if test has already started
		if (new Date() >= test.startTime) {
			return res.status(400).json({ message: 'Cannot edit test that has already started' });
		}

		// Update test metadata
		if (name !== undefined) test.name = name;
		if (type !== undefined) test.type = type;
		if (grade !== undefined) test.grade = grade;
		if (subject !== undefined) test.subject = subject;
		if (durationMinutes !== undefined) test.durationMinutes = durationMinutes;
		if (startTime !== undefined) test.startTime = new Date(startTime);
		if (endTime !== undefined) test.endTime = new Date(endTime);

		// Update questions if provided
		if (questions !== undefined) {
			const processedQuestions = questions.map(question => ({
				...question,
				qid: question.qid || generateQuestionId(),
			}));
			test.questions = processedQuestions;
		}

		await test.save();

		res.json({
			message: 'Test updated successfully',
			test: {
				id: test._id,
				name: test.name,
				type: test.type,
				grade: test.grade,
				subject: test.subject,
				durationMinutes: test.durationMinutes,
				startTime: test.startTime,
				endTime: test.endTime,
				questions: test.questions,
				status: test.status,
				totalMarks: test.totalMarks,
				updatedAt: test.updatedAt,
			},
		});
	} catch (error) {
		console.error('Error updating test:', error);
		res.status(500).json({
			message: 'Failed to update test',
			error: error.message,
		});
	}
};

// 3. Publish test and generate links for schools
const publishTest = async (req, res) => {
	try {
		const { testId } = req.params;
		const { schoolIds } = req.body;

		// Validation: Admin must select at least one school before publishing
		if (!schoolIds || schoolIds.length === 0) {
			return res.status(400).json({ message: 'At least one school must be selected before publishing' });
		}

		const test = await Test.findById(testId);
		if (!test) {
			return res.status(404).json({ message: 'Test not found' });
		}

		if (test.status !== 'draft') {
			return res.status(400).json({ message: 'Only draft tests can be published' });
		}

		// Verify all schools exist
		const schools = await School.find({ _id: { $in: schoolIds } });
		if (schools.length !== schoolIds.length) {
			return res.status(400).json({ message: 'One or more schools not found' });
		}

		const generatedLinks = [];

		// Generate TestLink for each school
		for (const school of schools) {
			const linkHash = generateLinkHash();
			const url = `/public/test/${linkHash}`;

			const testLink = new TestLink({
				test: testId,
				school: school._id,
				grade: test.grade,
				linkHash,
				url,
				status: 'active',
				startTime: test.startTime,
				endTime: test.endTime,
			});

			await testLink.save();

			generatedLinks.push({
				schoolId: school._id,
				schoolName: school.school_name,
				grade: test.grade,
				linkHash,
				url,
				startTime: test.startTime,
				endTime: test.endTime,
			});
		}

		// Update test status to active and store school information
		test.status = 'active';
		test.assignedSchools = schoolIds;
		test.schoolNames = schools.map(school => school.school_name);
		await test.save();

		res.json({
			message: 'Test published successfully',
			testId: test._id,
			generatedLinks,
		});
	} catch (error) {
		console.error('Error publishing test:', error);
		res.status(500).json({
			message: 'Failed to publish test',
			error: error.message,
		});
	}
};

// 4. Manually expire test
const expireTest = async (req, res) => {
	try {
		const { testId } = req.params;

		const test = await Test.findById(testId);
		if (!test) {
			return res.status(404).json({ message: 'Test not found' });
		}

		// Update test status
		test.status = 'expired';
		await test.save();

		// Update all associated TestLinks
		await TestLink.updateMany(
			{ test: testId },
			{ status: 'expired' }
		);

		res.json({
			message: 'Test expired successfully',
			testId: test._id,
		});
	} catch (error) {
		console.error('Error expiring test:', error);
		res.status(500).json({
			message: 'Failed to expire test',
			error: error.message,
		});
	}
};

// 5. Get all tests with pagination and filters
const getTests = async (req, res) => {
	try {
		const { page = 1, limit = 10, type, grade, status } = req.query;
		const adminId = req.user.id;

		// Build filter object
		const filter = { createdBy: adminId };
		if (type) filter.type = type;
		if (grade) filter.grade = grade;
		if (status) filter.status = status;

		const skip = (parseInt(page) - 1) * parseInt(limit);

		const tests = await Test.find(filter)
			.populate('assignedSchools', 'school_name')
			.sort({ createdAt: -1 })
			.skip(skip)
			.limit(parseInt(limit))
			.select('-questions.options -questions.correctOption'); // Exclude sensitive question data

		const total = await Test.countDocuments(filter);

		res.json({
			tests,
			pagination: {
				currentPage: parseInt(page),
				totalPages: Math.ceil(total / parseInt(limit)),
				totalTests: total,
				hasNext: skip + tests.length < total,
				hasPrev: parseInt(page) > 1,
			},
		});
	} catch (error) {
		console.error('Error fetching tests:', error);
		res.status(500).json({
			message: 'Failed to fetch tests',
			error: error.message,
		});
	}
};

// 6. Get test results
const getTestResults = async (req, res) => {
	try {
		const { testId } = req.params;

		const test = await Test.findById(testId);
		if (!test) {
			return res.status(404).json({ message: 'Test not found' });
		}

		// Get all results for this test
		const results = await StudentResult.find({ testId })
			.populate('schoolId', 'school_name')
			.sort({ marksObtained: -1 });

		if (results.length === 0) {
			return res.json({
				message: 'No results found for this test',
				testId,
				results: [],
				statistics: null,
			});
		}

		// Calculate statistics
		const totalStudents = results.length;
		const totalMarks = results.reduce((sum, result) => sum + result.marksObtained, 0);
		const averageMarks = totalMarks / totalStudents;
		const averagePercentage = results.reduce((sum, result) => sum + result.percentage, 0) / totalStudents;

		const topScores = results.slice(0, 10).map(result => ({
			studentName: result.studentName,
			grade: result.grade,
			schoolName: result.schoolId.school_name,
			marksObtained: result.marksObtained,
			percentage: result.percentage,
		}));

		// Grade-wise statistics
		const gradeStats = {};
		results.forEach(result => {
			if (!gradeStats[result.grade]) {
				gradeStats[result.grade] = {
					count: 0,
					totalMarks: 0,
					students: [],
				};
			}
			gradeStats[result.grade].count++;
			gradeStats[result.grade].totalMarks += result.marksObtained;
			gradeStats[result.grade].students.push({
				studentName: result.studentName,
				marksObtained: result.marksObtained,
				percentage: result.percentage,
			});
		});

		// Calculate averages for each grade
		Object.keys(gradeStats).forEach(grade => {
			gradeStats[grade].averageMarks = gradeStats[grade].totalMarks / gradeStats[grade].count;
		});

		res.json({
			testId,
			testName: test.name,
			testType: test.type,
			grade: test.grade,
			subject: test.subject,
			totalMarks: test.totalMarks,
			statistics: {
				totalStudents,
				averageMarks: Math.round(averageMarks * 100) / 100,
				averagePercentage: Math.round(averagePercentage * 100) / 100,
				topScores,
				gradeStats,
			},
			results: results.map(result => ({
				studentName: result.studentName,
				grade: result.grade,
				schoolName: result.schoolId.school_name,
				marksObtained: result.marksObtained,
				percentage: result.percentage,
				submittedAt: result.submittedAt,
			})),
		});
	} catch (error) {
		console.error('Error fetching test results:', error);
		res.status(500).json({
			message: 'Failed to fetch test results',
			error: error.message,
		});
	}
};

// 7. Delete a test
const deleteTest = async (req, res) => {
	try {
		const { testId } = req.params;
		const adminId = req.user.id;

		// Find the test and verify ownership
		const test = await Test.findOne({ _id: testId, createdBy: adminId });
		if (!test) {
			return res.status(404).json({
				message: 'Test not found or you do not have permission to delete this test',
			});
		}

		// Delete associated test links
		await TestLink.deleteMany({ testId: testId });

		// Delete associated student results
		await StudentResult.deleteMany({ testId: testId });

		// Delete the test
		await Test.findByIdAndDelete(testId);

		res.json({
			message: 'Test deleted successfully',
		});
	} catch (error) {
		console.error('Error deleting test:', error);
		res.status(500).json({
			message: 'Failed to delete test',
			error: error.message,
		});
	}
};

module.exports = {
	createTest,
	updateTest,
	publishTest,
	expireTest,
	getTests,
	getTestResults,
	deleteTest,
};

