const Test = require('../models/Test');
const TestLink = require('../models/TestLink');
const StudentResult = require('../models/StudentResult');

// Get test by link hash for public access
const getTestByLink = async (req, res) => {
	try {
		const { linkHash } = req.params;

		// Find the TestLink with the given hash
		const testLink = await TestLink.findOne({ linkHash })
			.populate('test', 'name type durationMinutes grade subject questions')
			.populate('school', 'school_name');

		if (!testLink) {
			return res.status(403).json({
				message: 'Link expired or invalid',
			});
		}

		// Check if link is active
		if (testLink.status !== 'active') {
			return res.status(403).json({
				message: 'Link expired or invalid',
			});
		}

		// Check if current time is between startTime and endTime
		const now = new Date();
		
		if (now < testLink.startTime) {
			return res.status(403).json({
				message: 'Test has not started yet. Please try again later.',
				details: {
					startTime: testLink.startTime,
					currentTime: now
				}
			});
		}
		
		if (now > testLink.endTime) {
			return res.status(403).json({
				message: 'Test has expired. The test period has ended.',
				details: {
					endTime: testLink.endTime,
					currentTime: now
				}
			});
		}

		// Get the test data
		const test = testLink.test;
		if (!test) {
			return res.status(403).json({
				message: 'Link expired or invalid',
			});
		}

		// Remove correctOption from MCQ questions for security
		const sanitizedQuestions = test.questions.map(question => {
			const sanitizedQuestion = {
				qid: question.qid,
				text: question.text,
				type: question.type,
				marks: question.marks,
			};

			// Only include options for MCQ questions
			if (question.type === 'mcq' && question.options) {
				sanitizedQuestion.options = question.options;
			}

			// Don't include correctOption for security
			return sanitizedQuestion;
		});

		// Return test data without sensitive information
		res.json({
			testId: test._id,
			name: test.name,
			type: test.type,
			durationMinutes: test.durationMinutes,
			grade: test.grade,
			subject: test.subject,
			questions: sanitizedQuestions,
			linkInfo: {
				linkHash: testLink.linkHash,
				startTime: testLink.startTime,
				endTime: testLink.endTime,
				schoolName: testLink.school?.school_name,
			},
		});
	} catch (error) {
		console.error('Error fetching test by link:', error);
		res.status(500).json({
			message: 'Internal server error',
			error: error.message,
		});
	}
};

// Submit test answers
const submitTest = async (req, res) => {
	try {
		const { linkHash } = req.params;
		const { name, rollNo, answers } = req.body;

		// Find the TestLink with the given hash
		const testLink = await TestLink.findOne({ linkHash })
			.populate('test', 'name type durationMinutes grade subject questions')
			.populate('school', 'school_name _id');

		if (!testLink) {
			return res.status(403).json({
				message: 'Link expired or invalid',
			});
		}

		// Check if link is active
		if (testLink.status !== 'active') {
			return res.status(403).json({
				message: 'Link expired or invalid',
			});
		}

		// Check if current time is between startTime and endTime
		const now = new Date();
		
		if (now < testLink.startTime) {
			return res.status(403).json({
				message: 'Test has not started yet. Please try again later.',
				details: {
					startTime: testLink.startTime,
					currentTime: now
				}
			});
		}
		
		if (now > testLink.endTime) {
			return res.status(403).json({
				message: 'Test has expired. The test period has ended.',
				details: {
					endTime: testLink.endTime,
					currentTime: now
				}
			});
		}

		// Get the test data
		const test = testLink.test;
		if (!test) {
			return res.status(403).json({
				message: 'Link expired or invalid',
			});
		}

		// Check if student has already submitted
		const existingResult = await StudentResult.findOne({
			testId: test._id,
			studentId: rollNo,
		});

		if (existingResult) {
			return res.status(400).json({
				message: 'Test already submitted by this student',
			});
		}

		// Calculate marks for each answer
		let totalMarksObtained = 0;
		const processedAnswers = answers.map(answer => {
			const question = test.questions.find(q => q.qid === answer.qid);
			if (!question) {
				return {
					qid: answer.qid,
					answer: answer.answerText || (answer.selectedOptionIndex !== undefined ? question?.options?.[answer.selectedOptionIndex] : ''),
					marksObtained: 0,
					isCorrect: false,
				};
			}

			let marksObtained = 0;
			let isCorrect = false;

			if (question.type === 'mcq') {
				// For MCQ, check if selected option matches correct option
				const selectedOption = question.options[answer.selectedOptionIndex];
				if (selectedOption === question.correctOption) {
					marksObtained = question.marks;
					isCorrect = true;
				}
			} else if (question.type === 'subjective') {
				// For subjective questions, give full marks (can be manually graded later)
				marksObtained = question.marks;
				isCorrect = true;
			}

			totalMarksObtained += marksObtained;

			return {
				qid: answer.qid,
				answer: answer.answerText || (answer.selectedOptionIndex !== undefined ? question.options[answer.selectedOptionIndex] : ''),
				marksObtained,
				isCorrect,
			};
		});

		// Calculate total marks
		const totalMarks = test.questions.reduce((sum, question) => sum + question.marks, 0);

		// Create student result
		const studentResult = new StudentResult({
			testId: test._id,
			testLinkId: testLink._id,
			studentId: rollNo,
			studentName: name,
			grade: test.grade,
			schoolId: testLink.school._id,
			answers: processedAnswers,
			totalMarks,
			marksObtained: totalMarksObtained,
			submittedAt: new Date(),
			status: 'submitted',
		});

		await studentResult.save();

		res.json({
			resultId: studentResult._id,
			marksObtained: totalMarksObtained,
			totalMarks,
			percentage: Math.round((totalMarksObtained / totalMarks) * 100 * 100) / 100,
			message: 'Test submitted successfully',
		});
	} catch (error) {
		console.error('Error submitting test:', error);
		res.status(500).json({
			message: 'Internal server error',
			error: error.message,
		});
	}
};

// Get student result by link hash and result ID
const getStudentResult = async (req, res) => {
	try {
		const { linkHash, resultId } = req.params;

		// Find the TestLink with the given hash
		const testLink = await TestLink.findOne({ linkHash })
			.populate('test', 'name type grade subject')
			.populate('school', 'school_name');

		if (!testLink) {
			return res.status(403).json({
				message: 'Link expired or invalid',
			});
		}

		// Check if link is active
		if (testLink.status !== 'active') {
			return res.status(403).json({
				message: 'Link expired or invalid',
			});
		}

		// Check if current time is between startTime and endTime
		const now = new Date();
		
		if (now < testLink.startTime) {
			return res.status(403).json({
				message: 'Test has not started yet. Please try again later.',
				details: {
					startTime: testLink.startTime,
					currentTime: now
				}
			});
		}
		
		if (now > testLink.endTime) {
			return res.status(403).json({
				message: 'Test has expired. The test period has ended.',
				details: {
					endTime: testLink.endTime,
					currentTime: now
				}
			});
		}

		// Find the student result
		const studentResult = await StudentResult.findOne({
			_id: resultId,
			testLinkId: testLink._id,
		}).populate('schoolId', 'school_name');

		if (!studentResult) {
			return res.status(404).json({
				message: 'Result not found',
			});
		}

		// Return student result data
		res.json({
			resultId: studentResult._id,
			studentName: studentResult.studentName,
			rollNo: studentResult.studentId,
			grade: studentResult.grade,
			schoolName: studentResult.schoolId?.school_name,
			testInfo: {
				testId: testLink.test._id,
				testName: testLink.test.name,
				testType: testLink.test.type,
				subject: testLink.test.subject,
			},
			marksObtained: studentResult.marksObtained,
			totalMarks: studentResult.totalMarks,
			percentage: studentResult.percentage,
			submittedAt: studentResult.submittedAt,
			answers: studentResult.answers.map(answer => ({
				qid: answer.qid,
				answer: answer.answer,
				marksObtained: answer.marksObtained,
				isCorrect: answer.isCorrect,
			})),
		});
	} catch (error) {
		console.error('Error fetching student result:', error);
		res.status(500).json({
			message: 'Internal server error',
			error: error.message,
		});
	}
};

module.exports = {
	getTestByLink,
	submitTest,
	getStudentResult,
};
