const express = require('express');
const Admin = require('../models/Admin');
const School = require('../models/School');

const router = express.Router();

// POST /api/create-account
router.post('/api/create-account', async (req, res) => {
	try {
		const { role } = req.body || {};
		const normalizedRole = typeof role === 'string' ? role.toLowerCase().trim() : undefined;

		if (!normalizedRole) {
			return res.status(400).json({ message: 'Invalid role' });
		}

		let created;
		if (normalizedRole === 'admin') {
			const { email, password } = req.body;
			created = await Admin.create({ email, password, role: 'admin' });
		} else if (normalizedRole === 'school') {
			const { name, email, password, school_name } = req.body;
			created = await School.create({ name, email, password, school_name, role: 'school' });
		} else {
			return res.status(400).json({ message: 'Invalid role' });
		}

		return res.status(201).json({ success: true, data: created });
	} catch (error) {
		// Handle common Mongoose errors
		if (error && (error.name === 'ValidationError' || error.code === 11000)) {
			return res.status(400).json({ success: false, message: error.message, details: error.errors || undefined });
		}
		return res.status(500).json({ success: false, message: 'Internal server error' });
	}
});

module.exports = router;


