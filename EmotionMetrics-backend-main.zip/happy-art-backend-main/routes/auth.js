const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const Admin = require('../models/Admin');
const School = require('../models/School');

const router = express.Router();

// POST /api/login
router.post('/api/login', async (req, res) => {
	try {
		const { email, password } = req.body || {};

		if (!email || !password) {
			return res.status(400).json({ message: 'Email and password are required' });
		}

		// Try to find user across known roles (admin, school)
		let user = await Admin.findOne({ email });
		if (!user) user = await School.findOne({ email });

		if (!user) {
			return res.status(401).json({ message: 'Invalid credentials' });
		}

		const isMatch = await bcrypt.compare(password, user.password);
		if (!isMatch) {
			return res.status(401).json({ message: 'Invalid credentials' });
		}

		const jwtSecret = process.env.JWT_SECRET;
		if (!jwtSecret) {
			return res.status(500).json({ message: 'JWT secret not configured' });
		}

		const payload = { id: String(user._id), role: user.role, email: user.email };
		const token = jwt.sign(payload, jwtSecret, { expiresIn: '1h' });

		return res.json({ message: 'Login successful', token, role: user.role });
	} catch (error) {
		return res.status(500).json({ message: 'Internal server error' });
	}
});

module.exports = router;


