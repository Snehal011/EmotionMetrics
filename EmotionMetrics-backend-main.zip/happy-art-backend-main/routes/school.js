const express = require('express');
const { param, validationResult } = require('express-validator');
const { verifyToken, requireRole } = require('../middleware/auth');
const TestLink = require('../models/TestLink');
const StudentResult = require('../models/StudentResult');
const Test = require('../models/Test');

const router = express.Router();

// Middleware to check for validation errors
const handleValidationErrors = (req, res, next) => {
	const errors = validationResult(req);
	if (!errors.isEmpty()) {
		return res.status(400).json({
			message: 'Validation failed',
			errors: errors.array(),
		});
	}
	next();
};

// Apply authentication and school role check to all routes
router.use(verifyToken);
router.use(requireRole('school'));

// 1. GET /api/school/tests - Get assigned tests for the school
router.get(
	'/tests',
	[],
	handleValidationErrors,
	async (req, res) => {
		try {
			const schoolId = req.user.id;
			const now = new Date();
			
			// Find all test links for this school (both active and expired)
			const testLinks = await TestLink.find({ 
				school: schoolId,
				status: { $in: ['active', 'expired'] }
			})
			.populate('test', 'name type grade subject durationMinutes startTime endTime status')
			.sort({ createdAt: -1 });

			// If no test links found, return empty state
			if (!testLinks || testLinks.length === 0) {
				return res.json({
					message: 'No tests assigned to your school yet',
					tests: [],
					count: 0,
					isEmpty: true
				});
			}

			// Filter out any test links where the test was deleted or doesn't exist
			const validTestLinks = testLinks.filter(link => link.test !== null);

			// If all test links have deleted tests, return empty state
			if (validTestLinks.length === 0) {
				return res.json({
					message: 'No tests assigned to your school yet',
					tests: [],
					count: 0,
					isEmpty: true
				});
			}

			// Format the response and determine actual status based on time
			const assignedTests = validTestLinks.map(link => {
				let actualStatus = link.test.status;
				
				// Check if test has expired based on endTime
				if (now > link.endTime && link.test.status !== 'expired') {
					actualStatus = 'expired';
				}
				
				return {
					id: link.test._id,
					testLinkId: link._id,
					name: link.test.name,
					type: link.test.type,
					grade: link.grade,
					subject: link.test.subject,
					durationMinutes: link.test.durationMinutes,
					status: actualStatus,
					startTime: link.startTime,
					endTime: link.endTime,
					linkHash: link.linkHash,
					url: link.url,
					createdAt: link.createdAt
				};
			});

			res.json({
				message: 'Assigned tests retrieved successfully',
				tests: assignedTests,
				count: assignedTests.length,
				isEmpty: false
			});
		} catch (error) {
			console.error('Error fetching assigned tests:', error);
			
			// Handle specific error types
			if (error.name === 'CastError') {
				return res.status(400).json({
					message: 'Invalid school ID format',
					error: 'Invalid ID format'
				});
			}
			
			if (error.name === 'ValidationError') {
				return res.status(400).json({
					message: 'Validation error',
					error: error.message
				});
			}
			
			// For other errors, return a generic message to avoid exposing internal details
			res.status(500).json({
				message: 'Unable to fetch assigned tests. Please try again later.',
				error: 'Database connection or query error'
			});
		}
	}
);

// 2. GET /api/school/test/:testId/results - Get test results for a specific test
router.get(
	'/test/:testId/results',
	[
		param('testId')
			.isMongoId()
			.withMessage('Invalid test ID'),
	],
	handleValidationErrors,
	async (req, res) => {
		try {
			const { testId } = req.params;
			const schoolId = req.user.id;

			// Verify the school has access to this test
			const testLink = await TestLink.findOne({
				test: testId,
				school: schoolId
			});

			if (!testLink) {
				return res.status(403).json({
					message: 'Access denied. Test not assigned to this school.',
				});
			}

			// Get all student results for this test from this school
			const results = await StudentResult.find({
				testId: testId,
				schoolId: schoolId
			})
			.sort({ submittedAt: -1 });

			// Get test details
			const test = await Test.findById(testId).select('name type grade subject totalMarks');

			// Calculate statistics
			const totalStudents = results.length;
			const totalMarks = test?.totalMarks || 0;
			const averageMarks = totalStudents > 0 ? results.reduce((sum, result) => sum + result.marksObtained, 0) / totalStudents : 0;
			const averagePercentage = totalMarks > 0 ? (averageMarks / totalMarks) * 100 : 0;

			// Get top scorers
			const topScorers = results
				.sort((a, b) => b.marksObtained - a.marksObtained)
				.slice(0, 5)
				.map(result => ({
					studentName: result.studentName,
					grade: result.grade,
					marksObtained: result.marksObtained,
					percentage: totalMarks > 0 ? (result.marksObtained / totalMarks) * 100 : 0
				}));

			// Format results for response
			const formattedResults = results.map(result => ({
				id: result._id,
				rollNo: result.studentId,
				name: result.studentName,
				grade: result.grade,
				marksObtained: result.marksObtained,
				totalMarks: result.totalMarks,
				percentage: result.percentage,
				submittedAt: result.submittedAt,
				status: result.status
			}));

			res.json({
				message: 'Test results retrieved successfully',
				test: {
					id: test?._id,
					name: test?.name,
					type: test?.type,
					grade: test?.grade,
					subject: test?.subject,
					totalMarks: test?.totalMarks
				},
				statistics: {
					totalStudents,
					averageMarks: Math.round(averageMarks * 100) / 100,
					averagePercentage: Math.round(averagePercentage * 100) / 100,
					topScorers
				},
				results: formattedResults
			});
		} catch (error) {
			console.error('Error fetching test results:', error);
			res.status(500).json({
				message: 'Internal server error',
				error: error.message,
			});
		}
	}
);

module.exports = router;
