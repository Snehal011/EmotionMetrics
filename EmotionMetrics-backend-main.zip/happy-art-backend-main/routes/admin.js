const express = require('express');
const { body, param, query, validationResult } = require('express-validator');
const { verifyToken, requireRole } = require('../middleware/auth');
const School = require('../models/School');
const TestLink = require('../models/TestLink');
const Test = require('../models/Test');
const StudentResult = require('../models/StudentResult');
const {
	createTest,
	updateTest,
	publishTest,
	expireTest,
	getTests,
	getTestResults,
	deleteTest,
} = require('../controllers/adminController');

const router = express.Router();

// Middleware to check for validation errors
const handleValidationErrors = (req, res, next) => {
	const errors = validationResult(req);
	if (!errors.isEmpty()) {
		return res.status(400).json({
			message: 'Validation failed',
			errors: errors.array(),
		});
	}
	next();
};

// Apply authentication and admin role check to all routes
router.use(verifyToken);
router.use(requireRole('admin'));

// Validation rules for question objects
const questionValidation = [
	body('questions.*.text')
		.notEmpty()
		.withMessage('Question text is required')
		.trim(),
	body('questions.*.type')
		.isIn(['mcq', 'subjective'])
		.withMessage('Question type must be either mcq or subjective'),
	body('questions.*.marks')
		.isInt({ min: 1 })
		.withMessage('Marks must be a positive integer'),
	body('questions.*.options')
		.if(body('questions.*.type').equals('mcq'))
		.isArray({ min: 2 })
		.withMessage('MCQ questions must have at least 2 options'),
	body('questions.*.correctOption')
		.if(body('questions.*.type').equals('mcq'))
		.notEmpty()
		.withMessage('Correct option is required for MCQ questions'),
];

// 1. POST /api/admin/test - Create a new test
router.post(
	'/test',
	[
		body('name')
			.notEmpty()
			.withMessage('Test name is required')
			.trim()
			.isLength({ min: 1, max: 200 })
			.withMessage('Test name must be between 1 and 200 characters'),
		body('type')
			.isIn(['pre', 'post'])
			.withMessage('Test type must be either pre or post'),
		body('grade')
			.notEmpty()
			.withMessage('Grade is required')
			.trim(),
		body('subject')
			.notEmpty()
			.withMessage('Subject is required')
			.trim(),
		body('durationMinutes')
			.isInt({ min: 1, max: 300 })
			.withMessage('Duration must be between 1 and 300 minutes'),
		body('startTime')
			.isISO8601()
			.withMessage('Start time must be a valid ISO 8601 date')
			.custom((value) => {
				const startTime = new Date(value);
				const now = new Date();
				// Allow start time to be up to 5 minutes in the past to account for timezone differences
				if (startTime <= new Date(now.getTime() - 5 * 60 * 1000)) {
					throw new Error('Start time must be in the future (or very recent past)');
				}
				return true;
			}),
		body('endTime')
			.isISO8601()
			.withMessage('End time must be a valid ISO 8601 date')
			.custom((value, { req }) => {
				const startTime = new Date(req.body.startTime);
				const endTime = new Date(value);
				if (endTime <= startTime) {
					throw new Error('End time must be after start time');
				}
				return true;
			}),
		body('questions')
			.isArray({ min: 1 })
			.withMessage('At least one question is required'),
		...questionValidation,
	],
	handleValidationErrors,
	createTest
);

// 2. PUT /api/admin/test/:testId - Update test
router.put(
	'/test/:testId',
	[
		param('testId')
			.isMongoId()
			.withMessage('Invalid test ID'),
		body('name')
			.optional()
			.trim()
			.isLength({ min: 1, max: 200 })
			.withMessage('Test name must be between 1 and 200 characters'),
		body('type')
			.optional()
			.isIn(['pre', 'post'])
			.withMessage('Test type must be either pre or post'),
		body('grade')
			.optional()
			.trim()
			.notEmpty()
			.withMessage('Grade cannot be empty'),
		body('subject')
			.optional()
			.trim()
			.notEmpty()
			.withMessage('Subject cannot be empty'),
		body('durationMinutes')
			.optional()
			.isInt({ min: 1, max: 300 })
			.withMessage('Duration must be between 1 and 300 minutes'),
		body('startTime')
			.optional()
			.isISO8601()
			.withMessage('Start time must be a valid ISO 8601 date'),
		body('endTime')
			.optional()
			.isISO8601()
			.withMessage('End time must be a valid ISO 8601 date'),
		body('questions')
			.optional()
			.isArray({ min: 1 })
			.withMessage('At least one question is required'),
		...questionValidation.map(rule => rule.optional()),
	],
	handleValidationErrors,
	updateTest
);

// 3. POST /api/admin/test/:testId/publish - Publish test
router.post(
	'/test/:testId/publish',
	[
		param('testId')
			.isMongoId()
			.withMessage('Invalid test ID'),
		body('schoolIds')
			.isArray({ min: 1 })
			.withMessage('At least one school ID is required'),
		body('schoolIds.*')
			.isMongoId()
			.withMessage('Invalid school ID'),
	],
	handleValidationErrors,
	publishTest
);

// 4. POST /api/admin/test/:testId/expire - Expire test
router.post(
	'/test/:testId/expire',
	[
		param('testId')
			.isMongoId()
			.withMessage('Invalid test ID'),
	],
	handleValidationErrors,
	expireTest
);

// 5. GET /api/admin/tests - Get all tests with pagination and filters
router.get(
	'/tests',
	[
		query('page')
			.optional()
			.isInt({ min: 1 })
			.withMessage('Page must be a positive integer'),
		query('limit')
			.optional()
			.isInt({ min: 1, max: 100 })
			.withMessage('Limit must be between 1 and 100'),
		query('type')
			.optional()
			.isIn(['pre', 'post'])
			.withMessage('Type must be either pre or post'),
		query('grade')
			.optional()
			.trim()
			.notEmpty()
			.withMessage('Grade cannot be empty'),
		query('status')
			.optional()
			.isIn(['draft', 'active', 'expired', 'completed'])
			.withMessage('Status must be one of: draft, active, expired, completed'),
	],
	handleValidationErrors,
	getTests
);

// 6. GET /api/admin/test/:testId/results - Get test results
router.get(
	'/test/:testId/results',
	[
		param('testId')
			.isMongoId()
			.withMessage('Invalid test ID'),
	],
	handleValidationErrors,
	getTestResults
);

// 7. DELETE /api/admin/test/:testId - Delete test
router.delete(
	'/test/:testId',
	[
		param('testId')
			.isMongoId()
			.withMessage('Invalid test ID'),
	],
	handleValidationErrors,
	deleteTest
);

// 8. GET /api/admin/schools - Get all schools
router.get(
	'/schools',
	[],
	handleValidationErrors,
	async (req, res) => {
		try {
			const schools = await School.find({}, 'name email school_name').sort({ name: 1 });
			res.json(schools);
		} catch (error) {
			console.error('Error fetching schools:', error);
			res.status(500).json({
				message: 'Internal server error',
				error: error.message,
			});
		}
	}
);

// 9. GET /api/admin/school/:schoolId/tests - Get assigned tests for a specific school (admin access)
router.get(
	'/school/:schoolId/tests',
	[
		param('schoolId')
			.isMongoId()
			.withMessage('Invalid school ID'),
	],
	handleValidationErrors,
	async (req, res) => {
		try {
			const { schoolId } = req.params;
			const now = new Date();
			
			// Find all test links for this school (both active and expired)
			const testLinks = await TestLink.find({ 
				school: schoolId,
				status: { $in: ['active', 'expired'] }
			})
			.populate('test', 'name type grade subject durationMinutes startTime endTime status')
			.sort({ createdAt: -1 });

			// If no test links found, return empty state
			if (!testLinks || testLinks.length === 0) {
				return res.json({
					message: 'No tests assigned to this school yet',
					tests: [],
					count: 0,
					isEmpty: true
				});
			}

			// Filter out any test links where the test was deleted or doesn't exist
			const validTestLinks = testLinks.filter(link => link.test !== null);

			// If all test links have deleted tests, return empty state
			if (validTestLinks.length === 0) {
				return res.json({
					message: 'No tests assigned to this school yet',
					tests: [],
					count: 0,
					isEmpty: true
				});
			}

			// Format the response and determine actual status based on time
			const assignedTests = validTestLinks.map(link => {
				let actualStatus = link.test.status;
				
				// Check if test has expired based on endTime
				if (now > link.endTime && link.test.status !== 'expired') {
					actualStatus = 'expired';
				}
				
				return {
					id: link.test._id,
					testLinkId: link._id,
					name: link.test.name,
					type: link.test.type,
					grade: link.grade,
					subject: link.test.subject,
					durationMinutes: link.test.durationMinutes,
					status: actualStatus,
					startTime: link.startTime,
					endTime: link.endTime,
					linkHash: link.linkHash,
					url: link.url,
					createdAt: link.createdAt
				};
			});

			res.json({
				message: 'Assigned tests retrieved successfully',
				tests: assignedTests,
				count: assignedTests.length,
				isEmpty: false
			});
		} catch (error) {
			console.error('Error fetching assigned tests for school:', error);
			
			// Handle specific error types
			if (error.name === 'CastError') {
				return res.status(400).json({
					message: 'Invalid school ID format',
					error: 'Invalid ID format'
				});
			}
			
			if (error.name === 'ValidationError') {
				return res.status(400).json({
					message: 'Validation error',
					error: error.message
				});
			}
			
			// For other errors, return a generic message to avoid exposing internal details
			res.status(500).json({
				message: 'Unable to fetch assigned tests. Please try again later.',
				error: 'Database connection or query error'
			});
		}
	}
);

// 10. GET /api/admin/school/:schoolId/test/:testId/results - Get test results for a specific school and test (admin access)
router.get(
	'/school/:schoolId/test/:testId/results',
	[
		param('schoolId')
			.isMongoId()
			.withMessage('Invalid school ID'),
		param('testId')
			.isMongoId()
			.withMessage('Invalid test ID'),
	],
	handleValidationErrors,
	async (req, res) => {
		try {
			const { schoolId, testId } = req.params;

			// Verify the school has access to this test
			const testLink = await TestLink.findOne({
				test: testId,
				school: schoolId
			});

			if (!testLink) {
				return res.status(200).json({
					message: 'No test results found for this school and test combination.',
					test: null,
					summary: {
						totalStudents: 0,
						averageMarks: 0,
						averagePercentage: 0,
						topScorers: []
					},
					results: []
				});
			}

			// Get all student results for this test from this school
			const results = await StudentResult.find({
				testId: testId,
				schoolId: schoolId
			})
			.sort({ submittedAt: -1 });

			// Get test details
			const test = await Test.findById(testId).select('name type grade subject totalMarks');

			// Calculate statistics
			const totalStudents = results.length;
			const totalMarks = test?.totalMarks || 0;
			const averageMarks = totalStudents > 0 ? results.reduce((sum, result) => sum + result.marksObtained, 0) / totalStudents : 0;
			const averagePercentage = totalMarks > 0 ? (averageMarks / totalMarks) * 100 : 0;

			// Get top scorers
			const topScorers = results
				.sort((a, b) => b.marksObtained - a.marksObtained)
				.slice(0, 5)
				.map(result => ({
					studentName: result.studentName,
					grade: result.grade,
					marksObtained: result.marksObtained,
					percentage: totalMarks > 0 ? (result.marksObtained / totalMarks) * 100 : 0
				}));

			// Format results for response
			const formattedResults = results.map(result => ({
				id: result._id,
				rollNo: result.studentId,
				name: result.studentName,
				grade: result.grade,
				marksObtained: result.marksObtained,
				totalMarks: result.totalMarks,
				percentage: result.percentage,
				submittedAt: result.submittedAt,
				status: result.status
			}));

			res.json({
				message: 'Test results retrieved successfully',
				test: {
					id: test?._id,
					name: test?.name,
					type: test?.type,
					grade: test?.grade,
					subject: test?.subject,
					totalMarks: test?.totalMarks
				},
				statistics: {
					totalStudents,
					averageMarks: Math.round(averageMarks * 100) / 100,
					averagePercentage: Math.round(averagePercentage * 100) / 100,
					topScorers
				},
				results: formattedResults
			});
		} catch (error) {
			console.error('Error fetching test results for school:', error);
			res.status(500).json({
				message: 'Internal server error',
				error: error.message,
			});
		}
	}
);

module.exports = router;
