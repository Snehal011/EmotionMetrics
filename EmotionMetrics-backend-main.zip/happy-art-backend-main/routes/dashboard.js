const express = require('express');
const { verifyToken } = require('../middleware/auth');
const School = require('../models/School');
const Admin = require('../models/Admin');
const Session = require('../models/Session');
const Analytics = require('../models/Analytics');

const router = express.Router();

// Apply authentication middleware to all dashboard routes
router.use(verifyToken);

// GET /api/dashboard/summary
router.get('/api/dashboard/summary', async (req, res) => {
	try {
		const { role, id } = req.user;
		
		let user;
		if (role === 'school') {
			user = await School.findById(id);
		} else if (role === 'admin') {
			user = await Admin.findById(id);
		}

		if (!user) {
			return res.status(404).json({ message: 'User not found' });
		}

		// Mock data for now - you can replace this with real data from your database
		const summary = {
			schoolName: user.school_name || user.name || 'School Portal',
			logoUrl: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=80&h=80&fit=crop&crop=center',
			studentsImpacted: 1245,
			studentsChange: 12,
			avgHappiness: 8.7,
			happinessChange: 0.3,
			sessionsConducted: 56
		};

		res.json(summary);
	} catch (error) {
		console.error('Error fetching dashboard summary:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// GET /api/dashboard/recent
router.get('/api/dashboard/recent', async (req, res) => {
	try {
		// Mock recent activities - you can replace this with real data from your database
		const recentActivities = [
			{
				id: 1,
				title: 'New student enrolled in Art Therapy Program',
				time: '2 hours ago',
				type: 'success',
				icon: 'CheckCircle'
			},
			{
				id: 2,
				title: 'Weekly happiness assessment completed',
				time: '4 hours ago',
				type: 'info',
				icon: 'BarChart'
			},
			{
				id: 3,
				title: 'Art session scheduled for Grade 3',
				time: '6 hours ago',
				type: 'warning',
				icon: 'Palette'
			},
			{
				id: 4,
				title: 'Parent-teacher meeting completed',
				time: '8 hours ago',
				type: 'info',
				icon: 'Users'
			}
		];

		res.json(recentActivities);
	} catch (error) {
		console.error('Error fetching recent activities:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// GET /api/dashboard/actions
router.get('/api/dashboard/actions', async (req, res) => {
	try {
		// Mock quick actions - you can replace this with real data from your database
		const quickActions = [
			{
				id: 1,
				title: 'Add New Student',
				description: 'Enroll a new student',
				icon: 'Plus',
				color: 'bg-blue-500 hover:bg-blue-600',
				iconBg: 'bg-blue-100',
				url: '/students/add'
			},
			{
				id: 2,
				title: 'Schedule Session',
				description: 'Plan art therapy session',
				icon: 'Calendar',
				color: 'bg-green-500 hover:bg-green-600',
				iconBg: 'bg-green-100',
				url: '/sessions/schedule'
			},
			{
				id: 3,
				title: 'Generate Report',
				description: 'Create progress report',
				icon: 'FileText',
				color: 'bg-purple-500 hover:bg-purple-600',
				iconBg: 'bg-purple-100',
				url: '/reports/generate'
			}
		];

		res.json(quickActions);
	} catch (error) {
		console.error('Error fetching quick actions:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// GET /api/user/profile - Get current user info
router.get('/api/user/profile', async (req, res) => {
	try {
		const { role, id } = req.user;
		
		let user;
		if (role === 'school') {
			user = await School.findById(id).select('-password');
		} else if (role === 'admin') {
			user = await Admin.findById(id).select('-password');
		}

		if (!user) {
			return res.status(404).json({ message: 'User not found' });
		}

		res.json({
			id: user._id,
			name: user.name || user.school_name,
			email: user.email,
			role: user.role,
			schoolName: user.school_name
		});
	} catch (error) {
		console.error('Error fetching user profile:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// POST /api/logout - Logout endpoint (optional, mainly for server-side session management)
router.post('/api/logout', (req, res) => {
	// Since we're using JWT tokens, logout is mainly handled client-side
	// This endpoint can be used for server-side session cleanup if needed
	res.json({ message: 'Logout successful' });
});

// GET /api/questionnaire/data - Get questionnaire data for analytics
router.get('/api/questionnaire/data', async (req, res) => {
	try {
		const { role, id } = req.user;
		
		// Mock questionnaire data - replace with real database queries
		const questionnaireData = {
			classes: [
				{
					className: 'Grade 3A',
					totalStudents: 25,
					averagePreTest: 6.2,
					averagePostTest: 8.1,
					averageImprovement: 30.6,
					students: [
						{
							id: 's1',
							name: 'Emma Johnson',
							grade: '3A',
							preTestScore: 5.5,
							postTestScore: 8.2,
							happinessImprovement: 49.1,
							emotionalDistribution: { happy: 40, neutral: 30, sad: 15, anxious: 10, excited: 5 }
						},
						{
							id: 's2',
							name: 'Liam Smith',
							grade: '3A',
							preTestScore: 7.1,
							postTestScore: 8.8,
							happinessImprovement: 23.9,
							emotionalDistribution: { happy: 50, neutral: 25, sad: 10, anxious: 10, excited: 5 }
						}
					]
				}
			],
			overallStats: {
				totalStudents: 53,
				averageHappinessBefore: 6.5,
				averageHappinessAfter: 8.3,
				overallImprovement: 27.7
			}
		};

		res.json(questionnaireData);
	} catch (error) {
		console.error('Error fetching questionnaire data:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// GET /api/analytics/data - Get analytics data
router.get('/api/analytics/data', async (req, res) => {
	try {
		const { role, id } = req.user;
		
		// Mock analytics data - replace with real database queries
		const analyticsData = {
			classes: [
				{
					className: 'Grade 3A',
					totalStudents: 25,
					averagePreTest: 6.2,
					averagePostTest: 8.1,
					averageImprovement: 30.6,
					trends: {
						weeklyImprovement: [15, 22, 28, 30],
						participationRate: 92,
						sessionCompletion: 88
					},
					students: [
						{
							id: 's1',
							name: 'Emma Johnson',
							grade: '3A',
							preTestScore: 5.5,
							postTestScore: 8.2,
							happinessImprovement: 49.1,
							emotionalTrend: { week1: 5.5, week2: 6.8, week3: 7.4, week4: 8.2 },
							participationRate: 95,
							artSessionCount: 12,
							lastSessionDate: '2024-01-15'
						}
					]
				}
			],
			overallStats: {
				totalStudents: 53,
				averageHappinessBefore: 6.5,
				averageHappinessAfter: 8.3,
				overallImprovement: 27.7,
				totalSessions: 156,
				averageParticipation: 90.5
			},
			timeRange: {
				startDate: '2024-01-01',
				endDate: '2024-01-31'
			}
		};

		res.json(analyticsData);
	} catch (error) {
		console.error('Error fetching analytics data:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// POST /api/reports/export - Export report data
router.post('/api/reports/export', async (req, res) => {
	try {
		const { role, id } = req.user;
		const { reportType, format, filters } = req.body;
		
		// Mock report generation - replace with real report generation logic
		const reportData = {
			reportId: `report_${Date.now()}`,
			reportType,
			format,
			filters,
			downloadUrl: `/api/reports/download/${Date.now()}`,
			generatedAt: new Date().toISOString()
		};

		res.json(reportData);
	} catch (error) {
		console.error('Error generating report:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// ==================== ADMIN DASHBOARD ROUTES ====================

// GET /api/admin/overview - Get comprehensive admin dashboard overview
router.get('/api/admin/overview', async (req, res) => {
	try {
		const { role } = req.user;
		
		if (role !== 'admin') {
			return res.status(403).json({ message: 'Access denied. Admin role required.' });
		}

		// Get all schools with their data
		const schools = await School.find({ status: 'active' });
		
		// Calculate aggregate statistics
		const totalSchools = schools.length;
		const totalBooksDistributed = schools.reduce((sum, school) => sum + (school.books_distributed || 0), 0);
		const totalChildrenImpacted = schools.reduce((sum, school) => sum + (school.total_students || 0), 0);
		
		// Calculate happiness scores
		const happinessData = schools.map(school => ({
			before: school.happiness_scores?.before_art || 0,
			after: school.happiness_scores?.after_art || 0,
			improvement: school.happiness_scores?.average_improvement || 0
		}));
		
		const avgHappinessBefore = happinessData.length > 0 
			? happinessData.reduce((sum, data) => sum + data.before, 0) / happinessData.length 
			: 0;
		const avgHappinessAfter = happinessData.length > 0 
			? happinessData.reduce((sum, data) => sum + data.after, 0) / happinessData.length 
			: 0;
		const overallImprovement = avgHappinessBefore > 0 
			? ((avgHappinessAfter - avgHappinessBefore) / avgHappinessBefore) * 100 
			: 0;

		// Get recent sessions
		const recentSessions = await Session.find({ status: 'completed' })
			.populate('school_id', 'school_name')
			.sort({ session_date: -1 })
			.limit(5);

		const overview = {
			totalSchools,
			totalBooksDistributed,
			totalChildrenImpacted,
			happinessScores: {
				before: Math.round(avgHappinessBefore * 10) / 10,
				after: Math.round(avgHappinessAfter * 10) / 10,
				improvement: Math.round(overallImprovement * 10) / 10
			},
			recentSessions: recentSessions.map(session => ({
				id: session._id,
				schoolName: session.school_id.school_name,
				date: session.session_date,
				participants: session.total_participants,
				improvement: session.improvement_percentage
			})),
			lastUpdated: new Date()
		};

		res.json(overview);
	} catch (error) {
		console.error('Error fetching admin overview:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// GET /api/admin/schools - Get all schools with detailed information
router.get('/api/admin/schools', async (req, res) => {
	try {
		const { role } = req.user;
		
		if (role !== 'admin') {
			return res.status(403).json({ message: 'Access denied. Admin role required.' });
		}

		const schools = await School.find({ status: 'active' })
			.select('-password')
			.sort({ last_activity: -1 });

		const schoolsWithDetails = await Promise.all(schools.map(async (school) => {
			// Get recent sessions for this school
			const recentSessions = await Session.find({ 
				school_id: school._id, 
				status: 'completed' 
			}).sort({ session_date: -1 }).limit(3);

			// Get photo count
			const photoCount = school.photos ? school.photos.length : 0;

			return {
				id: school._id,
				name: school.school_name,
				email: school.email,
				address: school.address,
				phone: school.phone,
				principalName: school.principal_name,
				totalStudents: school.total_students || 0,
				booksDistributed: school.books_distributed || 0,
				lastActivity: school.last_activity,
				happinessIndex: school.happiness_scores?.average_improvement || 0,
				status: school.status,
				photoCount,
				recentSessions: recentSessions.map(session => ({
					id: session._id,
					date: session.session_date,
					participants: session.total_participants,
					improvement: session.improvement_percentage
				}))
			};
		}));

		res.json(schoolsWithDetails);
	} catch (error) {
		console.error('Error fetching schools:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// GET /api/admin/school/:id/details - Get detailed school information
router.get('/api/admin/school/:id/details', async (req, res) => {
	try {
		const { role } = req.user;
		const { id } = req.params;
		
		if (role !== 'admin') {
			return res.status(403).json({ message: 'Access denied. Admin role required.' });
		}

		const school = await School.findById(id).select('-password');
		if (!school) {
			return res.status(404).json({ message: 'School not found' });
		}

		// Get all sessions for this school
		const sessions = await Session.find({ school_id: id })
			.sort({ session_date: -1 });

		// Get analytics data
		const analytics = await Analytics.find({ school_id: id })
			.sort({ date: -1 })
			.limit(12); // Last 12 months

		const schoolDetails = {
			basicInfo: {
				id: school._id,
				name: school.school_name,
				email: school.email,
				address: school.address,
				phone: school.phone,
				principalName: school.principal_name,
				status: school.status,
				createdAt: school.createdAt
			},
			statistics: {
				totalStudents: school.total_students || 0,
				booksDistributed: school.books_distributed || 0,
				happinessScores: school.happiness_scores || {},
				photoCount: school.photos ? school.photos.length : 0,
				sessionCount: sessions.length
			},
			sessions: sessions.map(session => ({
				id: session._id,
				date: session.session_date,
				type: session.session_type,
				participants: session.total_participants,
				happinessBefore: session.average_happiness_before,
				happinessAfter: session.average_happiness_after,
				improvement: session.improvement_percentage,
				status: session.status,
				photos: session.photos || [],
				notes: session.notes
			})),
			analytics: analytics.map(analytic => ({
				date: analytic.date,
				metrics: analytic.metrics,
				weeklyTrends: analytic.weekly_trends
			})),
			photos: school.photos || []
		};

		res.json(schoolDetails);
	} catch (error) {
		console.error('Error fetching school details:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// GET /api/admin/photos - Get photo gallery with filtering options
router.get('/api/admin/photos', async (req, res) => {
	try {
		const { role } = req.user;
		const { school_id, date_from, date_to, tags } = req.query;
		
		if (role !== 'admin') {
			return res.status(403).json({ message: 'Access denied. Admin role required.' });
		}

		let query = {};
		if (school_id) query.school_id = school_id;
		if (date_from || date_to) {
			query['photos.uploaded_at'] = {};
			if (date_from) query['photos.uploaded_at'].$gte = new Date(date_from);
			if (date_to) query['photos.uploaded_at'].$lte = new Date(date_to);
		}

		const schools = await School.find(query).select('school_name photos');
		
		let allPhotos = [];
		schools.forEach(school => {
			if (school.photos && school.photos.length > 0) {
				school.photos.forEach(photo => {
					// Filter by tags if provided
					if (!tags || photo.tags.some(tag => tags.includes(tag))) {
						allPhotos.push({
							id: photo._id,
							url: photo.url,
							description: photo.description,
							tags: photo.tags,
							uploadedAt: photo.uploaded_at,
							schoolName: school.school_name,
							schoolId: school._id
						});
					}
				});
			}
		});

		// Sort by upload date
		allPhotos.sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt));

		res.json(allPhotos);
	} catch (error) {
		console.error('Error fetching photos:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// GET /api/admin/analytics - Get comprehensive analytics data
router.get('/api/admin/analytics', async (req, res) => {
	try {
		const { role } = req.user;
		const { timeRange = '6months' } = req.query;
		
		if (role !== 'admin') {
			return res.status(403).json({ message: 'Access denied. Admin role required.' });
		}

		// Calculate date range
		const now = new Date();
		let startDate;
		switch (timeRange) {
			case '1month':
				startDate = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
				break;
			case '3months':
				startDate = new Date(now.getFullYear(), now.getMonth() - 3, now.getDate());
				break;
			case '6months':
				startDate = new Date(now.getFullYear(), now.getMonth() - 6, now.getDate());
				break;
			case '1year':
				startDate = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
				break;
			default:
				startDate = new Date(now.getFullYear(), now.getMonth() - 6, now.getDate());
		}

		// Get analytics data
		const analytics = await Analytics.find({
			date: { $gte: startDate, $lte: now }
		}).populate('school_id', 'school_name').sort({ date: 1 });

		// Get all schools for comparison
		const schools = await School.find({ status: 'active' });

		// Process data for charts
		const happinessTrends = analytics.map(data => ({
			date: data.date,
			before: data.metrics.average_happiness_before,
			after: data.metrics.average_happiness_after,
			improvement: data.metrics.improvement_percentage
		}));

		const schoolComparison = schools.map(school => ({
			name: school.school_name,
			students: school.total_students || 0,
			books: school.books_distributed || 0,
			happinessImprovement: school.happiness_scores?.average_improvement || 0,
			lastActivity: school.last_activity
		}));

		// Calculate heatmap data (emotional changes over time)
		const heatmapData = analytics.map(data => ({
			date: data.date,
			school: data.school_id.school_name,
			emotions: data.metrics.emotional_transitions || []
		}));

		const analyticsData = {
			timeRange: {
				start: startDate,
				end: now,
				label: timeRange
			},
			happinessTrends,
			schoolComparison,
			heatmapData,
			summary: {
				totalSchools: schools.length,
				totalStudents: schools.reduce((sum, school) => sum + (school.total_students || 0), 0),
				totalBooks: schools.reduce((sum, school) => sum + (school.books_distributed || 0), 0),
				averageImprovement: schoolComparison.length > 0 
					? schoolComparison.reduce((sum, school) => sum + school.happinessImprovement, 0) / schoolComparison.length 
					: 0
			}
		};

		res.json(analyticsData);
	} catch (error) {
		console.error('Error fetching analytics:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// POST /api/admin/school - Create new school
router.post('/api/admin/school', async (req, res) => {
	try {
		const { role } = req.user;
		
		if (role !== 'admin') {
			return res.status(403).json({ message: 'Access denied. Admin role required.' });
		}

		const schoolData = {
			...req.body,
			role: 'school'
		};

		const school = new School(schoolData);
		await school.save();

		res.status(201).json({
			message: 'School created successfully',
			school: {
				id: school._id,
				name: school.school_name,
				email: school.email
			}
		});
	} catch (error) {
		console.error('Error creating school:', error);
		if (error.code === 11000) {
			res.status(400).json({ message: 'Email already exists' });
		} else {
			res.status(500).json({ message: 'Internal server error' });
		}
	}
});

// POST /api/admin/session - Create new session
router.post('/api/admin/session', async (req, res) => {
	try {
		const { role, id } = req.user;
		
		if (role !== 'admin') {
			return res.status(403).json({ message: 'Access denied. Admin role required.' });
		}

		const sessionData = {
			...req.body,
			created_by: id
		};

		const session = new Session(sessionData);
		await session.save();

		// Update school's last activity
		await School.findByIdAndUpdate(sessionData.school_id, {
			last_activity: new Date()
		});

		res.status(201).json({
			message: 'Session created successfully',
			session: {
				id: session._id,
				date: session.session_date,
				school: sessionData.school_id
			}
		});
	} catch (error) {
		console.error('Error creating session:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

// POST /api/admin/upload-photos - Upload photos for a school
router.post('/api/admin/upload-photos', async (req, res) => {
	try {
		const { role } = req.user;
		const { school_id, photos } = req.body;
		
		if (role !== 'admin') {
			return res.status(403).json({ message: 'Access denied. Admin role required.' });
		}

		const school = await School.findById(school_id);
		if (!school) {
			return res.status(404).json({ message: 'School not found' });
		}

		// Add photos to school
		const newPhotos = photos.map(photo => ({
			url: photo.url,
			description: photo.description || '',
			tags: photo.tags || [],
			uploaded_at: new Date()
		}));

		school.photos = [...(school.photos || []), ...newPhotos];
		await school.save();

		res.json({
			message: 'Photos uploaded successfully',
			uploadedCount: newPhotos.length
		});
	} catch (error) {
		console.error('Error uploading photos:', error);
		res.status(500).json({ message: 'Internal server error' });
	}
});

module.exports = router;
