const express = require('express');
const { param, body, validationResult } = require('express-validator');
const { getTestByLink, submitTest, getStudentResult } = require('../controllers/publicController');

const router = express.Router();

// Middleware to check for validation errors
const handleValidationErrors = (req, res, next) => {
	const errors = validationResult(req);
	if (!errors.isEmpty()) {
		return res.status(400).json({
			message: 'Validation failed',
			errors: errors.array(),
		});
	}
	next();
};

// GET /public/test/:linkHash - Get test by link hash (public access)
router.get(
	'/test/:linkHash',
	[
		param('linkHash')
			.notEmpty()
			.withMessage('Link hash is required')
			.isLength({ min: 1, max: 20 })
			.withMessage('Link hash must be between 1 and 20 characters')
			.matches(/^[a-zA-Z0-9]+$/)
			.withMessage('Link hash must contain only alphanumeric characters'),
	],
	handleValidationErrors,
	getTestByLink
);

// POST /public/test/:linkHash/submit - Submit test answers
router.post(
	'/test/:linkHash/submit',
	[
		param('linkHash')
			.notEmpty()
			.withMessage('Link hash is required')
			.isLength({ min: 1, max: 20 })
			.withMessage('Link hash must be between 1 and 20 characters')
			.matches(/^[a-zA-Z0-9]+$/)
			.withMessage('Link hash must contain only alphanumeric characters'),
		body('name')
			.notEmpty()
			.withMessage('Student name is required')
			.trim()
			.isLength({ min: 1, max: 100 })
			.withMessage('Student name must be between 1 and 100 characters'),
		body('rollNo')
			.notEmpty()
			.withMessage('Roll number is required')
			.trim()
			.isLength({ min: 1, max: 50 })
			.withMessage('Roll number must be between 1 and 50 characters'),
		body('answers')
			.isArray({ min: 1 })
			.withMessage('At least one answer is required'),
		body('answers.*.qid')
			.notEmpty()
			.withMessage('Question ID is required for each answer'),
		body('answers.*.answerText')
			.optional()
			.trim()
			.isLength({ max: 1000 })
			.withMessage('Answer text must not exceed 1000 characters'),
		body('answers.*.selectedOptionIndex')
			.optional()
			.isInt({ min: 0, max: 9 })
			.withMessage('Selected option index must be between 0 and 9'),
	],
	handleValidationErrors,
	submitTest
);

// GET /public/test/:linkHash/result/:resultId - Get student result
router.get(
	'/test/:linkHash/result/:resultId',
	[
		param('linkHash')
			.notEmpty()
			.withMessage('Link hash is required')
			.isLength({ min: 1, max: 20 })
			.withMessage('Link hash must be between 1 and 20 characters')
			.matches(/^[a-zA-Z0-9]+$/)
			.withMessage('Link hash must contain only alphanumeric characters'),
		param('resultId')
			.notEmpty()
			.withMessage('Result ID is required')
			.isMongoId()
			.withMessage('Invalid result ID format'),
	],
	handleValidationErrors,
	getStudentResult
);

module.exports = router;
